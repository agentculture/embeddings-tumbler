/*! embeddings-tumbler 0.12.1 | source: github.com/agentculture/embeddings-tumbler | assembled from js/src by scripts/assemble.py, do not edit by hand */
(function (root) {
  "use strict";

  // Shared internal namespace. Every later module adds its functions here
  // (ET.math = {...}, ET.contract = {...}) and reads earlier modules' from it.
  var ET = {};
  ET.version = "0.12.1";
  // The public API object. Only 50-viewer.js fills this (mount, update, destroy).
  ET.api = {};
  // ---------------------------------------------------------------------------
  // 10-math.js: the mathematics of the viewer (ET.math). Pure functions, no DOM.
  //
  // Conventions used throughout (see js/api/10-math.md):
  //   - Vectors arrive as one flat Float32Array of length N * D, row-major
  //     (point i occupies [i * D, i * D + D)). D always comes from the caller.
  //   - A frame is a Float32Array of length 3 * D, row-major: rows 0, 1, 2 are
  //     the x, y and z viewing axes, and the rows are orthonormal.
  //   - Every projection is linear: a point's screen coordinates are the dot
  //     products of (x - centre) with the three frame rows. Nothing here builds
  //     a non-linear layout.
  //   - Anything random takes a seed. The same inputs and seed give the same
  //     output, bit for bit, in the same engine.
  // ---------------------------------------------------------------------------
  ET.math = (function () {
    var TAU = Math.PI * 2;
    var SALT_TOUR = 0x746f7572; // fixed salts so sub-streams never collide
    var SALT_SWAP = 0x73776170;
    var SALT_PCA = 0x70636121;

    // ----- seeded random source --------------------------------------------

    // Ported from the reference. Returns a function giving uniform numbers in [0, 1).
    // The state is a 32-bit word that wraps around (the wrap is the algorithm). The
    // reference keeps it as a signed word; here it is kept unsigned (>>> 0), which
    // holds the same 32 bits, and every operation below reads only those bits, so
    // the stream is the reference's, bit for bit.
    function mulberry32(seed) {
      var a = seed >>> 0;
      return function () {
        a = (a + 0x6d2b79f5) >>> 0;
        var t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
    }

    // The UTF-16 code unit at index i of s (what charCodeAt gives): codePointAt
    // gives a whole code point at the first half of a surrogate pair, so its first
    // (high) unit is rebuilt from it; everywhere else the two agree.
    function utf16UnitAt(s, i) {
      var cp = s.codePointAt(i);
      return cp > 0xffff ? 0xd800 + ((cp - 0x10000) >> 10) : cp;
    }

    // A seed may be a number or a string. Numbers are truncated to 32 bits;
    // strings are hashed (FNV-1a over their UTF-16 code units). Anything else is refused.
    function toSeed(value) {
      if (typeof value === "number" && Number.isFinite(value)) return Math.floor(value) >>> 0;
      if (typeof value === "string") {
        var h = 0x811c9dc5;
        for (var i = 0; i < value.length; i++) {
          h ^= utf16UnitAt(value, i);
          h = Math.imul(h, 0x01000193);
        }
        return h >>> 0;
      }
      throw new TypeError("seed must be a finite number or a string");
    }

    // Derive an independent 32-bit seed from (seed, salt), so that, for example,
    // cycle c of a schedule draws from its own stream whatever came before it.
    // The salt is reduced to 32 bits (>>> 0) and the arithmetic wraps; the XOR
    // already gives a signed 32-bit word.
    function mixSeed(seed, salt) {
      var h = toSeed(seed) ^ Math.imul((salt >>> 0) + 0x9e3779b9, 0x85ebca6b);
      h = Math.imul(h ^ (h >>> 16), 0x85ebca6b);
      h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
      h ^= h >>> 16;
      return h >>> 0;
    }

    // A seeded source with uniform and standard normal draws (polar method, as
    // in the reference, but with its spare value kept per source).
    function makeRandom(seed) {
      var next = mulberry32(toSeed(seed));
      var spare = null;
      function gauss() {
        if (spare !== null) {
          var s0 = spare;
          spare = null;
          return s0;
        }
        var u, v, s;
        do {
          u = next() * 2 - 1;
          v = next() * 2 - 1;
          s = u * u + v * v;
        } while (s >= 1 || s === 0);
        var m = Math.sqrt((-2 * Math.log(s)) / s);
        spare = v * m;
        return u * m;
      }
      function fillGauss(arr, offset, length) {
        var o = offset || 0;
        var n = length === undefined ? arr.length - o : length;
        for (var i = 0; i < n; i++) arr[o + i] = gauss();
        return arr;
      }
      return { next: next, gauss: gauss, fillGauss: fillGauss };
    }

    // ----- argument checks -----------------------------------------------------

    // Comparisons for the argument checks, written once as positive predicates.
    // NaN, undefined and anything else that does not compare as a number fail
    // them, which is the point: a check must refuse those. (A rewrite such as
    // `x < min` in place of `!(x >= min)` would let NaN through.)
    function atLeast(x, min) {
      return x >= min;
    }
    function above(x, min) {
      return x > min;
    }
    function intAtLeast(x, min) {
      return x >= min && Math.floor(x) === x;
    }

    // ToInt32, exactly what `x | 0` gives: non-numbers and NaN become 0 and large
    // values wrap modulo 2^32. Used to read integer options as the module always
    // has (Math.trunc would differ: NaN stays NaN, and nothing wraps).
    function toInt32(x) {
      return Math.imul(x, 1);
    }

    function checkDim(D) {
      if (!intAtLeast(D, 1)) throw new RangeError("dimension must be a positive integer");
    }

    // `rows` directions of length D in `dirs`, exactly: a mismatch is a caller bug.
    function checkRows(dirs, rows, D, what) {
      if (!intAtLeast(rows, 1) || rows > D) {
        throw new TypeError(what + ": rows must be an integer from 1 to the dimension");
      }
      if (dirs?.length !== rows * D) {
        throw new TypeError(what + ": expected " + rows * D + " values (rows * dimension)");
      }
    }

    function checkData(X, N, D) {
      checkDim(D);
      if (!intAtLeast(N, 0)) throw new RangeError("count must be a non-negative integer");
      if (!X || X.length < N * D) throw new RangeError("vector block is shorter than count * dimension");
    }

    // ----- sliced work ---------------------------------------------------------
    //
    // The long computations (centring, the principal-direction fit, the guided
    // tour's construction) are written once, as generator functions that pause
    // (yield) between small pieces of work. A stepper runs them a few units at a
    // time; the blocking functions run the same generators to the end without
    // pausing, so there is one code path and the results are bit-identical
    // however the work was sliced. A pause only ever falls between pieces, never
    // inside one, so where it falls changes how much work one step does and
    // nothing else. It falls after UNIT multiply-adds of work, or earlier once
    // SLICE_MS milliseconds have passed since the unit began (memory-bound loops
    // and code the engine has not optimised yet run slower per multiply-add).
    // The clock is read about every CHECK multiply-adds, and no piece of work
    // between two possible pauses is much larger than CHECK (PIECE is what the
    // generators aim for). That bound is what keeps a unit short on a device
    // that runs JavaScript without a compiler (an iPhone in Lockdown Mode, for
    // one): there a multiply-add costs 40 to 90 ns, not 1, so a piece of 2^20 of
    // them (one row of the Gram matrix of 999 points in 1,024-d, as it was)
    // held a frame for 50 to 90 ms whatever budget it had been given.

    var UNIT = 1 << 20; // multiply-adds per unit at most: about a millisecond of compiled arithmetic
    var CHECK = 1 << 12; // multiply-adds between two looks at the clock
    var PIECE = CHECK; // the generators pause-point at least this often (or once per vector)
    var SLICE_MS = 1;

    // How many items of `cost` multiply-adds each make one piece (at least one).
    function perPiece(cost) {
      return Math.max(1, Math.floor(PIECE / Math.max(1, cost)));
    }

    // Counts work done and says when a unit is over.
    function Tracker(total) {
      this.total = total > 0 ? total : 1;
      this.done = 0;
      this.acc = 0;
      this.nextCheck = CHECK;
      this.t0 = 0;
    }
    Tracker.prototype.add = function (cost) {
      this.done += cost;
      this.acc += cost;
      if (this.acc < this.nextCheck) return false;
      if (this.acc >= UNIT || clockNow() - this.t0 >= SLICE_MS) {
        this.acc = 0;
        this.nextCheck = CHECK;
        return true;
      }
      this.nextCheck = this.acc + CHECK;
      return false;
    };
    // The blocking calls never pause.
    var NO_PAUSE = {
      add: function () {
        return false;
      },
    };

    function runAll(gen) {
      var r = gen.next();
      while (!r.done) r = gen.next();
      return r.value;
    }

    function clockNow() {
      if (typeof performance !== "undefined" && typeof performance?.now === "function") {
        return performance.now();
      }
      return Date.now();
    }

    // A stepper over a generator: { step(budgetMs?) -> done, done, progress, result }.
    // step(budgetMs) runs units until budgetMs milliseconds have passed (always at
    // least one unit, so step(0) runs exactly one); step() runs to the end.
    // `result` is null until done.
    function genStepper(gen, tracker) {
      var st = { done: false, progress: 0, result: null, step: null };
      st.step = function (budgetMs) {
        if (st.done) return true;
        var limit = budgetMs === undefined ? Infinity : budgetMs;
        var start = clockNow();
        var first = true;
        while (first || limit === Infinity || clockNow() - start < limit) {
          first = false;
          tracker.t0 = clockNow();
          var r = gen.next();
          if (r.done) {
            st.done = true;
            st.result = r.value;
            st.progress = 1;
            return true;
          }
        }
        st.progress = Math.min(0.99, tracker.done / tracker.total);
        return false;
      };
      return st;
    }

    // Callers pass sums that start from +0, so x is never -0 (the one value where
    // this and the nested comparison `x < 0 ? 0 : x > 1 ? 1 : x` would differ).
    function clamp01(x) {
      return Math.min(Math.max(x, 0), 1);
    }

    // ----- centring and variance -------------------------------------------

    // Mean of N points in D dimensions, accumulated in double precision.
    function meanOf(X, N, D) {
      checkData(X, N, D);
      var mean = new Float64Array(D);
      for (var i = 0; i < N; i++) {
        var o = i * D;
        for (var d = 0; d < D; d++) mean[d] += X[o + d];
      }
      if (N > 0) for (var e = 0; e < D; e++) mean[e] /= N;
      return mean;
    }

    // Centring, sliced by rows: the mean (accumulated row by row in double
    // precision, as meanOf), then the centred rows.
    function* centreGen(X, N, D, inPlace, wk) {
      var mean = new Float64Array(D);
      for (var i = 0; i < N; i++) {
        var o = i * D;
        for (var d = 0; d < D; d++) mean[d] += X[o + d];
        if (wk.add(D)) yield;
      }
      if (N > 0) for (var e = 0; e < D; e++) mean[e] /= N;
      var Y = inPlace ? X : new Float32Array(N * D);
      for (var i2 = 0; i2 < N; i2++) {
        var o2 = i2 * D;
        for (var d2 = 0; d2 < D; d2++) Y[o2 + d2] = X[o2 + d2] - mean[d2];
        if (wk.add(D)) yield;
      }
      return { mean: mean, data: Y };
    }

    // Subtract the mean. Returns { mean: Float64Array(D), data: Float32Array(N*D) }.
    // With opts.inPlace the input block itself is overwritten and returned as data.
    // Centring is a translation: all pairwise distances are unchanged.
    function centre(X, N, D, opts) {
      checkData(X, N, D);
      return runAll(centreGen(X, N, D, !!opts?.inPlace, NO_PAUSE));
    }

    // The same, as a stepper whose result is centre()'s, bit for bit.
    function makeCentre(X, N, D, opts) {
      checkData(X, N, D);
      var wk = new Tracker(2 * N * D);
      return genStepper(centreGen(X, N, D, !!opts?.inPlace, wk), wk);
    }

    function* totalVarianceGen(Y, N, D, wk) {
      var s = 0;
      for (var i = 0; i < N; i++) {
        var o = i * D;
        for (var d = 0; d < D; d++) s += Y[o + d] * Y[o + d];
        if (wk.add(D)) yield;
      }
      return N > 0 ? s / N : 0;
    }

    // Total variance of centred data: the mean squared length of the rows.
    function totalVariance(Y, N, D) {
      checkData(Y, N, D);
      return runAll(totalVarianceGen(Y, N, D, NO_PAUSE));
    }

    // Sum over the rows of the squared projection onto each of `rows` unit
    // directions (row r of dirs), each sum taken in row order.
    function* projectedSquaresGen(Y, N, D, dirs, rows, wk) {
      var sums = new Float64Array(rows);
      for (var i = 0; i < N; i++) {
        var oi = i * D;
        for (var r = 0; r < rows; r++) {
          var o = r * D;
          var p = 0;
          for (var d = 0; d < D; d++) p += Y[oi + d] * dirs[o + d];
          sums[r] += p * p;
        }
        if (wk.add(rows * D)) yield;
      }
      return sums;
    }

    // Share of the total variance held by the span of `rows` orthonormal
    // directions (row-major, rows * D). Exact for whatever directions are given,
    // clamped to [0, 1] (rounding can otherwise overshoot 1 by about 1e-8).
    function varianceShare(Y, N, D, dirs, rows) {
      checkData(Y, N, D);
      checkRows(dirs, rows, D, "varianceShare");
      var total = totalVariance(Y, N, D);
      if (!above(total, 0)) return 0;
      var sums = runAll(projectedSquaresGen(Y, N, D, dirs, rows, NO_PAUSE));
      var s = 0;
      for (var r = 0; r < rows; r++) s += N > 0 ? sums[r] / N : 0;
      return clamp01(s / total);
    }

    // ----- orthonormal frames ------------------------------------------------

    // Gram-Schmidt, in place, on `rows` rows of length D, with a second
    // re-orthogonalisation pass. Work happens in double precision. A row that
    // collapses (it lies in the span of the rows before it) is replaced by the
    // standard basis vector least covered by those rows, so the result is always
    // orthonormal and never depends on a random draw.
    function orthonormalize(M, rows, D) {
      checkDim(D);
      if (rows > D) throw new RangeError("cannot fit more orthonormal rows than the dimension");
      var v = new Float64Array(D);
      for (var i = 0; i < rows; i++) orthoRow(M, i, D, v);
      return M;
    }

    // The same, sliced inside each row: a pause may fall after each earlier row
    // is removed (2 * D multiply-adds), so a row of a wide block (4 * i * D in
    // all) never holds a unit. The arithmetic and its order are orthoRow's.
    function* orthonormalizeGen(M, rows, D, wk) {
      checkDim(D);
      if (rows > D) throw new RangeError("cannot fit more orthonormal rows than the dimension");
      var v = new Float64Array(D);
      for (var i = 0; i < rows; i++) {
        var before = loadRowForOrtho(M, i, D, v);
        for (var pass = 0; pass < 2; pass++) {
          for (var j = 0; j < i; j++) {
            removeRow(v, 0, M, j * D, D);
            if (wk.add(2 * D)) yield;
          }
        }
        finishOrthoRow(M, i, D, v, before);
        if (wk.add(3 * D)) yield;
      }
      return M;
    }

    // Squared length of v[vo .. vo + D), summed in index order.
    function sqNorm(v, vo, D) {
      var s = 0;
      for (var d = 0; d < D; d++) s += v[vo + d] * v[vo + d];
      return s;
    }

    // Remove from v[vo .. vo + D) its components along rows 0..rows-1 of M
    // (row-major, meant to be orthonormal), one row at a time, in two passes.
    function removeSpan(v, vo, M, rows, D) {
      for (var pass = 0; pass < 2; pass++) {
        for (var j = 0; j < rows; j++) removeRow(v, vo, M, j * D, D);
      }
    }

    // Remove from v[vo .. vo + D) its component along the row of M at offset oj.
    function removeRow(v, vo, M, oj, D) {
      var dp = 0;
      for (var d = 0; d < D; d++) dp += v[vo + d] * M[oj + d];
      for (var d2 = 0; d2 < D; d2++) v[vo + d2] -= dp * M[oj + d2];
    }

    // Row i of M made orthogonal to rows 0..i-1 (twice) and normalised; v is scratch.
    function orthoRow(M, i, D, v) {
      var before = loadRowForOrtho(M, i, D, v);
      removeSpan(v, 0, M, i, D);
      finishOrthoRow(M, i, D, v, before);
    }

    // Copy row i of M into v; returns its squared length.
    function loadRowForOrtho(M, i, D, v) {
      var oi = i * D;
      var before = 0;
      for (var d = 0; d < D; d++) {
        v[d] = M[oi + d];
        before += v[d] * v[d];
      }
      return before;
    }

    // v (row i with rows 0..i-1 removed) normalised into row i of M, or the
    // fallback row when it collapsed.
    function finishOrthoRow(M, i, D, v, before) {
      var oi = i * D;
      var nn = sqNorm(v, 0, D);
      if (!above(nn, 1e-24) || nn <= 1e-12 * before) nn = fallbackRow(M, i, D, v);
      var inv = 1 / Math.sqrt(nn);
      for (var d6 = 0; d6 < D; d6++) M[oi + d6] = v[d6] * inv;
    }

    // The indices 0..D-1 ordered by how much rows 0..i-1 of M cover each
    // standard basis vector (least first, ties to the lower index).
    function coverageOrder(M, i, D) {
      var cover = new Float64Array(D);
      var order = [];
      for (var c = 0; c < D; c++) {
        var cv = 0;
        for (var j = 0; j < i; j++) cv += M[j * D + c] * M[j * D + c];
        cover[c] = cv;
        order.push(c);
      }
      order.sort(function (a, b) {
        return cover[a] - cover[b] || a - b;
      });
      return order;
    }

    // Standard basis vectors in order of least coverage by rows 0..i-1 (ties
    // to the lower index), each made orthogonal to those rows; the first whose
    // remainder does not collapse is written into v. Returns its squared norm.
    // Since i < D, some basis vector always keeps at least (D - i) / D of its
    // length, so the search ends.
    function fallbackRow(M, i, D, v) {
      var order = coverageOrder(M, i, D);
      var bestNorm = -1;
      var bestC = order[0];
      var nn = 0;
      for (var t = 0; t <= D; t++) {
        // after trying every candidate, settle on the one that kept the most
        var cand = t < D ? order[t] : bestC;
        v.fill(0);
        v[cand] = 1;
        removeSpan(v, 0, M, i, D);
        nn = sqNorm(v, 0, D);
        if (t === D || nn > 1e-6) return nn;
        if (nn > bestNorm) {
          bestNorm = nn;
          bestC = cand;
        }
      }
      return nn;
    }

    // Largest deviation of M M^T from the identity (rows * rows entries).
    function frameError(M, rows, D) {
      var worst = 0;
      for (var a = 0; a < rows; a++) {
        for (var b = a; b < rows; b++) {
          var s = 0;
          for (var d = 0; d < D; d++) s += M[a * D + d] * M[b * D + d];
          var e = Math.abs(s - (a === b ? 1 : 0));
          if (e > worst) worst = e;
        }
      }
      return worst;
    }

    // A frame drawn uniformly at random (Gaussian rows, orthonormalised).
    function randomFrame(D, rng, out, rows) {
      checkDim(D);
      var R = rows || 3;
      var F = out || new Float32Array(R * D);
      rng.fillGauss(F, 0, R * D);
      return orthonormalize(F, R, D);
    }

    // Linear projection of N points onto a frame: out[i*3 + r] = (x_i - centre) . F_r.
    // `centre` may be null (zero). Returns Float32Array(N * rows).
    function project(X, N, D, frame, centreVec, out, rows) {
      checkData(X, N, D);
      var R = rows ?? 3;
      checkRows(frame, R, D, "project");
      if (centreVec && centreVec.length !== D) throw new TypeError("project: centre must have dimension values");
      if (out && out.length < N * R) throw new TypeError("project: out is shorter than count * rows");
      var P = out || new Float32Array(N * R);
      var x = new Float64Array(D);
      for (var i = 0; i < N; i++) {
        loadRow(X, i * D, D, centreVec, x);
        for (var r = 0; r < R; r++) {
          var s = 0;
          var or = r * D;
          for (var d2 = 0; d2 < D; d2++) s += x[d2] * frame[or + d2];
          P[i * R + r] = s;
        }
      }
      return P;
    }

    // x = the row of X starting at o, minus centreVec when one is given.
    function loadRow(X, o, D, centreVec, x) {
      if (centreVec) for (var d = 0; d < D; d++) x[d] = X[o + d] - centreVec[d];
      else for (var d0 = 0; d0 < D; d0++) x[d0] = X[o + d0];
    }

    // ----- small symmetric eigenproblems (cyclic Jacobi) ---------------------

    // Eigen-decomposition of a symmetric n x n matrix (Float64Array, row-major).
    // Returns { values: Float64Array(n) descending, vectors: Float64Array(n*n) }
    // where vectors row j is the unit eigenvector for values[j]. Each vector's
    // largest-magnitude component is made positive, so the output is canonical.
    function symmetricEigen(A, n) {
      return runAll(symmetricEigenGen(A, n, NO_PAUSE));
    }

    function* symmetricEigenGen(A, n, wk) {
      var a = new Float64Array(A);
      var V = new Float64Array(n * n);
      for (var i = 0; i < n; i++) V[i * n + i] = 1;
      for (var sweep = 0; sweep < 100; sweep++) {
        if (jacobiSettled(a, n)) break;
        for (var p = 0; p < n; p++) {
          for (var q = p + 1; q < n; q++) jacobiRotate(a, V, n, p, q);
          if (wk.add(6 * n * (n - p))) yield;
        }
      }
      return canonicalEigen(a, V, n);
    }

    // True once the off-diagonal mass is negligible against the diagonal.
    function jacobiSettled(a, n) {
      var off = 0;
      var diag = 0;
      for (var p = 0; p < n; p++) {
        diag += a[p * n + p] * a[p * n + p];
        for (var q = p + 1; q < n; q++) off += a[p * n + q] * a[p * n + q];
      }
      return off <= 1e-30 * (diag + 1e-300) || off === 0;
    }

    // One Jacobi rotation zeroing a[p][q], applied to a (both sides) and to V.
    function jacobiRotate(a, V, n, p, q) {
      var apq = a[p * n + q];
      if (apq === 0) return;
      var app = a[p * n + p];
      var aqq = a[q * n + q];
      var theta = (aqq - app) / (2 * apq);
      var t = (theta >= 0 ? 1 : -1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
      var c = 1 / Math.sqrt(t * t + 1);
      var s = t * c;
      for (var k = 0; k < n; k++) {
        var akp = a[k * n + p];
        var akq = a[k * n + q];
        a[k * n + p] = c * akp - s * akq;
        a[k * n + q] = s * akp + c * akq;
      }
      for (var k2 = 0; k2 < n; k2++) {
        var apk = a[p * n + k2];
        var aqk = a[q * n + k2];
        a[p * n + k2] = c * apk - s * aqk;
        a[q * n + k2] = s * apk + c * aqk;
      }
      for (var k3 = 0; k3 < n; k3++) {
        var vkp = V[k3 * n + p];
        var vkq = V[k3 * n + q];
        V[k3 * n + p] = c * vkp - s * vkq;
        V[k3 * n + q] = s * vkp + c * vkq;
      }
    }

    // Eigenvalues (the diagonal of a) in descending order, ties to the lower
    // index, with the matching columns of V as rows, each signed canonically.
    function canonicalEigen(a, V, n) {
      var order = [];
      for (var j = 0; j < n; j++) order.push(j);
      order.sort(function (x, y) {
        var dv = a[y * n + y] - a[x * n + x];
        return dv !== 0 ? dv : x - y;
      });
      var values = new Float64Array(n);
      var vectors = new Float64Array(n * n);
      for (var r = 0; r < n; r++) {
        var col = order[r];
        values[r] = a[col * n + col];
        var sign = largestSign(V, n, col);
        for (var k5 = 0; k5 < n; k5++) vectors[r * n + k5] = sign * V[k5 * n + col];
      }
      return { values: values, vectors: vectors };
    }

    // The sign of column col's largest-magnitude component (the first such, +1 if all zero).
    function largestSign(V, n, col) {
      var big = 0;
      var sign = 1;
      for (var k4 = 0; k4 < n; k4++) {
        var comp = V[k4 * n + col];
        if (Math.abs(comp) > big) {
          big = Math.abs(comp);
          sign = comp < 0 ? -1 : 1;
        }
      }
      return sign;
    }

    // ----- principal directions ---------------------------------------------

    // Top-k principal directions of centred data Y (N x D).
    //   N <= D: through the N x N Gram matrix (exactly by Jacobi when N is small,
    //           otherwise by block subspace iteration on the Gram matrix).
    //   N >  D: block subspace iteration on the covariance, applied as
    //           Y^T (Y q) without forming it.
    // The reported variances are recomputed exactly along the returned
    // directions, so shares are honest even where iteration stopped early.
    // opts: { seed, maxIterations (60), tolerance (1e-6, relative change of the
    //         top-k Ritz values), oversample (k, min 4), sampleRows }
    // With sampleRows = S and N > S, the directions are fitted on S rows taken
    // at an even stride (deterministic), and the variances and shares are still
    // computed exactly over all N rows.
    // Runs makePrincipalDirections to the end: the same bytes, in one call.
    function principalDirections(Y, N, D, k, opts) {
      checkPca(Y, N, D, opts);
      return runAll(pcaGen(Y, N, D, k, opts || {}, NO_PAUSE, false));
    }

    // The same fit as a stepper { step(budgetMs?) -> done, done, progress, result }.
    // Arguments are checked here, as principalDirections checks them.
    function makePrincipalDirections(Y, N, D, k, opts) {
      checkPca(Y, N, D, opts);
      var o = opts || {};
      var wk = new Tracker(pcaWorkEstimate(N, D, k, o));
      return genStepper(pcaGen(Y, N, D, k, o, wk, false), wk);
    }

    function checkPca(Y, N, D, opts) {
      checkData(Y, N, D);
      var o = opts || {};
      var maxIt = o.maxIterations === undefined ? 60 : o.maxIterations;
      var tol = o.tolerance === undefined ? 1e-6 : o.tolerance;
      if (!intAtLeast(maxIt, 0)) {
        throw new RangeError("maxIterations must be a non-negative integer");
      }
      // `+tol` is the number conversion the global isFinite applied, so a numeric
      // string such as "0.5" is still accepted and "Infinity" still refused.
      if (!atLeast(tol, 0) || !Number.isFinite(+tol)) throw new RangeError("tolerance must be a finite number >= 0");
      if (o.oversample !== undefined && !intAtLeast(o.oversample, 0)) {
        throw new RangeError("oversample must be a non-negative integer");
      }
    }

    // A rough count of the multiply-adds a fit takes (for progress only),
    // assuming a dozen iterations.
    function pcaWorkEstimate(N, D, k, o) {
      var K = Math.max(1, Math.min(toInt32(k), D));
      var S = toInt32(o.sampleRows);
      var n = S > 0 && N > S ? S : N;
      var p = Math.min(n, D, K + (o.oversample === undefined ? Math.max(4, K) : o.oversample));
      var fit = n <= D ? (n * n * D) / 2 + 12 * p * n * n : 12 * 2 * n * D * p;
      return n * D + N * D + fit + K * N * D;
    }

    // pcaGen: the fit itself. `inner` marks the fit on the sampled rows, whose
    // variances the outer call recomputes over all rows, so it skips them.
    function* pcaGen(Y, N, D, k, o, wk, inner) {
      var maxIt = o.maxIterations === undefined ? 60 : o.maxIterations;
      var tol = o.tolerance === undefined ? 1e-6 : o.tolerance;
      var S = toInt32(o.sampleRows);
      if (S > 0 && N > S) return yield* sampledPcaGen(Y, N, D, k, o, S, wk);
      // k is clamped into 1..D. Directions beyond the data's rank (at most
      // N - 1 for centred data) are an orthonormal completion with variance 0.
      var K = Math.max(1, Math.min(toInt32(k), D));
      var total = yield* totalVarianceGen(Y, N, D, wk);
      var result = {
        count: K,
        dimension: D,
        directions: new Float32Array(K * D),
        variances: new Float64Array(K),
        shares: new Float64Array(K),
        totalVariance: total,
        share: 0,
        method: "",
        iterations: 0,
        converged: true,
        sampledRows: N,
      };
      if (N === 0 || !above(total, 0)) {
        yield* orthonormalizeGen(result.directions, K, D, wk);
        result.method = "degenerate";
      } else {
        var fit = {
          seed: mixSeed(o.seed === undefined ? 0 : o.seed, SALT_PCA),
          maxIt: maxIt,
          tol: tol,
          oversample: o.oversample,
        };
        if (N <= D) yield* gramFitGen(Y, N, D, fit, result, wk);
        else yield* covarianceFitGen(Y, N, D, fit, result, wk);
      }
      if (!inner) yield* finishPcaGen(Y, N, D, result, wk);
      return result;
    }

    // The fit on S rows taken at an even stride, with the variances and shares
    // then computed over all N rows.
    function* sampledPcaGen(Y, N, D, k, o, S, wk) {
      var Ys = new Float32Array(S * D);
      for (var si = 0; si < S; si++) {
        var src = Math.floor((si * N) / S) * D;
        for (var sd = 0; sd < D; sd++) Ys[si * D + sd] = Y[src + sd];
        if (wk.add(D)) yield;
      }
      var innerOpts = {};
      for (var key in o) if (key !== "sampleRows") innerOpts[key] = o[key];
      var fitted = yield* pcaGen(Ys, S, D, k, innerOpts, wk, true);
      Ys = null;
      fitted.totalVariance = yield* totalVarianceGen(Y, N, D, wk);
      fitted.method += "-sampled";
      fitted.sampledRows = S;
      yield* finishPcaGen(Y, N, D, fitted, wk);
      return fitted;
    }

    // N <= D: eigenvectors of the N x N Gram matrix (exact by Jacobi up to 64
    // rows, by subspace iteration above), mapped back to directions in R^D.
    function* gramFitGen(Y, N, D, fit, result, wk) {
      var K = result.count;
      var G = yield* gramGen(Y, N, D, wk);
      var vecs; // rows in N-space
      var nv = Math.min(K, N);
      if (N <= 64) {
        vecs = (yield* symmetricEigenGen(G, N, wk)).vectors;
        result.method = "gram-exact";
      } else {
        var it = yield* subspaceIterationGen(
          function (Q, p, W) {
            return denseApplyGen(G, N, Q, p, W, wk);
          },
          N,
          nv,
          fit,
          wk
        );
        vecs = it.vectors;
        result.method = "gram-iterative";
        result.iterations = it.iterations;
        result.converged = it.converged;
      }
      yield* combineRowsGen(vecs, nv, Y, N, D, result.directions, wk);
      yield* orthonormalizeGen(result.directions, K, D, wk);
    }

    // dirs row j += sum over a of vecs[j][a] * Y row a, for j < nv (zero weights skipped).
    function* combineRowsGen(vecs, nv, Y, N, D, dirs, wk) {
      for (var j = 0; j < nv; j++) {
        var oj = j * D;
        for (var a = 0; a < N; a++) {
          var w = vecs[j * N + a];
          if (w === 0) continue;
          var oa = a * D;
          for (var d = 0; d < D; d++) dirs[oj + d] += w * Y[oa + d];
          if (wk.add(D)) yield;
        }
      }
    }

    // N > D: subspace iteration on the covariance, applied without forming it.
    function* covarianceFitGen(Y, N, D, fit, result, wk) {
      var K = result.count;
      var dirs = result.directions;
      var it = yield* subspaceIterationGen(
        function (Q, p, W) {
          return covarianceApplyGen(Y, N, D, Q, p, W, wk);
        },
        D,
        K,
        fit,
        wk
      );
      for (var j = 0; j < K * D; j++) dirs[j] = it.vectors[j];
      yield* orthonormalizeGen(dirs, K, D, wk);
      result.method = "covariance-iterative";
      result.iterations = it.iterations;
      result.converged = it.converged;
    }

    // Exact variances and shares along the result's directions, over all rows.
    // Shares are clamped to [0, 1] (rounding can otherwise overshoot 1 slightly).
    function* finishPcaGen(Y, N, D, result, wk) {
      var K = result.count;
      var total = result.totalVariance;
      var sums = yield* projectedSquaresGen(Y, N, D, result.directions, K, wk);
      var s = 0;
      for (var r = 0; r < K; r++) {
        var v = N > 0 ? sums[r] / N : 0;
        result.variances[r] = v;
        result.shares[r] = total > 0 ? clamp01(v / total) : 0;
        s += result.shares[r];
      }
      result.share = clamp01(s);
    }

    // The Gram matrix Y Y^T, a few entries at a time: a whole row of it is up to
    // N * D multiply-adds (a million for 999 points in 1,024-d), far too long
    // for one piece. Each entry is its own sum, so where a pause falls changes
    // nothing.
    function* gramGen(Y, N, D, wk) {
      var G = new Float64Array(N * N);
      var chunk = perPiece(D);
      for (var a = 0; a < N; a++) {
        for (var b = a; b < N; b += chunk) {
          var end = Math.min(N, b + chunk);
          gramEntries(Y, G, a, b, end, N, D);
          if (wk.add((end - b) * D)) yield;
        }
      }
      return G;
    }

    // G[a][b] and G[b][a] for b in [from, to): the dot product of rows a and b.
    function gramEntries(Y, G, a, from, to, N, D) {
      var oa = a * D;
      for (var b = from; b < to; b++) {
        var ob = b * D;
        var s = 0;
        for (var d = 0; d < D; d++) s += Y[oa + d] * Y[ob + d];
        G[a * N + b] = s;
        G[b * N + a] = s;
      }
    }

    // W (p rows of length n) = A Q for symmetric dense A (n x n), Q given as rows.
    function* denseApplyGen(A, n, Q, p, W, wk) {
      for (var j = 0; j < p; j++) {
        var oj = j * n;
        for (var a = 0; a < n; a++) {
          var s = 0;
          var oa = a * n;
          for (var b = 0; b < n; b++) s += A[oa + b] * Q[oj + b];
          W[oj + a] = s;
          if (wk.add(n)) yield;
        }
      }
    }

    // W (p rows of length D) = Y^T (Y Q^T)^T, i.e. the covariance (times N)
    // applied to each row of Q, without forming the D x D matrix.
    function* covarianceApplyGen(Y, N, D, Q, p, W, wk) {
      // Rows of Y are taken four at a time so each pass over Q and W serves
      // four points (a quarter of the memory traffic). A missing row at the end
      // repeats the last real row with weight zero. The order of additions is
      // fixed, so the result is still deterministic.
      // A group of four rows against all p directions is 8 * p * D
      // multiply-adds (131,072 at p = 16 in 1,024-d), so a pause may fall
      // between directions: row j of W depends only on row j of Q.
      W.fill(0);
      var z = new Float64Array(4 * p);
      var chunk = perPiece(8 * D);
      for (var i = 0; i < N; i += 4) {
        var live = Math.min(4, N - i); // real rows in this group
        var group = { oa: i * D, live: live };
        for (var j = 0; j < p; j += chunk) {
          var end = Math.min(p, j + chunk);
          projectFour(Y, group, Q, j, end, D, z);
          accumulateFour(Y, group, z, j, end, D, W);
          if (wk.add(8 * (end - j) * D)) yield;
        }
      }
    }

    // Offset in Y of row r of the group of four starting at offset oa: a row
    // beyond the `live` real ones repeats the first.
    function rowOffset(oa, r, live, D) {
      return r < live ? oa + r * D : oa;
    }

    // z[4j + r] = (Y row r of the group at group.oa) . (Q row j), 0 for a row
    // beyond the group.live real ones, for j in [from, to).
    function projectFour(Y, group, Q, from, to, D, z) {
      var oa = group.oa;
      var live = group.live;
      var ob = rowOffset(oa, 1, live, D);
      var oc = rowOffset(oa, 2, live, D);
      var od = rowOffset(oa, 3, live, D);
      for (var j = from; j < to; j++) {
        var sa = 0;
        var sb = 0;
        var sc = 0;
        var sd = 0;
        var oj = j * D;
        for (var d = 0; d < D; d++) {
          var q = Q[oj + d];
          sa += Y[oa + d] * q;
          sb += Y[ob + d] * q;
          sc += Y[oc + d] * q;
          sd += Y[od + d] * q;
        }
        z[4 * j] = sa;
        z[4 * j + 1] = live > 1 ? sb : 0;
        z[4 * j + 2] = live > 2 ? sc : 0;
        z[4 * j + 3] = live > 3 ? sd : 0;
      }
    }

    // W row j += the four rows weighted by z[4j .. 4j + 3], in a fixed order,
    // for j in [from, to).
    function accumulateFour(Y, group, z, from, to, D, W) {
      var oa = group.oa;
      var live = group.live;
      var ob = rowOffset(oa, 1, live, D);
      var oc = rowOffset(oa, 2, live, D);
      var od = rowOffset(oa, 3, live, D);
      for (var j2 = from; j2 < to; j2++) {
        var a = z[4 * j2];
        var b = z[4 * j2 + 1];
        var c = z[4 * j2 + 2];
        var e = z[4 * j2 + 3];
        var o2 = j2 * D;
        for (var d2 = 0; d2 < D; d2++) {
          W[o2 + d2] += a * Y[oa + d2] + b * Y[ob + d2] + (c * Y[oc + d2] + e * Y[od + d2]);
        }
      }
    }

    // Block subspace iteration with Rayleigh-Ritz for the top k eigenvectors
    // of a symmetric positive semi-definite operator on R^n. Deterministic for
    // a given seed. `applyGen(Q, p, W)` returns a generator that fills W.
    // `fit` is { seed, maxIt, tol, oversample } (oversample may be undefined).
    // Returns { vectors: Float64Array(k*n) rows, values, iterations, converged }.
    function* subspaceIterationGen(applyGen, n, k, fit, wk) {
      var extra = fit.oversample === undefined ? Math.max(4, k) : fit.oversample;
      var p = Math.min(n, k + extra);
      var rng = makeRandom(fit.seed);
      var Q = new Float64Array(p * n);
      rng.fillGauss(Q, 0, p * n);
      yield* orthonormalizeGen(Q, p, n, wk);
      var W = new Float64Array(p * n);
      var B = new Float64Array(p * p);
      var prev = null;
      var eig = null;
      var iterations = 0;
      var converged = false;
      for (var it = 0; it <= fit.maxIt; it++) {
        yield* applyGen(Q, p, W);
        iterations = it + 1;
        yield* rayleighGen(Q, W, B, p, n, wk);
        eig = yield* symmetricEigenGen(B, p, wk);
        if (prev && ritzSettled(eig.values, prev, k, fit.tol)) {
          converged = true;
          break;
        }
        if (it === fit.maxIt) break;
        prev = eig.values;
        var tmp = Q;
        Q = W;
        W = tmp;
        yield* orthonormalizeGen(Q, p, n, wk);
      }
      var vectors = yield* ritzVectorsGen(eig.vectors, Q, k, p, n, wk);
      return { vectors: vectors, values: eig.values.slice(0, k), iterations: iterations, converged: converged };
    }

    // B (p x p, symmetric) = Q W^T, with Q and W given as p rows of length n.
    function* rayleighGen(Q, W, B, p, n, wk) {
      for (var a = 0; a < p; a++) {
        for (var b = a; b < p; b++) {
          var s = 0;
          for (var x = 0; x < n; x++) s += Q[a * n + x] * W[b * n + x];
          B[a * p + b] = s;
          B[b * p + a] = s;
          if (wk.add(n)) yield;
        }
      }
    }

    // True when the top k Ritz values moved by at most tol relative to the largest.
    function ritzSettled(values, prev, k, tol) {
      var worst = 0;
      for (var r = 0; r < k; r++) {
        var dv = Math.abs(values[r] - prev[r]);
        if (dv > worst) worst = dv;
      }
      return worst <= tol * Math.max(values[0], 1e-300);
    }

    // The top k Ritz vectors in R^n: row r = sum over c of evecs[r][c] * Q row c.
    function* ritzVectorsGen(evecs, Q, k, p, n, wk) {
      var vectors = new Float64Array(k * n);
      for (var r2 = 0; r2 < k; r2++) {
        for (var c = 0; c < p; c++) {
          var w = evecs[r2 * p + c];
          if (w === 0) continue;
          for (var x2 = 0; x2 < n; x2++) vectors[r2 * n + x2] += w * Q[c * n + x2];
          if (wk.add(n)) yield;
        }
      }
      return vectors;
    }

    // ----- the guided tour (Tumble) ------------------------------------------

    // A tour through an m-dimensional subspace spanned by orthonormal `basis`
    // rows (m * D). The frame at time t is a closed-form function of
    // (basis, seed, speed, t): F(t) = E L(t) P basis, where P is a seeded random
    // m x m rotation, L(t) turns m/2 planes at seeded frequencies, and E picks
    // the start so that F(0) is the first three basis rows. There is no state:
    // frameAt(t) gives the same frame however time has been sliced.
    // opts: { seed (0), speed (0.42 rad/s, the reference's rate) }
    function makeTour(basis, m, D, opts) {
      checkDim(D);
      if (!atLeast(m, 3)) throw new RangeError("a tour needs at least three directions");
      if (m > D) throw new RangeError("a tour cannot use more directions than the dimension");
      var o = opts || {};
      var seed = toSeed(o.seed === undefined ? 0 : o.seed);
      var speed = o.speed === undefined ? 0.42 : o.speed;
      var rng = makeRandom(mixSeed(seed, SALT_TOUR));
      var P = new Float64Array(m * m);
      rng.fillGauss(P, 0, m * m);
      orthonormalize(P, m, m);
      var planes = Math.floor(m / 2);
      var freq = new Float64Array(planes);
      for (var h = 0; h < planes; h++) {
        var mag = speed * (0.55 + 0.9 * rng.next());
        freq[h] = rng.next() < 0.5 ? -mag : mag;
      }
      // E = first three rows of P^T: E[r][c] = P[c][r].
      var E = new Float64Array(3 * m);
      for (var r = 0; r < 3; r++) for (var c = 0; c < m; c++) E[r * m + c] = P[c * m + r];
      var L = new Float64Array(3 * m);
      var A = new Float64Array(3 * m);
      var F64 = new Float64Array(3 * D);
      var basisCopy = new Float32Array(basis.subarray ? basis.subarray(0, m * D) : basis.slice(0, m * D));

      // A(t): the 3 x m coefficients of the frame in the basis. Rows orthonormal.
      function coefficientsAt(t, out) {
        var res = out || new Float64Array(3 * m);
        for (var i = 0; i < 3 * m; i++) L[i] = E[i];
        for (var hh = 0; hh < planes; hh++) {
          var ang = freq[hh] * t;
          var cs = Math.cos(ang);
          var sn = Math.sin(ang);
          var c0 = 2 * hh;
          for (var rr = 0; rr < 3; rr++) {
            var x = E[rr * m + c0];
            var y = E[rr * m + c0 + 1];
            L[rr * m + c0] = cs * x - sn * y;
            L[rr * m + c0 + 1] = sn * x + cs * y;
          }
        }
        for (var r2 = 0; r2 < 3; r2++) {
          for (var c2 = 0; c2 < m; c2++) {
            var s = 0;
            for (var q = 0; q < m; q++) s += L[r2 * m + q] * P[q * m + c2];
            res[r2 * m + c2] = s;
          }
        }
        orthonormalize(res, 3, m);
        return res;
      }

      function frameAt(t, out) {
        if (typeof t !== "number" || !Number.isFinite(t)) throw new RangeError("time must be a finite number");
        var F = out || new Float32Array(3 * D);
        coefficientsAt(t, A);
        F64.fill(0);
        for (var r3 = 0; r3 < 3; r3++) {
          var orow = r3 * D;
          for (var j = 0; j < m; j++) {
            var w = A[r3 * m + j];
            var ob = j * D;
            for (var d = 0; d < D; d++) F64[orow + d] += w * basisCopy[ob + d];
          }
        }
        orthonormalize(F64, 3, D);
        for (var i2 = 0; i2 < 3 * D; i2++) F[i2] = F64[i2];
        orthonormalize(F, 3, D);
        return F;
      }

      return {
        kind: "guided-tour",
        seed: seed,
        speed: speed,
        dimension: D,
        subspace: m,
        basis: basisCopy,
        frequencies: freq,
        coefficientsAt: coefficientsAt,
        frameAt: frameAt,
      };
    }

    // The guided tour over data: principal directions first, then a tour inside
    // them. Reports the share of total variance held by the toured directions.
    // opts: { seed (0), subspace (8), speed, pca (a principalDirections result
    //         to reuse); sampleRows, maxIterations, tolerance and oversample are
    //         passed to principalDirections }
    // Runs makeGuidedTour to the end: the same tour, in one call.
    function guidedTour(Y, N, D, opts) {
      var o = opts || {};
      var m = checkGuidedTour(Y, N, D, o);
      return runAll(guidedTourGen(Y, N, D, o, m, NO_PAUSE));
    }

    // The same as a stepper { step(budgetMs?) -> done, done, progress, result }
    // whose result is the tour.
    function makeGuidedTour(Y, N, D, opts) {
      var o = opts || {};
      var m = checkGuidedTour(Y, N, D, o);
      var est = needsFit(o.pca, m, D) ? pcaWorkEstimate(N, D, m, o) : 1;
      var wk = new Tracker(est);
      return genStepper(guidedTourGen(Y, N, D, o, m, wk), wk);
    }

    function needsFit(pca, m, D) {
      return !pca || pca.count < m || pca.dimension !== D;
    }

    function tourPcaOpts(o) {
      return {
        seed: o.seed,
        sampleRows: o.sampleRows,
        maxIterations: o.maxIterations,
        tolerance: o.tolerance,
        oversample: o.oversample,
      };
    }

    function checkGuidedTour(Y, N, D, o) {
      checkData(Y, N, D);
      var m = Math.min(o.subspace === undefined ? 8 : toInt32(o.subspace), D);
      if (m < 3) throw new RangeError("a guided tour needs a subspace of at least three directions");
      if (needsFit(o.pca, m, D)) checkPca(Y, N, D, tourPcaOpts(o));
      return m;
    }

    function* guidedTourGen(Y, N, D, o, m, wk) {
      var pca = o.pca;
      if (needsFit(pca, m, D)) pca = yield* pcaGen(Y, N, D, m, tourPcaOpts(o), wk, false);
      var basis = pca.directions.subarray(0, m * D);
      var tour = makeTour(basis, m, D, { seed: o.seed, speed: o.speed });
      var share = 0;
      for (var j = 0; j < m; j++) share += pca.shares[j];
      tour.kind = "guided-tour";
      tour.varianceShare = clamp01(share);
      tour.variances = pca.variances.slice(0, m);
      tour.totalVariance = pca.totalVariance;
      tour.pca = pca;
      return tour;
    }

    // ----- axis swap (Lattice) ------------------------------------------------

    // A unit vector orthogonal to the frame's three rows, drawn from rng. When
    // `basis` (m rows) is given it is drawn inside that subspace; if that leaves
    // nothing orthogonal it falls back to the full space.
    function hiddenDirection(frame, D, rng, basis, m, out) {
      var h = out || new Float32Array(D);
      var v = new Float64Array(4 * D);
      for (var i = 0; i < 3 * D; i++) v[i] = frame[i];
      for (var attempt = 0; attempt < 8; attempt++) {
        var useBasis = basis && m > 3 && attempt < 4;
        if (useBasis) drawInBasis(v, 3 * D, D, rng, basis, m);
        else rng.fillGauss(v, 3 * D, D);
        var before = sqNorm(v, 3 * D, D);
        removeSpan(v, 3 * D, v, 3, D);
        var nn = sqNorm(v, 3 * D, D);
        if (nn > 1e-12 * before && nn > 0) return scaleInto(h, v, 3 * D, D, 1 / Math.sqrt(nn));
      }
      if (D <= 3) throw new RangeError("no hidden direction exists when the dimension is three or less");
      orthonormalize(v, 4, D);
      for (var d8 = 0; d8 < D; d8++) h[d8] = v[3 * D + d8];
      return h;
    }

    // h = v[vo .. vo + D) * inv. Returns h.
    function scaleInto(h, v, vo, D, inv) {
      for (var d = 0; d < D; d++) h[d] = v[vo + d] * inv;
      return h;
    }

    // v[vo .. vo + D) = a Gaussian combination of the m rows of basis.
    function drawInBasis(v, vo, D, rng, basis, m) {
      for (var d = 0; d < D; d++) v[vo + d] = 0;
      for (var j = 0; j < m; j++) {
        var g = rng.gauss();
        for (var d2 = 0; d2 < D; d2++) v[vo + d2] += g * basis[j * D + d2];
      }
    }

    // The eased quarter turn of the reference: theta = (pi/2)(u - sin(2 pi u)/(2 pi)).
    function swapAngle(u) {
      var x = Math.min(Math.max(u, 0), 1);
      return (Math.PI / 2) * (x - Math.sin(TAU * x) / TAU);
    }

    // Pure swap step: copy `start` to out and replace row `axis` with
    // cos(theta) * start[axis] + sin(theta) * hidden, theta = swapAngle(u).
    // At u >= 1 the row is exactly `hidden`.
    function swapStep(start, axis, hidden, u, D, out) {
      var F = out || new Float32Array(3 * D);
      if (F !== start) for (var i = 0; i < 3 * D; i++) F[i] = start[i];
      var o = axis * D;
      if (u >= 1) {
        for (var d = 0; d < D; d++) F[o + d] = hidden[d];
      } else {
        var th = swapAngle(u);
        var c = Math.cos(th);
        var s = Math.sin(th);
        for (var d2 = 0; d2 < D; d2++) F[o + d2] = c * start[o + d2] + s * hidden[d2];
      }
      return F;
    }

    // A schedule of swaps: during cycle c = floor(t / period), axis c mod 3
    // turns a quarter turn into a hidden direction drawn from the stream
    // mixSeed(seed ^ SALT_SWAP, c). frameAt(t) is a pure function of (frame0, seed, period,
    // basis, t); when time goes backwards it replays cycle starts from the nearest
    // kept one (bounded memory: at most 33 kept frames).
    // opts: { seed (0), period (3.4 s, the reference's), basis, basisRows }
    var SWAP_CHECKPOINT_SPACING = 16; // cycles between kept cycle starts at first
    var SWAP_CHECKPOINTS = 32;
    function makeSwapTour(frame0, D, opts) {
      checkDim(D);
      if (D < 4) throw new RangeError("axis swaps need a dimension of at least four");
      var o = opts || {};
      var seed = toSeed(o.seed === undefined ? 0 : o.seed);
      var period = o.period === undefined ? 3.4 : o.period;
      if (!above(period, 0)) throw new RangeError("period must be positive");
      var basis = o.basis || null;
      var basisRows = 0;
      if (basis) {
        basisRows = o.basisRows;
        if (!(basisRows >= 3 && basisRows <= D) || Math.floor(basisRows) !== basisRows || basis.length !== basisRows * D) {
          throw new RangeError("makeSwapTour: basis needs basisRows (3..dimension) with basis.length = basisRows * dimension");
        }
      }
      var first = new Float32Array(3 * D);
      for (var i = 0; i < 3 * D; i++) first[i] = frame0[i];
      orthonormalize(first, 3, D);
      var start = new Float32Array(first);
      var hidden = new Float32Array(D);
      var cycle = -1;
      // Cycle starts kept so that a backward seek replays from the nearest one, not
      // from frame0: at most SWAP_CHECKPOINTS (besides cycle 0), spaced further
      // apart as the tour goes on. A replay from one gives the same bits as a
      // replay from frame0 (the same steps on the same values).
      var marks = [{ c: 0, start: first }];
      var spacing = SWAP_CHECKPOINT_SPACING;
      var steps = 0; // swap steps computed in all, for tests

      function keep() {
        if (cycle % spacing !== 0) return;
        var at = marks.length;
        while (at > 0 && marks[at - 1].c > cycle) at--;
        if (marks[at - 1].c === cycle) return;
        marks.splice(at, 0, { c: cycle, start: new Float32Array(start) });
        if (marks.length > SWAP_CHECKPOINTS + 1) {
          spacing *= 2;
          marks = marks.filter(function (m) {
            return m.c % spacing === 0;
          });
        }
      }

      function enterCycle(c) {
        var near = marks[0];
        for (var i = marks.length - 1; i >= 0; i--) {
          if (marks[i].c <= c) {
            near = marks[i];
            break;
          }
        }
        if (c < cycle || cycle < 0 || near.c > cycle) {
          start.set(near.start);
          cycle = near.c;
          hiddenDirection(start, D, makeRandom(mixSeed(seed ^ SALT_SWAP, cycle)), basis, basisRows, hidden);
        }
        while (cycle < c) {
          swapStep(start, cycle % 3, hidden, 1, D, start);
          orthonormalize(start, 3, D);
          cycle++;
          steps++;
          hiddenDirection(start, D, makeRandom(mixSeed(seed ^ SALT_SWAP, cycle)), basis, basisRows, hidden);
          keep();
        }
      }

      function stateAt(t) {
        if (typeof t !== "number" || !Number.isFinite(t)) throw new RangeError("time must be a finite number");
        var x = t < 0 ? 0 : t / period;
        var c = Math.floor(x);
        enterCycle(c);
        return { cycle: c, axis: c % 3, u: x - c };
      }

      function frameAt(t, out) {
        var st = stateAt(t);
        return swapStep(start, st.axis, hidden, st.u, D, out || new Float32Array(3 * D));
      }

      return {
        kind: "axis-swap",
        seed: seed,
        period: period,
        dimension: D,
        stateAt: stateAt,
        frameAt: frameAt,
        hiddenAt: function (t) {
          stateAt(t);
          return new Float32Array(hidden);
        },
        steps: function () {
          return steps;
        },
        checkpoints: function () {
          return marks.length;
        },
      };
    }

    // ----- true nearest neighbours -------------------------------------------

    // Exact k nearest neighbours by Euclidean distance in the full D-dimensional
    // space, among the first `limit` points (default N). Ties go to the lower
    // index. Cost: O(limit^2 * D) multiply-adds in total, done row by row so a
    // caller can spread it over many slices with step(rows), or a part of a row
    // at a time with stepPart(candidates): one query row is up to limit * D
    // multiply-adds (a million for 1,000 points in 1,024-d), too long for one
    // unit on a device that runs JavaScript slowly. The candidates of a row are
    // tried in the same order however it is sliced, so the result is the same.
    // Returns a stepper { k, count, indices: Int32Array(count*k),
    // distances: Float32Array(count*k), next, done, step(rows) -> done,
    // stepPart(candidates) -> done }.
    function makeKnn(X, N, D, k, opts) {
      checkData(X, N, D);
      var o = opts || {};
      var S = o.limit === undefined ? N : Math.max(0, Math.min(N, toInt32(o.limit)));
      var K = Math.max(0, Math.min(toInt32(k), S - 1));
      var indices = new Int32Array(S * K);
      var distances = new Float32Array(S * K);
      var bestD = new Float64Array(K + 1);
      var bestI = new Int32Array(K + 1);
      // With k = 0 there is nothing to find: the stepper starts finished.
      var state = { k: K, count: S, dimension: D, indices: indices, distances: distances, next: 0, done: false };
      if (K === 0) {
        state.next = S;
        state.done = true;
      }

      // The row in progress (state.next): the next candidate and how many of
      // the best are filled.
      var rowAt = 0;
      var filled = 0;

      // Up to `count` more candidates of row i; true once the row is written.
      function rowPart(i, count) {
        var oi = i * D;
        var stop = Math.min(S, rowAt + count);
        for (var j = rowAt; j < stop; j++) {
          if (j === i) continue;
          var bound = filled === K ? bestD[K - 1] : Infinity;
          var s = partialSqDistance(X, oi, j * D, D, bound);
          if (s > bound || (filled === K && s === bound && j > bestI[K - 1])) continue;
          // insert j at the end (or over the last when full), keeping order
          insertBest(bestD, bestI, Math.min(filled, K - 1), s, j);
          if (filled < K) filled++;
        }
        rowAt = stop;
        if (stop < S) return false;
        for (var q = 0; q < K; q++) {
          indices[i * K + q] = bestI[q];
          distances[i * K + q] = Math.sqrt(bestD[q]);
        }
        rowAt = 0;
        filled = 0;
        return true;
      }

      state.step = function (rows) {
        var r = rows === undefined ? S : Math.max(1, toInt32(rows));
        if (state.done) return true;
        var stop = Math.min(S, state.next + r);
        for (var i = state.next; i < stop; i++) rowPart(i, S);
        state.next = stop;
        state.done = stop >= S;
        return state.done;
      };
      // Up to `candidates` more candidates of the row in progress (at least one).
      state.stepPart = function (candidates) {
        if (state.done) return true;
        var c = candidates === undefined ? S : Math.max(1, toInt32(candidates));
        if (rowPart(state.next, c)) {
          state.next++;
          state.done = state.next >= S;
        }
        return state.done;
      };
      return state;
    }

    // Squared distance between the rows of X at offsets oi and oj, summed in
    // index order in blocks of 64 values, with an exact early exit: once the
    // running sum exceeds `bound` (the current k-th best) after a block, the
    // row cannot enter the list and the partial sum is returned.
    function partialSqDistance(X, oi, oj, D, bound) {
      var s = 0;
      var d = 0;
      while (d < D) {
        var end = Math.min(d + 64, D);
        for (; d < end; d++) {
          var t = X[oi + d] - X[oj + d];
          s += t * t;
        }
        if (s > bound) break;
      }
      return s;
    }

    // Put (s, j) at position `pos` of the lists of (distance, index) pairs,
    // first moving up every pair before it that sorts after it, so the lists
    // stay ascending (distance first, then index).
    function insertBest(bestD, bestI, pos, s, j) {
      var at = pos;
      while (at > 0 && (bestD[at - 1] > s || (bestD[at - 1] === s && bestI[at - 1] > j))) {
        bestD[at] = bestD[at - 1];
        bestI[at] = bestI[at - 1];
        at--;
      }
      bestD[at] = s;
      bestI[at] = j;
    }

    // All at once: makeKnn(...).step() to completion.
    function knn(X, N, D, k, opts) {
      var s = makeKnn(X, N, D, k, opts);
      s.step();
      return s;
    }

    // ----- local frames and alignment (Wander) ------------------------------

    // Three axes fitted to a neighbourhood: the top three principal directions
    // of the points `ids` (the point itself and its neighbours), from their
    // Gram matrix. Deterministic. Returns Float32Array(3 * D), orthonormal.
    // ids must be integers in 0..N-1 (at least one); anything else is a caller
    // bug and throws RangeError.
    function localFrame(X, N, D, ids, out) {
      checkLocalFrame(X, N, D, ids);
      return runAll(localFrameGen(X, N, D, ids, out, NO_PAUSE));
    }

    // The same as a stepper whose result is localFrame's frame, bit for bit.
    function makeLocalFrame(X, N, D, ids, out) {
      checkLocalFrame(X, N, D, ids);
      var M = ids.length;
      var wk = new Tracker(M * M * D + 4 * M * D + 50 * M * M * M);
      return genStepper(localFrameGen(X, N, D, ids, out, wk), wk);
    }

    function checkLocalFrame(X, N, D, ids) {
      checkData(X, N, D);
      var M = ids.length;
      if (!atLeast(M, 1)) throw new RangeError("localFrame needs at least one point id");
      for (var q = 0; q < M; q++) {
        var id = ids[q];
        if (!(id >= 0 && id < N) || Math.floor(id) !== id) {
          throw new RangeError("localFrame: point id " + id + " is outside 0.." + (N - 1));
        }
      }
    }

    // The rows `ids` of X, centred on their own mean (accumulated in double
    // precision), as a Float64Array(ids.length * D).
    function centredRows(X, D, ids) {
      var M = ids.length;
      var mean = new Float64Array(D);
      for (var a = 0; a < M; a++) {
        var oa = ids[a] * D;
        for (var d = 0; d < D; d++) mean[d] += X[oa + d];
      }
      for (var d1 = 0; d1 < D; d1++) mean[d1] /= M;
      var Yl = new Float64Array(M * D);
      for (var a2 = 0; a2 < M; a2++) {
        var oa2 = ids[a2] * D;
        for (var d2 = 0; d2 < D; d2++) Yl[a2 * D + d2] = X[oa2 + d2] - mean[d2];
      }
      return Yl;
    }

    function* localFrameGen(X, N, D, ids, out, wk) {
      var M = ids.length;
      var Yl = centredRows(X, D, ids);
      if (wk.add(2 * M * D)) yield;
      var G = yield* gramGen(Yl, M, D, wk);
      var eig = yield* symmetricEigenGen(G, M, wk);
      var F64 = new Float64Array(3 * D);
      var axes = Math.min(3, M);
      for (var ax = 0; ax < axes; ax++) {
        if (!above(eig.values[ax], 1e-12 * Math.max(eig.values[0], 1e-300))) continue;
        for (var b = 0; b < M; b++) {
          var w = eig.vectors[ax * M + b];
          for (var d3 = 0; d3 < D; d3++) F64[ax * D + d3] += w * Yl[b * D + d3];
        }
        if (wk.add(M * D)) yield;
      }
      orthonormalize(F64, 3, D);
      var F = out || new Float32Array(3 * D);
      for (var i = 0; i < 3 * D; i++) F[i] = F64[i];
      return orthonormalize(F, 3, D);
    }

    var PERMS = [
      [0, 1, 2],
      [0, 2, 1],
      [1, 0, 2],
      [1, 2, 0],
      [2, 0, 1],
      [2, 1, 0],
    ];

    // Ported from the reference: reorder and flip target's axes so that the
    // flight from ref to it twists as little as possible. Ties go to the first
    // permutation in a fixed order. Returns a new Float32Array(3 * D).
    function alignTo(target, ref, D) {
      var m = new Float64Array(9);
      for (var i = 0; i < 3; i++) {
        for (var j = 0; j < 3; j++) {
          var dp = 0;
          for (var d = 0; d < D; d++) dp += target[i * D + d] * ref[j * D + d];
          m[i * 3 + j] = dp;
        }
      }
      var best = PERMS[0];
      var bestScore = -1;
      for (const pr of PERMS) {
        var sc = Math.abs(m[pr[0] * 3]) + Math.abs(m[pr[1] * 3 + 1]) + Math.abs(m[pr[2] * 3 + 2]);
        if (sc > bestScore) {
          bestScore = sc;
          best = pr;
        }
      }
      var out = new Float32Array(3 * D);
      for (var j2 = 0; j2 < 3; j2++) {
        var src = best[j2];
        var sign = m[src * 3 + j2] < 0 ? -1 : 1;
        for (var d2 = 0; d2 < D; d2++) out[j2 * D + d2] = sign * target[src * D + d2];
      }
      return out;
    }

    function smoothstep(u) {
      var x = Math.min(Math.max(u, 0), 1);
      return x * x * (3 - 2 * x);
    }

    // The reference's flight between frames: blend row by row with weight e
    // (0 gives `from`, 1 gives `to`) and re-orthonormalise. Pure.
    function blendFrames(from, to, e, D, out) {
      var F64 = new Float64Array(3 * D);
      for (var i = 0; i < 3 * D; i++) F64[i] = from[i] + (to[i] - from[i]) * e;
      orthonormalize(F64, 3, D);
      var F = out || new Float32Array(3 * D);
      for (var i2 = 0; i2 < 3 * D; i2++) F[i2] = F64[i2];
      return orthonormalize(F, 3, D);
    }

    // ----- group separation ---------------------------------------------------

    // Mean distance between points of different groups divided by mean distance
    // between points of the same group, over all pairs (the probe's measure;
    // 1.0 means no visible grouping). P holds N points of `dim` coordinates.
    // Labels that are "", null or undefined are ungrouped and left out.
    // Returns NaN when there are no within-group or no between-group pairs;
    // Infinity when all same-group pairs coincide but groups are apart; 1 when
    // every grouped point coincides.
    function groupSeparation(P, N, dim, groups) {
      var sums = pairDistanceSums(P, N, dim, groups);
      if (sums.nWithin === 0 || sums.nBetween === 0) return Number.NaN;
      // Every same-group pair coincides: Infinity when the groups are apart,
      // 1 (nothing to see) when everything coincides.
      if (sums.within === 0) return sums.between > 0 ? Infinity : 1;
      return sums.between / sums.nBetween / (sums.within / sums.nWithin);
    }

    function ungrouped(g) {
      return g === "" || g === null || g === undefined;
    }

    // Sums and counts of the distances between grouped points, over all pairs
    // i < j in order, split into same-group and different-group pairs.
    function pairDistanceSums(P, N, dim, groups) {
      var sums = { within: 0, nWithin: 0, between: 0, nBetween: 0 };
      for (var i = 0; i < N; i++) {
        var gi = groups[i];
        if (ungrouped(gi)) continue;
        for (var j = i + 1; j < N; j++) {
          var gj = groups[j];
          if (ungrouped(gj)) continue;
          var dist = Math.sqrt(sqDistance(P, i * dim, j * dim, dim));
          if (gi === gj) {
            sums.within += dist;
            sums.nWithin++;
          } else {
            sums.between += dist;
            sums.nBetween++;
          }
        }
      }
      return sums;
    }

    // Squared distance between the rows of P at offsets oi and oj, summed in index order.
    function sqDistance(P, oi, oj, dim) {
      var s = 0;
      for (var d = 0; d < dim; d++) {
        var t = P[oi + d] - P[oj + d];
        s += t * t;
      }
      return s;
    }

    // Group separation of the data as seen through one frame.
    function frameSeparation(Y, N, D, frame, groups) {
      return groupSeparation(project(Y, N, D, frame, null), N, 3, groups);
    }

    return {
      mulberry32: mulberry32,
      toSeed: toSeed,
      mixSeed: mixSeed,
      makeRandom: makeRandom,
      meanOf: meanOf,
      centre: centre,
      makeCentre: makeCentre,
      totalVariance: totalVariance,
      varianceShare: varianceShare,
      orthonormalize: orthonormalize,
      frameError: frameError,
      randomFrame: randomFrame,
      project: project,
      symmetricEigen: symmetricEigen,
      principalDirections: principalDirections,
      makePrincipalDirections: makePrincipalDirections,
      makeTour: makeTour,
      guidedTour: guidedTour,
      makeGuidedTour: makeGuidedTour,
      hiddenDirection: hiddenDirection,
      swapAngle: swapAngle,
      swapStep: swapStep,
      makeSwapTour: makeSwapTour,
      makeKnn: makeKnn,
      knn: knn,
      localFrame: localFrame,
      makeLocalFrame: makeLocalFrame,
      alignTo: alignTo,
      smoothstep: smoothstep,
      blendFrames: blendFrames,
      groupSeparation: groupSeparation,
      frameSeparation: frameSeparation,
    };
  })();

// ---------------------------------------------------------------------------
// 20-contract.js: data contract loader and validator (schema version 1).
// Pure functions: no file, network or DOM access. See docs/data-contract.md
// (the authority) and js/api/20-contract.md (the interface).
// ---------------------------------------------------------------------------
(function () {
  var SUPPORTED = [1];
  var KIND = "embeddings-tumbler/data";
  var MAX_INT = 9007199254740991;
  var ENDPOINT_NAME = /^[A-Za-z0-9][A-Za-z0-9 _-]{0,63}$/;
  var PLAIN_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;

  var MESSAGES = {
    "wrong-kind":
      'Not an embeddings-tumbler data set: "kind" must be "embeddings-tumbler/data".',
    "schema-version":
      "Data schema version {found} is not supported; this viewer reads schema version {supported}.",
    "invalid-field": 'Field "{field}" is missing or not valid.',
    "vector-file-path":
      'Vector file "{file}" must be a plain file name in the same folder as the data file.',
    "endpoint-is-address":
      '"provenance.endpoint" must name the embedding route, not give a network address.',
    "block-unreadable": 'Vector file "{file}" could not be read.',
    "count-mismatch": '"count" is {count} but the data has {found} point records.',
    "duplicate-id": 'Point id "{id}" appears more than once.',
    "block-length":
      "Vector block is {found} bytes; expected {count} points x {dimension} dimensions x 4 bytes = {expected} bytes.",
    "non-finite": 'Vector of point "{id}" contains a value that is not a finite number.',
    "append-without-base":
      "Cannot append: the view holds no data set yet. Send a full set first.",
    "model-mismatch":
      'Cannot append: model "{found}" differs from the view\'s model "{expected}". One view shows one model.',
    "dimension-mismatch":
      "Cannot append: dimension {found} differs from the view's dimension {expected}.",
    "reduction-mismatch":
      'Cannot append: reduction "{found}" differs from the view\'s reduction "{expected}".',
    "id-exists": 'Cannot append: point id "{id}" is already in the view.',
  };

  function fill(code, values) {
    return MESSAGES[code].replace(/\{(\w+)\}/g, function (m, name) {
      return Object.hasOwn(values || {}, name) ? String(values[name]) : m;
    });
  }

  // The base set is returned with every refusal so the caller keeps what it holds.
  function refuse(code, values, base) {
    return { ok: false, code: code, message: fill(code, values), set: base || null };
  }

  function tag(v) {
    return Object.prototype.toString.call(v);
  }
  function isObject(v) {
    return typeof v === "object" && v !== null && !Array.isArray(v);
  }
  function isInt(v) {
    return typeof v === "number" && Number.isFinite(v) && Math.floor(v) === v && Math.abs(v) <= MAX_INT;
  }
  function isNonEmptyString(v) {
    return typeof v === "string" && v.length > 0;
  }
  function isStringList(v) {
    if (!Array.isArray(v)) return false;
    for (const item of v) if (typeof item !== "string") return false;
    return true;
  }
  function isFloat32Array(v) {
    return tag(v) === "[object Float32Array]";
  }
  function isArrayBuffer(v) {
    return tag(v) === "[object ArrayBuffer]";
  }
  function has(o, k) {
    return Object.hasOwn(o, k);
  }

  function jsonText(v) {
    try {
      var s = JSON.stringify(v);
      return s === undefined ? "missing" : s;
    } catch {
      // JSON.stringify throws for a value it cannot write (a BigInt, a cycle, a
      // throwing toJSON); the message then shows the plain string form instead,
      // and the error itself carries nothing the message needs.
      return String(v);
    }
  }

  // Deep copy of JSON-like data, so the set never shares objects with the host.
  function clone(v) {
    if (Array.isArray(v)) {
      var a = [];
      for (const item of v) a.push(clone(item));
      return a;
    }
    if (v !== null && typeof v === "object") {
      var o = {};
      // defineProperty, not assignment: a key named "__proto__" stays a key.
      for (const key of Object.keys(v)) {
        Object.defineProperty(o, key, { value: clone(v[key]), writable: true, enumerable: true, configurable: true });
      }
      return o;
    }
    return v;
  }

  // Returns the path of the first invalid field, or null. `form` is "memory" or "file".
  // The checks run in the contract's field order; each helper returns the path
  // of its first invalid field, or null to go on to the next.
  function firstInvalidField(d, op, form) {
    return (
      invalidTopField(d, op) ??
      invalidProvenance(d.provenance, op === "append") ??
      invalidReduction(d.reduction, d) ??
      invalidVectors(d.vectors, d, form) ??
      invalidPoints(d.points)
    );
  }

  function invalidTopField(d, op) {
    if (op !== undefined && op !== "replace" && op !== "append") return "op";
    if (!isNonEmptyString(d.model)) return "model";
    if (!isInt(d.dimension) || d.dimension < 1) return "dimension";
    if (!isInt(d.count) || d.count < 0) return "count";
    if (typeof d.text_included !== "boolean") return "text_included";
    return null;
  }

  // Provenance is required, except on an append, where it may be left out.
  function invalidProvenance(p, isAppend) {
    if (p === undefined && isAppend) return null;
    return invalidProvenanceRequired(p) ?? invalidProvenanceOptional(p);
  }

  function invalidProvenanceRequired(p) {
    if (!isObject(p)) return "provenance";
    if (!isNonEmptyString(p.source)) return "provenance.source";
    if (!isNonEmptyString(p.producer)) return "provenance.producer";
    if (typeof p.synthetic !== "boolean") return "provenance.synthetic";
    if (!has(p, "seed") || !(p.seed === null || isInt(p.seed))) return "provenance.seed";
    if (!isStringList(p.limitations)) return "provenance.limitations";
    if (!isStringList(p.uncertain)) return "provenance.uncertain";
    return null;
  }

  function invalidProvenanceOptional(p) {
    if (p.created !== undefined && typeof p.created !== "string") return "provenance.created";
    if (p.endpoint !== undefined && !isNonEmptyString(p.endpoint)) return "provenance.endpoint";
    if (p.params !== undefined && !isObject(p.params)) return "provenance.params";
    return null;
  }

  // The reduction is optional; when given, its fields must be valid and agree
  // with the data's dimension.
  function invalidReduction(r, d) {
    if (r === undefined) return null;
    return invalidReductionField(r) ?? invalidReductionAgreement(r, d);
  }

  function invalidReductionField(r) {
    if (!isObject(r)) return "reduction";
    if (r.kind !== "none" && r.kind !== "rotation" && r.kind !== "top-k") return "reduction.kind";
    if (!isInt(r.source_dimension) || r.source_dimension < 1) return "reduction.source_dimension";
    if (!isInt(r.directions_kept) || r.directions_kept < 1) return "reduction.directions_kept";
    if (
      typeof r.variance_dropped !== "number" ||
      !Number.isFinite(r.variance_dropped) ||
      r.variance_dropped < 0 ||
      r.variance_dropped > 1
    )
      return "reduction.variance_dropped";
    return null;
  }

  // Runs after invalidReductionField and invalidTopField passed, so every value
  // compared here is a finite number (no NaN can make a comparison false both ways).
  function invalidReductionAgreement(r, d) {
    if (r.directions_kept !== d.dimension) return "reduction";
    if (r.kind === "top-k") {
      if (d.dimension >= r.source_dimension || r.variance_dropped >= 1) return "reduction";
    } else if (r.source_dimension !== d.dimension || r.variance_dropped !== 0) {
      return "reduction";
    }
    return null;
  }

  function invalidVectors(v, d, form) {
    if (form === "file") return invalidVectorFile(v, d);
    return isFloat32Array(v) || isArrayBuffer(v) ? null : "vectors";
  }

  function invalidVectorFile(v, d) {
    if (!isObject(v)) return "vectors";
    if (!isNonEmptyString(v.file)) return "vectors.file";
    if (v.dtype !== "float32") return "vectors.dtype";
    if (v.byte_order !== "little") return "vectors.byte_order";
    if (!isInt(v.byte_length) || v.byte_length !== d.count * d.dimension * 4) {
      return "vectors.byte_length";
    }
    return null;
  }

  function invalidPoints(pts) {
    if (!Array.isArray(pts)) return "points";
    for (var i = 0; i < pts.length; i++) {
      var bad = invalidPoint(pts[i]);
      if (bad !== null) return "points[" + i + "]" + bad;
    }
    return null;
  }

  // The invalid field of one point record as a path suffix ("" for the record
  // itself, ".id" and so on), or null.
  function invalidPoint(pt) {
    if (!isObject(pt)) return "";
    if (!isNonEmptyString(pt.id)) return ".id";
    if (typeof pt.label !== "string") return ".label";
    if (pt.group !== undefined && typeof pt.group !== "string") return ".group";
    if (pt.metadata !== undefined && !isObject(pt.metadata)) return ".metadata";
    return null;
  }

  // Checks 1 to 7 of the contract (everything that needs no vector block).
  function checkRecordsInner(d, form, base) {
    if (!isObject(d) || d.kind !== KIND) return refuse("wrong-kind", {}, base);
    if (!isInt(d.schema_version) || !SUPPORTED.includes(d.schema_version)) {
      return refuse(
        "schema-version",
        {
          found: has(d, "schema_version") ? jsonText(d.schema_version) : "missing",
          supported: SUPPORTED.join(", "),
        },
        base
      );
    }
    var bad = firstInvalidField(d, d.op, form);
    if (bad !== null) return refuse("invalid-field", { field: bad }, base);
    if (form === "file" && !PLAIN_NAME.test(d.vectors.file)) {
      return refuse("vector-file-path", { file: d.vectors.file }, base);
    }
    // After firstInvalidField, provenance is either an object or (on an append) absent.
    if (d.provenance?.endpoint !== undefined && !ENDPOINT_NAME.test(d.provenance.endpoint)) {
      return refuse("endpoint-is-address", {}, base);
    }
    if (d.count !== d.points.length) {
      return refuse("count-mismatch", { count: d.count, found: d.points.length }, base);
    }
    var seen = Object.create(null); // ids are untrusted: no inherited names
    for (const point of d.points) {
      var id = point.id;
      if (has(seen, id)) return refuse("duplicate-id", { id: id }, base);
      seen[id] = true;
    }
    return { ok: true };
  }

  var LITTLE = new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;

  // A fresh Float32Array of the block's values (little-endian bytes for an ArrayBuffer).
  function readValues(block) {
    if (isFloat32Array(block)) {
      return new Float32Array(block); // copies the view's own range only
    }
    var n = Math.floor(block.byteLength / 4);
    var out = new Float32Array(n);
    if (LITTLE) {
      out.set(new Float32Array(block, 0, n));
    } else {
      var dv = new DataView(block);
      for (var i = 0; i < n; i++) out[i] = dv.getFloat32(i * 4, true);
    }
    return out;
  }

  // Appends write into spare capacity instead of copying the base's vectors.
  // A set's `vectors` is a Float32Array view of exactly count * dimension
  // values over a buffer that may be longer. `head` maps a buffer to the end
  // (in values) of the newest view over it. An append onto the set whose view
  // ends at the head writes its rows just after it and returns a longer view
  // over the same buffer: the older, shorter view is untouched, so the older
  // set stays valid. An append onto any other set (a fork, or a set that never
  // had spare room) copies into a new buffer of twice the needed length, so
  // the cost of appends is proportional to the points added, amortised.
  var head = typeof WeakMap === "function" ? new WeakMap() : null;

  function appendValues(baseValues, values) {
    var n0 = baseValues.length;
    var n1 = n0 + values.length;
    var buf = baseValues.buffer;
    var off = baseValues.byteOffset / 4;
    if (head?.get(buf) === off + n0 && off + n1 <= buf.byteLength / 4) {
      var grown = new Float32Array(buf, baseValues.byteOffset, n1);
      grown.set(values, n0);
      head.set(buf, off + n1);
      return grown;
    }
    var fresh = new Float32Array(Math.max(2 * n1, 64));
    fresh.set(baseValues, 0);
    fresh.set(values, n0);
    if (head) head.set(fresh.buffer, n1);
    return fresh.subarray(0, n1);
  }

  function copyPoints(pts) {
    var out = [];
    for (const p of pts) {
      out.push({
        id: p.id,
        label: p.label,
        group: p.group === undefined ? "" : p.group,
        metadata: p.metadata === undefined ? {} : clone(p.metadata),
      });
    }
    return out;
  }

  function reductionOf(d) {
    if (d.reduction !== undefined) return clone(d.reduction);
    return {
      kind: "none",
      source_dimension: d.dimension,
      directions_kept: d.dimension,
      variance_dropped: 0,
    };
  }

  function idsOf(points) {
    return points.map(function (p) {
      return p.id;
    });
  }

  // Checks 9 to 11 and the merge. `d` has already passed checks 1 to 7.
  function finishInner(d, block, base) {
    var byteLength = block.byteLength;
    var expected = d.count * d.dimension * 4;
    if (byteLength !== expected) {
      return refuse(
        "block-length",
        { found: byteLength, count: d.count, dimension: d.dimension, expected: expected },
        base
      );
    }
    var values = readValues(block);
    var bad = firstNonFinite(values);
    if (bad >= 0) {
      var row = Math.floor(bad / d.dimension);
      return refuse("non-finite", { id: d.points[row].id }, base);
    }

    var points = copyPoints(d.points);
    var red = reductionOf(d);
    if (d.op === "append") return mergeAppend(d, values, points, red, base);

    return {
      ok: true,
      set: {
        schema_version: 1,
        model: d.model,
        dimension: d.dimension,
        count: points.length,
        text_included: d.text_included,
        provenance: clone(d.provenance),
        reduction: red,
        vectors: values,
        ids: idsOf(points),
        points: points,
      },
    };
  }

  // Index of the first value that is not a finite number, or -1.
  function firstNonFinite(values) {
    for (var i = 0; i < values.length; i++) if (!Number.isFinite(values[i])) return i;
    return -1;
  }

  // Check 11 (an append agrees with the set it extends) and the merge.
  function mergeAppend(d, values, points, red, base) {
    if (!isObject(base)) return refuse("append-without-base", {}, null);
    if (d.model !== base.model) {
      return refuse("model-mismatch", { found: d.model, expected: base.model }, base);
    }
    if (d.dimension !== base.dimension) {
      return refuse("dimension-mismatch", { found: d.dimension, expected: base.dimension }, base);
    }
    if (red.kind !== base.reduction.kind) {
      return refuse("reduction-mismatch", { found: red.kind, expected: base.reduction.kind }, base);
    }
    var held = Object.create(null);
    for (const p of base.points) held[p.id] = true;
    for (const p of points) {
      if (has(held, p.id)) return refuse("id-exists", { id: p.id }, base);
    }
    var merged = appendValues(base.vectors, values);
    var allPoints = base.points.concat(points);
    return {
      ok: true,
      set: {
        schema_version: 1,
        model: base.model,
        dimension: base.dimension,
        count: allPoints.length,
        text_included: base.text_included || d.text_included,
        provenance: base.provenance,
        reduction: base.reduction,
        vectors: merged,
        ids: idsOf(allPoints),
        points: allPoints,
      },
    };
  }

  // Never throws into the caller: an unexpected failure becomes a refusal.
  function guarded(base, fn) {
    try {
      return fn();
    } catch {
      // Whatever threw (a hostile getter or proxy in the host's data, a value no
      // check foresaw), the caller gets a refusal, never the exception; the
      // refusal is the whole report, so the error itself is not kept.
      return refuse("invalid-field", { field: "(unreadable data)" }, base);
    }
  }

  // A file-form descriptor carrying its fetched block: { file, dtype, byte_order,
  // byte_length, data }, as a host or a shell hands update() a data file it fetched.
  function isDescriptorWithBlock(v) {
    return isObject(v) && !isFloat32Array(v) && !isArrayBuffer(v) && has(v, "data");
  }

  // validate(data, base): in-memory form. Returns { ok: true, set } or
  // { ok: false, code, message, set: base || null }. When `vectors` is the file
  // form's descriptor with the fetched block in `vectors.data`, the data is checked
  // as the file form (the descriptor's dtype, byte order and declared length too),
  // exactly as finish() would.
  function validate(data, base) {
    return guarded(base, function () {
      if (isObject(data) && isDescriptorWithBlock(data.vectors)) return finishFile(data, data.vectors.data, base);
      var r = checkRecordsInner(data, "memory", base);
      if (!r.ok) return r;
      return finishInner(data, data.vectors, base);
    });
  }

  // checkRecords(records): file form, checks 1 to 7. { ok: true, file } or a refusal.
  function checkRecords(records, base) {
    return guarded(base, function () {
      var r = checkRecordsInner(records, "file", base);
      if (!r.ok) return r;
      return { ok: true, file: records.vectors.file };
    });
  }

  // finish(records, block, base): file form, with the fetched block (ArrayBuffer or
  // Float32Array). Runs checks 1 to 11. A missing or wrong-typed block is block-unreadable.
  function finish(records, block, base) {
    return guarded(base, function () {
      return finishFile(records, block, base);
    });
  }

  function finishFile(records, block, base) {
    var r = checkRecordsInner(records, "file", base);
    if (!r.ok) return r;
    if (!isArrayBuffer(block) && !isFloat32Array(block)) {
      return refuse("block-unreadable", { file: records.vectors.file }, base);
    }
    return finishInner(records, block, base);
  }

  function siblingUrl(jsonUrl, file) {
    var s = String(jsonUrl).split("#")[0].split("?")[0];
    var cut = s.lastIndexOf("/");
    return cut < 0 ? file : s.slice(0, cut + 1) + file;
  }

  // loadFile(jsonUrl, fetchFn, base): file form. fetchFn is fetch-like: it takes a URL
  // string and returns a promise of { ok, json(), arrayBuffer() }. The block is fetched
  // beside the JSON file only. Resolves (never rejects) to the same result as validate.
  function loadFile(jsonUrl, fetchFn, base) {
    return Promise.resolve()
      .then(function () {
        return fetchFn(String(jsonUrl));
      })
      .then(function (res) {
        if (!res?.ok) throw new Error("unreadable");
        return res.json();
      })
      .then(
        function (records) {
          var c = checkRecords(records, base);
          if (!c.ok) return c;
          return loadBlock(records, jsonUrl, c.file, fetchFn, base);
        },
        function () {
          // The data file itself could not be fetched or is not JSON: the document defines
          // no code for this; it is reported as "not a data set".
          return refuse("wrong-kind", {}, base);
        }
      )
      .catch(function () {
        return refuse("wrong-kind", {}, base);
      });
  }

  // The second half of loadFile, once the records have passed checks 1 to 7: fetch
  // the block `file` beside the JSON file and run finish(). Resolves (never
  // rejects); any failure to fetch or read the block is block-unreadable.
  function loadBlock(records, jsonUrl, file, fetchFn, base) {
    return Promise.resolve()
      .then(function () {
        return fetchFn(siblingUrl(jsonUrl, file));
      })
      .then(function (res) {
        if (!res?.ok) throw new Error("unreadable");
        return res.arrayBuffer();
      })
      .then(
        function (buf) {
          return finish(records, buf, base);
        },
        function () {
          return refuse("block-unreadable", { file: file }, base);
        }
      );
  }

  ET.contract = {
    supportedVersions: SUPPORTED.slice(),
    messages: MESSAGES,
    validate: validate,
    checkRecords: checkRecords,
    finish: finish,
    loadFile: loadFile,
  };
})();
// ---------------------------------------------------------------------------
// 24-search.js: ranking one search (ET.search). Pure functions, no DOM, no
// network. See js/api/24-search.md (the interface) and docs/search-interface.md.
//
// The measure is cosine distance (1 minus cosine), in double precision over every
// dimension. Ties go to the lower point index. On-screen position is never an
// input. The long scans are steppers in the convention of 10-math.js: written once
// as generators that pause between small pieces of work, so the result is the same
// however the work was sliced.
// ---------------------------------------------------------------------------
(function () {
  var DEFAULT_K = 8;
  var MIN_K = 3;
  var MAX_K = 100;
  var DEFAULT_CANDIDATES = 50;
  var MAX_CANDIDATES = 100;
  var DEFAULT_TOP = 20;
  var PREFIX_MIN = 3;
  var MEASURE = "cosine";
  var MEASURE_TEXT = "cosine distance (1 minus cosine similarity)";

  var MESSAGES = Object.freeze({
    "no-data": "There is no data to search yet.",
    "reduction-not-searchable":
      'Cannot search by embedding: the vectors in this data set were changed after embedding (reduction "{kind}"), and the file does not carry what is needed to change a query the same way. Search among the loaded points still works.',
    "query-model-missing":
      'Cannot search: the embedder did not say which model made the query vector, so it cannot be checked against the data\'s model "{expected}".',
    "query-model-mismatch":
      'Cannot search: the query was embedded by model "{found}" but the data was embedded by model "{expected}". One view compares one model.',
    "query-not-vector": "Cannot search: the query is not a list of numbers.",
    "query-dimension-mismatch":
      "Cannot search: the query vector has dimension {found} but the data has dimension {expected}.",
    "query-non-finite":
      "Cannot search: the query vector holds a value that is not a finite number (at position {index}).",
    "query-zero":
      "Cannot search: the query vector is all zeros, so it has no direction to compare.",
    "point-unknown": 'No point with id "{id}" is in the view.',
    "empty-query": "Nothing to search for: the query has no words.",
    "words-none":
      "None of these words matches a label or text among the loaded points: {words}.",
    "rerank-malformed":
      "The reranker's answer was not one score per candidate; the results stay in embedding order.",
  });

  // ----- messages and small checks -------------------------------------------

  function format(code, values) {
    if (!Object.hasOwn(MESSAGES, code)) throw new RangeError("unknown refusal code: " + code);
    return MESSAGES[code].replace(/\{(\w+)\}/g, function (whole, name) {
      return values && Object.hasOwn(values, name) ? String(values[name]) : whole;
    });
  }

  function refuse(code, values) {
    return { ok: false, code: code, message: format(code, values) };
  }

  // A count rounded and clamped into MIN_K .. most; not a finite number gives `fallback`.
  function clampCount(n, most, fallback) {
    if (typeof n !== "number" || !Number.isFinite(n)) return fallback;
    return Math.min(most, Math.max(MIN_K, Math.round(n)));
  }

  function clampK(k) {
    return clampCount(k, MAX_K, DEFAULT_K);
  }

  function clampCandidates(n) {
    return clampCount(n, MAX_CANDIDATES, DEFAULT_CANDIDATES);
  }

  // How many reranked candidates are kept: MIN_K .. the clamped number of candidates.
  function clampTop(top, candidates) {
    var most = clampCandidates(candidates);
    return clampCount(top, most, Math.min(DEFAULT_TOP, most));
  }

  function hasPoints(set) {
    return !!set && set.count > 0 && !!set.vectors && set.vectors.length >= set.count * set.dimension;
  }

  function checkSameSpace(set) {
    if (!hasPoints(set)) return refuse("no-data");
    var kind = set.reduction?.kind ?? "none";
    if (kind === "none") return { ok: true };
    var r = refuse("reduction-not-searchable", { kind: kind });
    r.kind = kind;
    return r;
  }

  function isNumericArray(v) {
    return Array.isArray(v) || v instanceof Float32Array || v instanceof Float64Array;
  }

  function allNumbers(v) {
    for (const x of v) if (typeof x !== "number") return false;
    return true;
  }

  function firstNonFinite(v) {
    for (var i = 0; i < v.length; i++) if (!Number.isFinite(v[i])) return i;
    return -1;
  }

  function isAllZero(v) {
    for (const x of v) if (x !== 0) return false;
    return true;
  }

  function checkModel(set, query) {
    var model = query?.model;
    if (typeof model !== "string" || model === "") {
      return refuse("query-model-missing", { expected: set.model });
    }
    if (model !== set.model) {
      return refuse("query-model-mismatch", { found: model, expected: set.model });
    }
    return null;
  }

  function checkVector(set, raw) {
    if (!isNumericArray(raw) || !allNumbers(raw)) return refuse("query-not-vector");
    if (raw.length !== set.dimension) {
      return refuse("query-dimension-mismatch", { found: raw.length, expected: set.dimension });
    }
    var vector = Float32Array.from(raw);
    var bad = firstNonFinite(vector);
    if (bad >= 0) return refuse("query-non-finite", { index: bad });
    if (isAllZero(vector)) return refuse("query-zero");
    return { ok: true, vector: vector };
  }

  function checkQuery(set, query) {
    var same = checkSameSpace(set);
    if (!same.ok) return same;
    return checkModel(set, query) ?? checkVector(set, query?.vector);
  }

  // ----- sliced work (the convention of 10-math.js) --------------------------

  var UNIT = 1 << 20; // multiply-adds per unit at most
  var CHECK = 1 << 12; // multiply-adds between two looks at the clock (as in 10-math.js)
  var SLICE_MS = 1;

  function clockNow() {
    if (typeof performance !== "undefined" && typeof performance?.now === "function") {
      return performance.now();
    }
    return Date.now();
  }

  // Counts work done and says when a unit is over.
  function Tracker(total) {
    this.total = total > 0 ? total : 1;
    this.done = 0;
    this.acc = 0;
    this.nextCheck = CHECK;
    this.t0 = 0;
  }
  Tracker.prototype.add = function (cost) {
    this.done += cost;
    this.acc += cost;
    if (this.acc < this.nextCheck) return false;
    if (this.acc >= UNIT || clockNow() - this.t0 >= SLICE_MS) {
      this.acc = 0;
      this.nextCheck = CHECK;
      return true;
    }
    this.nextCheck = this.acc + CHECK;
    return false;
  };

  // { step(budgetMs?) -> done, done, progress, result }: step(budgetMs) runs units
  // until budgetMs ms have passed (at least one); step() runs to the end.
  function genStepper(gen, tracker) {
    var st = { done: false, progress: 0, result: null, step: null };
    st.step = function (budgetMs) {
      if (st.done) return true;
      var limit = budgetMs === undefined ? Infinity : budgetMs;
      var start = clockNow();
      var first = true;
      while (first || limit === Infinity || clockNow() - start < limit) {
        first = false;
        tracker.t0 = clockNow();
        var r = gen.next();
        if (r.done) {
          st.done = true;
          st.result = r.value;
          st.progress = 1;
          return true;
        }
      }
      st.progress = Math.min(0.99, tracker.done / tracker.total);
      return false;
    };
    return st;
  }

  function runToEnd(stepper) {
    stepper.step();
    return stepper.result;
  }

  // ----- the exact scan -------------------------------------------------------

  function isF32(v, n) {
    return v instanceof Float32Array && v.length === n;
  }

  // Row sums for one point: dot with the query and squared length, plain and
  // (when scaled) with every dimension multiplied by the scale.
  function rowPlain(V, o, D, q, acc) {
    var dot = 0;
    var nn = 0;
    for (var d = 0; d < D; d++) {
      var x = V[o + d];
      dot += x * q[d];
      nn += x * x;
    }
    acc.dot = dot;
    acc.nn = nn;
  }

  function rowScaled(V, o, D, q, s2, qs2, acc) {
    var dot = 0;
    var nn = 0;
    var dotS = 0;
    var nnS = 0;
    for (var d = 0; d < D; d++) {
      var x = V[o + d];
      var xx = x * x;
      dot += x * q[d];
      nn += xx;
      dotS += x * qs2[d];
      nnS += xx * s2[d];
    }
    acc.dot = dot;
    acc.nn = nn;
    acc.dotS = dotS;
    acc.nnS = nnS;
  }

  // Cosine distance from a dot product, a squared row length and the query's length.
  function cosineDistance(dot, nn, qn) {
    if (nn === 0 || qn === 0) return 1; // no direction: similarity 0
    var c = dot / (Math.sqrt(nn) * qn);
    return 1 - Math.min(1, Math.max(-1, c));
  }

  // The best P points so far, ordered by (distance, index); rows arrive by index.
  function Pool(P) {
    this.cap = P;
    this.n = 0;
    this.dist = new Float64Array(P);
    this.idx = new Int32Array(P);
  }
  Pool.prototype.offer = function (i, d) {
    var j;
    if (this.n === this.cap) {
      // Not "!(d < worst)": a NaN distance must still be turned away.
      if (d < this.dist[this.cap - 1]) j = this.cap - 1;
      else return;
    } else {
      j = this.n++;
    }
    while (j > 0 && this.dist[j - 1] > d) {
      this.dist[j] = this.dist[j - 1];
      this.idx[j] = this.idx[j - 1];
      j--;
    }
    this.dist[j] = d;
    this.idx[j] = i;
  };

  function sumSquares(q, w) {
    var s = 0;
    for (var d = 0; d < q.length; d++) s += w ? q[d] * q[d] * w[d] : q[d] * q[d];
    return s;
  }

  function squares(scale) {
    var s2 = new Float64Array(scale.length);
    for (var d = 0; d < scale.length; d++) s2[d] = scale[d] * scale[d];
    return s2;
  }

  // How many candidates come before (dist, idx) in the order by (distance, index);
  // `mask` null means every point is a candidate.
  function countBefore(distances, dist, idx, mask) {
    var c = 0;
    for (var j = 0; j < distances.length; j++) {
      if (mask?.[j] === 0) continue;
      if (distances[j] < dist || (distances[j] === dist && j < idx)) c++;
    }
    return c;
  }

  function makeHit(set, index, distance, embeddingRank, plainDistance, plainRank) {
    return {
      index: index,
      id: set.ids[index],
      distance: distance,
      similarity: 1 - distance,
      embeddingRank: embeddingRank,
      rank: embeddingRank,
      moved: 0,
      score: null,
      plainDistance: plainDistance,
      plainRank: plainRank,
      gap: 0,
    };
  }

  function buildRanking(set, counts, scaled, pool, scan, plainRanks) {
    var distances = scan.distances;
    var plainDistances = scan.plainDistances;
    var nearest = [];
    for (var r = 0; r < pool.n; r++) {
      var i = pool.idx[r];
      var plainD = scaled ? plainDistances[i] : pool.dist[r];
      nearest.push(makeHit(set, i, pool.dist[r], r + 1, plainD, scaled ? plainRanks[r] : r + 1));
    }
    var hits = nearest.slice(0, counts.k);
    var near = hits.length ? hits[0].distance : null;
    var radius = hits.length ? hits.at(-1).distance : null;
    for (const hit of hits) hit.gap = hit.distance - near;
    return {
      measure: MEASURE,
      k: counts.k,
      candidates: counts.candidates,
      top: counts.top,
      count: set.count,
      named: scan.named,
      scaled: scaled,
      hits: hits,
      pool: nearest.slice(0, counts.candidates),
      near: near,
      radius: radius,
      distances: distances,
      plainDistances: scaled ? plainDistances : null,
    };
  }

  // What the scan needs besides the vectors: the query as doubles with its
  // length, and (with a scale) the squared scale, the scaled query and its length.
  function scanSetup(q32, scale, D) {
    var q = Float64Array.from(q32);
    var setup = { q: q, qn: Math.sqrt(sumSquares(q, null)), s2: null, qs2: null, qnS: 0 };
    if (scale) {
      var s2 = squares(scale);
      var qs2 = new Float64Array(D);
      for (var e = 0; e < D; e++) qs2[e] = q[e] * s2[e];
      setup.s2 = s2;
      setup.qs2 = qs2;
      setup.qnS = Math.sqrt(sumSquares(q, s2));
    }
    return setup;
  }

  // One row's distance (and, when scaled, its plain distance as well).
  function scanRow(V, i, D, setup, acc, distances, plainDistances) {
    if (plainDistances) {
      rowScaled(V, i * D, D, setup.q, setup.s2, setup.qs2, acc);
      plainDistances[i] = cosineDistance(acc.dot, acc.nn, setup.qn);
      distances[i] = cosineDistance(acc.dotS, acc.nnS, setup.qnS);
    } else {
      rowPlain(V, i * D, D, setup.q, acc);
      distances[i] = cosineDistance(acc.dot, acc.nn, setup.qn);
    }
  }

  // The plain rank of each pooled point among the candidates (a scaled search only).
  function* pooledPlainRanks(pool, plainDistances, mask, N, wk) {
    var plainRanks = new Int32Array(pool.n);
    for (var r = 0; r < pool.n; r++) {
      var pi = pool.idx[r];
      plainRanks[r] = 1 + countBefore(plainDistances, plainDistances[pi], pi, mask);
      if (wk.add(N)) yield;
    }
    return plainRanks;
  }

  // ----- named points: the candidates for results ----------------------------

  // Readable text: a string with something other than white space that is not the id.
  function readable(value, id) {
    return typeof value === "string" && value !== id && /\S/.test(value);
  }

  // The text of a point that is more than its id, or null.
  function namedText(set, index) {
    var point = set.points?.[index];
    var id = set.ids[index];
    var text = point?.metadata?.text;
    if (readable(text, id)) return text;
    if (readable(point?.label, id)) return point.label;
    return null;
  }

  function isNamed(set, index) {
    return namedText(set, index) !== null;
  }

  var NAME_COST = 64; // work counted per point when the named points are found
  var namedCache = new WeakMap();

  // { mask: Uint8Array(N) with 1 for a named point, count }; cached per set object.
  function* namedGen(set, wk) {
    var cached = namedCache.get(set);
    if (cached) return cached;
    var N = set.count;
    var mask = new Uint8Array(N);
    var count = 0;
    for (var i = 0; i < N; i++) {
      if (isNamed(set, i)) {
        mask[i] = 1;
        count++;
      }
      if (wk.add(NAME_COST)) yield;
    }
    var built = { mask: mask, count: count };
    namedCache.set(set, built);
    return built;
  }

  function* scanGen(set, q32, scale, counts, wk) {
    var N = set.count;
    var D = set.dimension;
    var V = set.vectors;
    var scaled = !!scale;
    var setup = scanSetup(q32, scale, D);
    var named = yield* namedGen(set, wk);
    // Results come from named points; with none named, every point is a candidate.
    var mask = named.count > 0 ? named.mask : null;
    // The nearest max(k, candidates): the results come from its start, the reranker's pool too.
    var pool = new Pool(Math.min(Math.max(counts.k, counts.candidates), mask ? named.count : N));
    var distances = new Float64Array(N);
    var plainDistances = scaled ? new Float64Array(N) : null;
    var acc = { dot: 0, nn: 0, dotS: 0, nnS: 0 };
    for (var i = 0; i < N; i++) {
      scanRow(V, i, D, setup, acc, distances, plainDistances);
      if (mask === null || mask[i] === 1) pool.offer(i, distances[i]);
      if (wk.add(scaled ? 4 * D : 2 * D)) yield;
    }
    var plainRanks = scaled ? yield* pooledPlainRanks(pool, plainDistances, mask, N, wk) : null;
    var scan = { distances: distances, plainDistances: plainDistances, named: named.count };
    return buildRanking(set, counts, scaled, pool, scan, plainRanks);
  }

  function makeRank(set, vector, options) {
    var D = set.dimension;
    if (!isF32(vector, D)) throw new TypeError("vector must be a Float32Array of length " + D);
    var scale = options?.scale ?? null;
    if (scale !== null && !isF32(scale, D)) {
      throw new TypeError("scale must be a Float32Array of length " + D);
    }
    var candidates = clampCandidates(options?.candidates);
    var counts = { k: clampK(options?.k), candidates: candidates, top: clampTop(options?.top, candidates) };
    var wk = new Tracker(set.count * (NAME_COST + (scale ? 4 * D : 2 * D)));
    return genStepper(scanGen(set, vector, scale, counts, wk), wk);
  }

  function rank(set, vector, options) {
    return runToEnd(makeRank(set, vector, options));
  }

  // ----- reranking -------------------------------------------------------------

  function scoresOk(ranking, scores) {
    if (!isNumericArray(scores) || scores.length !== ranking.pool.length) return false;
    for (const score of scores) {
      if (typeof score !== "number" || !Number.isFinite(score)) return false;
    }
    return true;
  }

  function rerankOrder(ranking, scores) {
    if (!scoresOk(ranking, scores)) return refuse("rerank-malformed");
    var order = [];
    for (var i = 0; i < scores.length; i++) order.push(i);
    // Highest score first; equal scores keep embedding order (the pool's order).
    order.sort(function (a, b) {
      return scores[b] - scores[a] || a - b;
    });
    // The best `top` of the candidates by the reranker's scores (k for a ranking without one).
    var take = Math.min(ranking.top ?? ranking.k, order.length);
    var hits = [];
    for (var r = 0; r < take; r++) {
      var hit = { ...ranking.pool[order[r]] };
      hit.rank = r + 1;
      hit.moved = hit.embeddingRank - hit.rank;
      hit.score = scores[order[r]];
      hits.push(hit);
    }
    var near = null;
    var radius = null;
    for (const picked of hits) {
      if (near === null || picked.distance < near) near = picked.distance;
      if (radius === null || picked.distance > radius) radius = picked.distance;
    }
    for (const picked of hits) picked.gap = picked.distance - near;
    return { ok: true, hits: hits, near: near, radius: radius };
  }

  // ----- search from a loaded point ---------------------------------------------

  function pointQuery(set, id) {
    if (!hasPoints(set)) return refuse("no-data");
    var index = set.ids.indexOf(id);
    if (index < 0) return refuse("point-unknown", { id: id });
    var D = set.dimension;
    return { ok: true, index: index, id: id, vector: set.vectors.slice(index * D, index * D + D) };
  }

  function pointText(set, index) {
    return namedText(set, index) ?? set.ids[index];
  }

  // ----- search by words ----------------------------------------------------------

  function tokens(text) {
    if (typeof text !== "string") return [];
    var found = text.toLowerCase().match(/[\p{L}\p{N}]+/gu) || [];
    return Array.from(new Set(found));
  }

  // The words of one set: word -> ascending point indices, whole phrase -> indices.
  function addTo(map, key, i) {
    var list = map.get(key);
    if (!list) map.set(key, [i]);
    else if (list.at(-1) !== i) list.push(i);
  }

  function indexPoint(set, i, words, phrases) {
    var label = set.points[i]?.label;
    var text = set.points[i]?.metadata?.text;
    var cost = 64;
    var fields = [label, text];
    for (var f = 0; f < 2; f++) {
      if (typeof fields[f] !== "string") continue;
      cost += fields[f].length;
      var list = tokens(fields[f]);
      if (list.length === 0) continue;
      addTo(phrases, list.join(" "), i);
      for (const word of list) addTo(words, word, i);
    }
    return cost;
  }

  var wordCache = new WeakMap();

  function* indexGen(set, wk) {
    var cached = wordCache.get(set);
    if (cached) return cached;
    var words = new Map();
    var phrases = new Map();
    for (var i = 0; i < set.count; i++) {
      if (wk.add(indexPoint(set, i, words, phrases))) yield;
    }
    var built = { words: words, phrases: phrases };
    wordCache.set(set, built);
    return built;
  }

  // Points whose words start with `word`, ascending and each once.
  function prefixPoints(index, word) {
    var seen = new Set();
    index.words.forEach(function (list, key) {
      if (key.startsWith(word)) for (const point of list) seen.add(point);
    });
    return Array.from(seen).sort(function (a, b) {
      return a - b;
    });
  }

  // How each word matches: [{ word, how, points }] and the words that match nothing.
  function resolveWords(index, words) {
    var used = [];
    var unmatched = [];
    for (const word of words) {
      var points = index.words.get(word);
      var how = "exact";
      if (!points && Array.from(word).length >= PREFIX_MIN) {
        points = prefixPoints(index, word);
        how = "prefix";
      }
      if (points && points.length > 0) used.push({ word: word, how: how, points: points });
      else unmatched.push(word);
    }
    return { used: used, unmatched: unmatched };
  }

  // Adds the mean of the rows `points` (double precision) times `weight` into `total`.
  function* addMean(set, points, weight, total, wk) {
    var D = set.dimension;
    var V = set.vectors;
    var sum = new Float64Array(D);
    for (const point of points) {
      var o = point * D;
      for (var d = 0; d < D; d++) sum[d] += V[o + d];
      if (wk.add(D)) yield;
    }
    for (var e = 0; e < D; e++) total[e] += (sum[e] / points.length) * weight;
  }

  function wordFailure(code, words, unmatched) {
    var r = refuse(code, { words: unmatched.join(", ") });
    r.words = words;
    r.unmatched = unmatched;
    return r;
  }

  function* wordGen(set, text, wk) {
    var words = tokens(text);
    if (!hasPoints(set)) return wordFailure("no-data", words, words);
    if (words.length === 0) return wordFailure("empty-query", words, []);
    var index = yield* indexGen(set, wk);
    var phrase = words.join(" ");
    var whole = index.phrases.get(phrase);
    var picked;
    if (whole) {
      picked = {
        used: [{ word: phrase, how: "whole", points: whole }],
        unmatched: [],
      };
    } else {
      picked = resolveWords(index, words);
    }
    if (picked.used.length === 0) return wordFailure("words-none", words, picked.unmatched);
    var total = new Float64Array(set.dimension);
    for (const match of picked.used) {
      yield* addMean(set, match.points, 1 / picked.used.length, total, wk);
    }
    var vector = Float32Array.from(total);
    if (isAllZero(vector)) return wordFailure("query-zero", words, picked.unmatched);
    return {
      ok: true,
      vector: vector,
      words: words,
      used: picked.used.map(function (m) {
        return { word: m.word, how: m.how, count: m.points.length };
      }),
      unmatched: picked.unmatched,
      whole: !!whole,
    };
  }

  function makeWordQuery(set, text) {
    var n = set?.count > 0 ? set.count : 1;
    var wk = new Tracker(n * (set?.dimension > 0 ? set.dimension : 1));
    return genStepper(wordGen(set, text, wk), wk);
  }

  function wordQuery(set, text) {
    return runToEnd(makeWordQuery(set, text));
  }

  ET.search = {
    DEFAULT_K: DEFAULT_K,
    MIN_K: MIN_K,
    MAX_K: MAX_K,
    DEFAULT_CANDIDATES: DEFAULT_CANDIDATES,
    MAX_CANDIDATES: MAX_CANDIDATES,
    DEFAULT_TOP: DEFAULT_TOP,
    PREFIX_MIN: PREFIX_MIN,
    MEASURE: MEASURE,
    MEASURE_TEXT: MEASURE_TEXT,
    MESSAGES: MESSAGES,
    clampK: clampK,
    clampCandidates: clampCandidates,
    clampTop: clampTop,
    format: format,
    checkSameSpace: checkSameSpace,
    checkQuery: checkQuery,
    makeRank: makeRank,
    rank: rank,
    rerankOrder: rerankOrder,
    pointQuery: pointQuery,
    pointText: pointText,
    isNamed: isNamed,
    tokens: tokens,
    makeWordQuery: makeWordQuery,
    wordQuery: wordQuery,
  };
})();
// ---------------------------------------------------------------------------
// 26-search-sets.js: several searches at once (ET.searchSets).
//
// Up to four searches are active together. Given their rankings (the shape
// ET.search makes, js/api/24-search.md) this module answers what is lit and
// how strongly under the three lit settings, which points carry the shared
// mark, the report for each pair of searches, the point-of-view scale of one
// search, and the seeded linear view that faces the searches.
//
// Pure: no DOM, no WebGL, no network. The only random numbers are drawn from
// ET.math.makeRandom on a seed derived from the view seed, so the same data,
// searches and seed give the same frame bit for bit. Every projection is
// linear: the facing frame is three orthonormal rows applied to every point.
//
// Documented in js/api/26-search-sets.md.
// ---------------------------------------------------------------------------
ET.searchSets = (function () {
  var MAX_SEARCHES = 4;
  var LETTERS = Object.freeze(["A", "B", "C", "D"]);
  var LIT_SETTINGS = Object.freeze(["even", "close", "named"]);
  var DEFAULT_LIT = "even";
  var LIT_THRESHOLD = 0.02;
  var CLOSE_REACH = 2.2;
  var CLOSE_POWER = 1.6;
  var FACE_SALT = 0x46414345;
  var FACE_ITERATIONS = 25;
  var FACE_ZOOM = 0.7;
  var FACE_MIN_REACH = 1e-3;
  // A candidate axis is kept when what is left after removing the axes so far
  // is longer than KEEP times its length before.
  var KEEP = 1e-6;
  // The facing-frame stepper pauses after this many multiply-adds (counted, not
  // timed, so the pauses fall at the same places on every run).
  var FACE_UNIT = 1 << 17;

  // ----- small functions -----------------------------------------------------

  function letter(j) {
    if (!Number.isInteger(j) || j < 0 || j >= MAX_SEARCHES) {
      throw new RangeError("a search position is an integer from 0 to " + (MAX_SEARCHES - 1));
    }
    return LETTERS[j];
  }

  function litSetting(value) {
    return LIT_SETTINGS.includes(value) ? value : DEFAULT_LIT;
  }

  function isVectorLike(v) {
    return v !== null && typeof v === "object" && typeof v.length === "number";
  }

  function scaleFor(vector) {
    if (!isVectorLike(vector)) throw new TypeError("scaleFor: the query vector must be an array of numbers");
    var s = new Float32Array(vector.length);
    for (var d = 0; d < vector.length; d++) s[d] = Math.abs(vector[d]);
    return s;
  }

  function checkSearches(searches) {
    if (!Array.isArray(searches)) throw new TypeError("searches must be an array");
    if (searches.length > MAX_SEARCHES) {
      throw new RangeError("at most " + MAX_SEARCHES + " searches can be active at once");
    }
  }

  function hasResults(ranking) {
    return typeof ranking.radius === "number" && ranking.hits.length > 0;
  }

  // ----- lit values ----------------------------------------------------------

  function closeValue(d, near, reach) {
    var x = Math.min(Math.max(1 - (d - near) / (reach - near), 0), 1);
    return x ** CLOSE_POWER;
  }

  // The value one search gives a point at distance d (named results are set apart).
  function searchValue(how, d, isIn, near, reach) {
    if (how === "close") return closeValue(d, near, reach);
    return how === "even" && isIn ? 1 : 0;
  }

  function lightNamed(ranking, count, out) {
    for (const hit of ranking.hits) {
      var at = hit.index;
      if (at < count) out.lit[at] = 1;
    }
  }

  // Adds one search to `out`; returns how many points are inside it.
  function lightSearch(ranking, count, how, out) {
    if (!hasResults(ranking)) return 0;
    var dist = ranking.distances;
    var n = Math.min(count, dist.length);
    var radius = ranking.radius;
    var near = ranking.near;
    var reach = near + (radius - near) * CLOSE_REACH + 1e-6;
    var inside = 0;
    for (var i = 0; i < n; i++) {
      var isIn = dist[i] <= radius;
      if (isIn) {
        out.inside[i]++;
        inside++;
      }
      var v = searchValue(how, dist[i], isIn, near, reach);
      if (v > out.lit[i]) out.lit[i] = v;
    }
    if (how === "named") lightNamed(ranking, count, out);
    return inside;
  }

  function litValues(searches, count, setting) {
    checkSearches(searches);
    if (!Number.isInteger(count) || count < 0) throw new RangeError("count must be a non-negative integer");
    var how = litSetting(setting);
    var out = {
      lit: new Float32Array(count),
      shared: new Uint8Array(count),
      inside: new Uint8Array(count),
      insideCounts: [],
      litCount: 0,
      sharedCount: 0,
    };
    for (const search of searches) out.insideCounts.push(lightSearch(search, count, how, out));
    for (var i = 0; i < count; i++) {
      if (out.lit[i] > LIT_THRESHOLD) out.litCount++;
      if (out.inside[i] >= 2 && out.lit[i] > 0) {
        out.shared[i] = 1;
        out.sharedCount++;
      }
    }
    return out;
  }

  // ----- pair reports --------------------------------------------------------

  function checkIndex(index, count) {
    if (!Number.isInteger(index) || index < 0 || index >= count) {
      throw new RangeError("a named result's index is not a row of the set: " + index);
    }
  }

  // The length of every named result's row, in double precision.
  function hitLengths(X, D, count, hits) {
    var lengths = new Float64Array(hits.length);
    for (var h = 0; h < hits.length; h++) {
      checkIndex(hits[h].index, count);
      var o = hits[h].index * D;
      var sum = 0;
      for (var d = 0; d < D; d++) sum += X[o + d] * X[o + d];
      lengths[h] = Math.sqrt(sum);
    }
    return lengths;
  }

  // Plain cosine distance between two loaded rows; a zero row is at distance 1.
  function rowDistance(X, D, i, j, li, lj) {
    if (li === 0 || lj === 0) return 1;
    var oi = i * D;
    var oj = j * D;
    var dot = 0;
    for (var d = 0; d < D; d++) dot += X[oi + d] * X[oj + d];
    var cos = Math.min(Math.max(dot / (li * lj), -1), 1);
    return 1 - cos;
  }

  function sharedBetween(ra, rb) {
    if (!hasResults(ra) || !hasResults(rb)) return 0;
    var n = Math.min(ra.distances.length, rb.distances.length);
    var shared = 0;
    for (var i = 0; i < n; i++) {
      if (ra.distances[i] <= ra.radius && rb.distances[i] <= rb.radius) shared++;
    }
    return shared;
  }

  // The closest pair of different named results, one from each search; pauses when a unit
  // of work ends (counted, so the pauses fall at the same places on every run).
  function* closestPairGen(X, D, ra, rb, la, lb, wk) {
    var best = null;
    for (var x = 0; x < ra.hits.length; x++) {
      var ia = ra.hits[x].index;
      for (var y = 0; y < rb.hits.length; y++) {
        var ib = rb.hits[y].index;
        if (ia === ib) continue;
        var dist = rowDistance(X, D, ia, ib, la[x], lb[y]);
        if (best === null || dist < best.distance) best = { a: ia, b: ib, distance: dist };
        if (wk.add(D)) yield;
      }
    }
    return best;
  }

  // One pair's report.
  function* pairGen(set, a, b, ra, rb, lengths, wk) {
    var inB = new Set();
    for (const hit of rb.hits) inB.add(hit.index);
    var commonIndices = [];
    for (const hit of ra.hits) {
      if (inB.has(hit.index)) commonIndices.push(hit.index);
    }
    var shared = sharedBetween(ra, rb);
    if (wk.add(Math.min(ra.distances.length, rb.distances.length))) yield;
    var closest = yield* closestPairGen(set.vectors, set.dimension, ra, rb, lengths[a], lengths[b], wk);
    return {
      a: a,
      b: b,
      shared: shared,
      common: commonIndices.length,
      commonIndices: commonIndices,
      closest: closest,
    };
  }

  function* pairsGen(set, searches, lengths, wk) {
    var pairs = [];
    for (var a = 0; a < searches.length; a++) {
      for (var b = a + 1; b < searches.length; b++) {
        pairs.push(yield* pairGen(set, a, b, searches[a], searches[b], lengths, wk));
      }
    }
    return pairs;
  }

  // The pair reports as a stepper (the facing frame's convention). The rows' lengths and the
  // checks of every index are worked out here, so a bad index throws at once.
  function makePairReports(set, searches) {
    checkSearches(searches);
    var D = set.dimension;
    var lengths = [];
    for (const search of searches) lengths.push(hitLengths(set.vectors, D, set.count, search.hits));
    var total = 1;
    for (var a = 0; a < searches.length; a++) {
      for (var b = a + 1; b < searches.length; b++) {
        total += searches[a].hits.length * searches[b].hits.length * D + set.count;
      }
    }
    var wk = new FaceWork(total);
    return faceStepper(pairsGen(set, searches, lengths, wk), wk);
  }

  function pairReports(set, searches) {
    var st = makePairReports(set, searches);
    st.step();
    return st.result;
  }

  // ----- the facing frame: vector helpers (double precision) -----------------

  function dotD(a, b, D) {
    var s = 0;
    for (var d = 0; d < D; d++) s += a[d] * b[d];
    return s;
  }

  function lengthD(a, D) {
    return Math.sqrt(dotD(a, a, D));
  }

  // Removes from v its components along each of `axes` (orthonormal rows), once.
  function removeAxes(v, axes, D) {
    for (const axis of axes) {
      var p = dotD(v, axis, D);
      for (var d = 0; d < D; d++) v[d] -= p * axis[d];
    }
  }

  // Step 3: Gram-Schmidt against the axes so far (twice); kept when what is left
  // is longer than KEEP times the candidate, then normalised and appended.
  function offer(axes, candidate, D) {
    var before = lengthD(candidate, D);
    removeAxes(candidate, axes, D);
    removeAxes(candidate, axes, D);
    var after = lengthD(candidate, D);
    if (before > 0 && after > KEEP * before) {
      for (var d = 0; d < D; d++) candidate[d] /= after;
      axes.push(candidate);
      return true;
    }
    return false;
  }

  // Step 6: the standard basis vectors e_0, e_1, ... in order until one is kept.
  // With fewer than three axes and D >= 3 one always is.
  function offerBasis(axes, D) {
    for (var d = 0; d < D; d++) {
      var e = new Float64Array(D);
      e[d] = 1;
      if (offer(axes, e, D)) return;
    }
  }

  function checkLength(v, length, what) {
    if (!isVectorLike(v) || v.length !== length) {
      throw new TypeError("facing frame: " + what + " must have " + length + " values");
    }
  }

  function checkOption(v, length, what) {
    if (v === null || v === undefined) return null;
    if (!(v instanceof Float32Array) || v.length !== length) {
      throw new TypeError("facing frame: " + what + " must be a Float32Array of " + length + " values");
    }
    return v;
  }

  function checkFacing(set, searches) {
    var D = set.dimension;
    for (const search of searches) {
      checkLength(search.query, D, "each query");
      if (!Array.isArray(search.hits)) throw new TypeError("facing frame: each search needs a hits array");
      for (const hit of search.hits) checkIndex(hit.index, set.count);
    }
  }

  // ----- the facing frame: the computation, as a generator --------------------

  // Counts multiply-adds and says when a unit of work is over.
  function FaceWork(total) {
    this.total = total;
    this.done = 0;
    this.acc = 0;
  }
  FaceWork.prototype.add = function (cost) {
    this.done += cost;
    this.acc += cost;
    if (this.acc < FACE_UNIT) return false;
    this.acc = 0;
    return true;
  };

  // One search's rows: its query and its named results' loaded vectors.
  function searchRows(X, D, search) {
    var mine = [search.query];
    for (const hit of search.hits) {
      var o = hit.index * D;
      mine.push(X.subarray(o, o + D));
    }
    return mine;
  }

  // The mean of rows (each optionally scaled by s), in double precision.
  function meanOfRows(rows, D, s) {
    var c = new Float64Array(D);
    for (const row of rows) {
      for (var d = 0; d < D; d++) c[d] += s ? row[d] * s[d] : row[d];
    }
    for (var e = 0; e < D; e++) c[e] /= rows.length;
    return c;
  }

  // (row * s) - c for one row, in double precision.
  function offsetOf(row, D, s, c) {
    var v = new Float64Array(D);
    for (var d = 0; d < D; d++) v[d] = (s ? row[d] * s[d] : row[d]) - c[d];
    return v;
  }

  // The rows of every search (its query and its named results), unscaled, each
  // search's centre scaled and unscaled, and each scaled row's offset from its
  // search's scaled centre.
  // Pauses after each search's centres and whenever a unit of work ends among its offsets, so
  // searches of 100 results keep units short.
  function* gatherRows(fit, wk) {
    var out = { scaledCentres: [], plainCentres: [], offsets: [], plainRows: [] };
    for (const search of fit.searches) {
      var mine = searchRows(fit.X, fit.D, search);
      var c = meanOfRows(mine, fit.D, fit.scale);
      out.scaledCentres.push(c);
      out.plainCentres.push(meanOfRows(mine, fit.D, null));
      wk.add(2 * mine.length * fit.D);
      yield;
      for (const row of mine) {
        out.plainRows.push(row);
        out.offsets.push(offsetOf(row, fit.D, fit.scale, c));
        if (wk.add(fit.D)) yield;
      }
    }
    return out;
  }

  // One pass of the power iteration over rows `from` on: w += (row . v) row for each,
  // stopping after the row at which a unit of work ends. Returns the next row to do,
  // or -1 when the rows ran out without a unit ending. (A plain function that resumes
  // at `from`: the generator itself pays for a for...of over the rows, measured.)
  function spreadPass(offsets, from, v, w, D, wk) {
    for (var r = from; r < offsets.length; r++) {
      var row = offsets[r];
      var p = dotD(row, v, D);
      for (var d = 0; d < D; d++) w[d] += p * row[d];
      if (wk.add(2 * D)) return r + 1;
    }
    return -1;
  }

  // Step 5: a power iteration on the spread of the rows about their own centres,
  // from a seeded start. Returns the candidate, or null when the spread left
  // outside the axes so far is zero (then the basis fallback applies).
  function* spreadAxis(fit, offsets, axes, wk) {
    var D = fit.D;
    var v = new Float64Array(D);
    ET.math.makeRandom(ET.math.mixSeed(fit.seed, FACE_SALT + axes.length)).fillGauss(v);
    for (var it = 0; it < FACE_ITERATIONS; it++) {
      var w = new Float64Array(D);
      var next = spreadPass(offsets, 0, v, w, D, wk);
      while (next >= 0) {
        yield;
        next = spreadPass(offsets, next, v, w, D, wk);
      }
      var before = lengthD(w, D);
      removeAxes(w, axes, D);
      var after = lengthD(w, D);
      if (after <= KEEP * before) return null;
      for (var e = 0; e < D; e++) w[e] /= after;
      v = w;
    }
    return v;
  }

  // Step 7: with a scale, axis a becomes a * s and the three are made
  // orthonormal again in order; a degenerate one is replaced by the basis rule.
  function mapBack(axes, origins, s, D) {
    var mapped = [];
    for (var k = 0; k < axes.length; k++) {
      var m = new Float64Array(D);
      for (var d = 0; d < D; d++) m[d] = axes[k][d] * s[d];
      if (!offer(mapped, m, D)) {
        offerBasis(mapped, D);
        origins[k] = "basis";
      }
    }
    return mapped;
  }

  // Step 8: the frame's rows, each negated when it points away from the same
  // row of the current frame.
  function signedFrame(axes, current, D) {
    var frame = new Float32Array(3 * D);
    for (var k = 0; k < 3; k++) {
      var away = current !== null && dotD(axes[k], current.subarray(k * D, (k + 1) * D), D) < 0;
      var sign = away ? -1 : 1;
      for (var d = 0; d < D; d++) frame[k * D + d] = sign * axes[k][d];
    }
    return frame;
  }

  // Step 9: the length of frame (x - centre).
  function shownLength(frame, x, centre, D) {
    var sq = 0;
    for (var a = 0; a < 3; a++) {
      var p = 0;
      for (var f = 0; f < D; f++) p += (x[f] - centre[f]) * frame[a * D + f];
      sq += p * p;
    }
    return Math.sqrt(sq);
  }

  function countOf(origins, what) {
    return origins.filter((o) => o === what).length;
  }

  // Steps 8 and 9: signs against the current frame, then centre and zoom.
  function* finish(fit, rows, axes, origins, wk) {
    var D = fit.D;
    var frame = signedFrame(axes, fit.current, D);
    var centre = Float32Array.from(meanOfRows(rows.plainCentres, D, null));
    var reach = FACE_MIN_REACH;
    for (const row of rows.plainRows) {
      reach = Math.max(reach, shownLength(frame, row, centre, D));
      if (wk.add(3 * D)) yield;
    }
    return {
      frame: frame,
      centre: centre,
      zoom: FACE_ZOOM / reach,
      fromCentres: countOf(origins, "centres"),
      fromSpread: countOf(origins, "spread"),
      fromBasis: countOf(origins, "basis"),
    };
  }

  function* facingGen(fit, wk) {
    var D = fit.D;
    var rows = yield* gatherRows(fit, wk);
    var axes = [];
    var origins = [];
    var cs = rows.scaledCentres;
    for (var j = 1; j < cs.length && axes.length < 3; j++) {
      var join = new Float64Array(D);
      for (var d = 0; d < D; d++) join[d] = cs[j][d] - cs[0][d];
      if (offer(axes, join, D)) origins.push("centres");
    }
    while (axes.length < 3) {
      var candidate = yield* spreadAxis(fit, rows.offsets, axes, wk);
      if (candidate && offer(axes, candidate, D)) {
        origins.push("spread");
      } else {
        offerBasis(axes, D);
        origins.push("basis");
      }
    }
    if (fit.scale) axes = mapBack(axes, origins, fit.scale, D);
    return yield* finish(fit, rows, axes, origins, wk);
  }

  function now() {
    return performance.now();
  }

  // { step(budgetMs?) -> done, done, progress, result }, as ET.math's steppers:
  // step(budgetMs) runs units until budgetMs ms have passed (at least one);
  // step() runs to the end. The clock decides only how many units run per call.
  function faceStepper(gen, wk) {
    var st = { done: false, progress: 0, result: null, step: null };
    st.step = function (budgetMs) {
      if (st.done) return true;
      var limit = budgetMs === undefined ? Infinity : budgetMs;
      var start = now();
      do {
        var r = gen.next();
        if (r.done) {
          st.done = true;
          st.result = r.value;
          st.progress = 1;
          return true;
        }
      } while (now() - start < limit);
      st.progress = Math.min(0.99, wk.done / wk.total);
      return false;
    };
    return st;
  }

  // Written as a comparison so that NaN (and undefined) are not enough.
  function hasThreeDimensions(D) {
    return D >= 3;
  }

  function makeFacingFrame(set, searches, options) {
    var o = options || {};
    checkSearches(searches);
    var D = set.dimension;
    if (!hasThreeDimensions(D)) throw new RangeError("the facing frame needs at least 3 dimensions");
    var fit = {
      X: set.vectors,
      D: D,
      searches: searches,
      seed: ET.math.toSeed(o.seed === undefined ? 1 : o.seed),
      scale: checkOption(o.scale, D, "scale"),
      current: checkOption(o.current, 3 * D, "current"),
    };
    checkFacing(set, searches);
    if (!searches.length) {
      return {
        done: true,
        progress: 1,
        result: null,
        step: function () {
          return true;
        },
      };
    }
    var rowCount = 0;
    for (const search of searches) rowCount += 1 + search.hits.length;
    var wk = new FaceWork(rowCount * D * (6 + 2 * FACE_ITERATIONS * 3));
    return faceStepper(facingGen(fit, wk), wk);
  }

  function facingFrame(set, searches, options) {
    var st = makeFacingFrame(set, searches, options);
    st.step();
    return st.result;
  }

  return {
    MAX_SEARCHES: MAX_SEARCHES,
    LETTERS: LETTERS,
    LIT_SETTINGS: LIT_SETTINGS,
    DEFAULT_LIT: DEFAULT_LIT,
    LIT_THRESHOLD: LIT_THRESHOLD,
    CLOSE_REACH: CLOSE_REACH,
    CLOSE_POWER: CLOSE_POWER,
    FACE_SALT: FACE_SALT,
    FACE_ITERATIONS: FACE_ITERATIONS,
    FACE_ZOOM: FACE_ZOOM,
    letter: letter,
    litSetting: litSetting,
    scaleFor: scaleFor,
    litValues: litValues,
    pairReports: pairReports,
    makePairReports: makePairReports,
    makeFacingFrame: makeFacingFrame,
    facingFrame: facingFrame,
  };
})();
// ---------------------------------------------------------------------------
// 30-renderer.js: WebGL 2 drawing (ET.renderer).
//
// Ported from the reference page (docs/specs/reference/embedding-tumbler-demo.html):
// glowing points, true-neighbour wires, an HDR half-float target with a mip-chain
// bloom, depth of field, trails and twinkle. What changed from the reference:
//
//   * The dimension D comes from the data. Vectors are packed four dimensions per
//     RGBA32F texel, ceil(D / 4) texels per point, several points per texture row;
//     the shader's loop bound and row packing are generated from that layout and
//     checked against MAX_TEXTURE_SIZE.
//   * The renderer draws only. The caller supplies vectors, per-point colour and
//     weight, wire pairs, the frame (three orthonormal rows of length D), the centre,
//     and the draw parameters. It computes no tour, no neighbours, reads no CSS and
//     touches no DOM beyond the canvas it is given.
//   * It has a lifecycle: dispose() frees every GPU object it made, a lost context
//     is rebuilt from the data it keeps, and without WebGL 2 it reports instead of
//     throwing.
//   * Search: setLit() gives per-point lit values and a shared mark, drawn by a second
//     point program (and, for the wires, a second wire program) only when they apply;
//     without them the frame is drawn as before.
//
// The API is documented in js/api/30-renderer.md.
// ---------------------------------------------------------------------------
ET.renderer = (function () {
  // Draw parameters. Every value here is a documented default that a mode or the
  // viewer may override per frame through draw(state).
  var DEFAULTS = Object.freeze({
    zoom: 1, // scale applied to projected coordinates before perspective
    yaw: 0, // extra 3-D turn of the projected cloud about the vertical axis (radians)
    pitch: 0, // and about the horizontal axis (radians)
    radius: 0.46, // half-extent of unit coordinates as a share of min(width, height)
    pointSize: 6.5, // base point size in device pixels (multiply by devicePixelRatio)
    minPointSize: 1.5, // floor on the drawn point size in device pixels
    gain: 1, // overall brightness of points and wires
    fallbackGain: 0.55, // brightness used when there is no HDR target
    twinkle: 0.18, // amplitude of each point's slow brightness flicker, 0 = steady
    time: 0, // seconds; drives twinkle
    dt: 1 / 60, // seconds since the previous draw; drives trail fading
    trails: 0.17, // trail persistence in seconds (0 = clear every frame)
    trailGain: 1.6, // brightness compensation while trails accumulate
    clear: false, // true: wipe the trails this frame
    wires: 0, // 0..1 opacity of the true-neighbour wires
    wireGain: 1.5, // brightness of wires at wires = 1
    dim: 1, // brightness of points whose weight is below 0.99 (1 = no dimming)
    fog: 0, // 0..1: how strongly true distance from the centre dims and shrinks points
    fogNear: 1.2, // true distance (data units) at which fog starts to clear
    fogWidth: 0.8, // distance over which fog goes from clear to full
    focus: 0, // depth of the in-focus plane after the 3-D turn (0 = the cloud centre)
    depthOfField: 1.1, // how fast points swell and dim away from the focus plane
    wireDepthOfField: 0.8, // the same for wires
    bloom: 0.55, // strength of the mip-chain glow
    exposure: 1.35, // tone-mapping exposure; bright cores burn toward white
    gamma: 0.92, // output curve
    vignette: 0.72, // brightness at the corners (1 = no vignette)
    background: Object.freeze([0, 0, 0]), // added under the image, linear RGB 0..1
    filter: 0, // 0..1: how much the lit values (setLit) apply this frame; 0 = drawn as without search
    unlitGain: 0.07, // brightness factor of a point with lit value 0, at filter 1
    // 0 = off. Above 0: the most wire light per pixel, measured where the wires' light lands,
    // that the wires may pile up to; above it the wires' brightness is scaled down (wireDensity).
    wireLoad: 0,
  });

  var WIRE_SAMPLE = 192; // wires sampled (at an even stride) to measure how they pile up
  var WIRE_CELLS = 64; // grid cells across the stage's shorter side for that measure

  // The point program's uniforms (the lit programs add uFilter and uUnlit).
  var POINT_UNIFORMS = ["uPx", "uMinPx", "uFog", "uTime", "uGain", "uDim", "uTwinkle", "uDof", "uFogNear", "uFogWidth"];
  var VIEW_UNIFORMS = ["uX", "uF", "uRot", "uView", "uZoom", "uFocus"];

  var MAX_ROW_WIDTH = 4096; // preferred texture row width (texels) before widening
  var INT32_MAX = 2147483647;

  function unavailable(reason, message) {
    return { ok: false, reason: reason, message: message };
  }

  // The integer part of a size or count; NaN, null and undefined read as 0.
  function wholeOr0(x) {
    return Math.trunc(x) || 0;
  }

  function shaderError(message) {
    var e = new Error(message);
    e.isShaderError = true;
    return e;
  }

  function freshGpu() {
    return {
      objects: [],
      tone: null,
      fade: null,
      point: null,
      pointLit: null, // the point program that reads lit values, compiled on first setLit
      line: null,
      lineLit: null, // the wire program that reads each wire's lit value, compiled with pointLit
      progLayout: null,
      quadVao: null,
      texX: null,
      texXRows: 0,
      texF: null,
      fStage: null,
      fWidth: 0,
      vboPoint: null,
      vaoPoint: null,
      vboLit: null, // one float per point: lit value, plus 2 for the shared mark
      vaoPointLit: null, // vboPoint at location 0 and vboLit at location 1
      litCapacity: 0, // points vboLit was allocated for
      vboLine: null,
      vaoLine: null,
      vboWireLit: null, // one float per wire end: the smaller lit value of the wire's two ends
      vaoLineLit: null, // vboLine at locations 0..2 and vboWireLit at location 3
      fbo: null,
      texHdr: null,
      hdrW: 0,
      hdrH: 0,
    };
  }

  // CPU arrays for `capacity` points in layout `lay`, zero-padded to whole rows.
  function allocate(lay, capacity) {
    var rows = lay.rows(capacity);
    var vec = new Float32Array(rows * lay.pointsPerRow * lay.floatsPerPoint);
    var attr = new Float32Array(Math.max(1, capacity) * 4);
    return { vectors: vec, attr: attr };
  }

  // ---------- layout: how N points of dimension D sit in one RGBA32F texture ----------

  function layout(dimension, count, maxTextureSize) {
    var d = Math.trunc(dimension);
    var n = Math.max(0, wholeOr0(count));
    var max = wholeOr0(maxTextureSize);
    if (d < 1 || d !== dimension || d > INT32_MAX) return unavailable("bad-dimension", "Dimension must be a positive integer.");
    var texels = Math.ceil(d / 4);
    if (texels > max) {
      return unavailable(
        "dimension-too-large",
        "Dimension " + d + " needs " + texels + " texels per point; this GPU allows " + max + "."
      );
    }
    var perRow = Math.max(1, Math.floor(Math.min(max, MAX_ROW_WIDTH) / texels));
    if (Math.ceil(n / perRow) > max) perRow = Math.floor(max / texels); // widen before refusing
    var maxPoints = perRow * max;
    if (n > maxPoints) {
      return unavailable(
        "too-many-points",
        n + " points of dimension " + d + " do not fit this GPU's textures (at most " + maxPoints + ")."
      );
    }
    return {
      ok: true,
      dimension: d,
      texelsPerPoint: texels,
      floatsPerPoint: texels * 4,
      pointsPerRow: perRow,
      width: perRow * texels,
      maxTextureSize: max,
      maxPoints: maxPoints,
      rows: function (points) {
        return Math.max(1, Math.ceil(points / perRow));
      },
    };
  }

  // ---------- shaders, generated from the layout ----------

  // The point vertex shader's body. lit false gives the program drawn whenever no search
  // applies, line for line the shader that existed before search, so that picture cannot
  // change. lit true is a second program that also reads the per-point lit value (aLit:
  // the value in 0..1, plus 2 when the shared mark is drawn) and the draw keys filter
  // (uFilter) and unlitGain (uUnlit): results swell and brighten, the rest shrink and dim,
  // and a marked point adds white. A lit point's fog (distance dimming) is also reduced in
  // proportion to its lit value times filter, so results stay visible wherever the camera
  // is while unlit points keep the fog.
  function pointMain(lit) {
    var sizeTail = lit ? " * mix(1.0, mix(0.8, 1.5, l), uFilter)" : "";
    var colourTail = lit ? " * mix(1.0, mix(uUnlit, 2.2, l), uFilter)" : "";
    var fogAmount = lit ? "fogK" : "uFog";
    return ["uniform float uPx, uMinPx, uFog, uTime, uGain, uDim, uTwinkle, uDof, uFogNear, uFogWidth;"]
      .concat(lit ? ["uniform float uFilter, uUnlit;"] : [])
      .concat(["layout(location = 0) in vec4 aCol;"])
      .concat(lit ? ["layout(location = 1) in float aLit;"] : [])
      .concat([
        "out vec3 vCol;",
        "void main() {",
        "  float fid = float(gl_VertexID);",
        "  float dist, zf;",
        "  vec4 q = place(proj(gl_VertexID, dist), zf);",
        "  gl_Position = vec4(q.xy, 0.0, 1.0);",
        "  float fog = clamp((uFogNear - dist) / uFogWidth, 0.0, 1.0);",
        "  float w = aCol.a;",
        "  float blur = 1.0 + uDof * zf * zf;", // out-of-focus points swell and dim
      ])
      .concat(
        lit
          ? [
              "  float mark = step(1.5, aLit);",
              "  float l = clamp(aLit - 2.0 * mark, 0.0, 1.0);",
              "  float fogK = uFog * (1.0 - l * uFilter);",
            ]
          : []
      )
      .concat([
        "  float size = uPx * q.w * (0.55 + 1.5 * w) * blur * mix(1.0, 0.45 + 1.25 * fog, " + fogAmount + ")" + sizeTail + ";",
        "  gl_PointSize = max(size, uMinPx);",
        "  float tw = (1.0 - uTwinkle) + uTwinkle * sin(uTime * (1.3 + fract(fid * 0.618) * 2.2) + fid * 12.9898);",
        "  float a = (0.16 + 0.84 * w * w) * tw / pow(blur, 1.5) * mix(1.0, 0.22 + 0.78 * fog * fog, " + fogAmount + ");",
        "  vCol = aCol.rgb * a * uGain * mix(1.0, uDim, step(w, 0.99))" + colourTail + ";",
      ])
      .concat(lit ? ["  vCol += vec3(0.9) * a * uGain * mark * uFilter;"] : [])
      .concat(["}"])
      .join("\n");
  }

  // The wire vertex shader's body. lit false gives the program drawn whenever no search
  // applies, line for line the shader that existed before search. lit true also reads the
  // wire's lit value (aWireLit: the smaller lit value of its two ends, so 1 only when both
  // ends are lit) and the draw keys filter and unlitGain: a wire between results keeps its
  // full strength, any other wire is dimmed like an unlit point.
  function lineMain(lit, wireScale) {
    var colourTail = lit ? " * mix(1.0, mix(uUnlit, 1.0, aWireLit), uFilter)" : "";
    return ["uniform float uGain, uWireDof;"]
      .concat(lit ? ["uniform float uFilter, uUnlit;"] : [])
      .concat(["layout(location = 0) in uvec2 aPair;", "layout(location = 1) in float aLen;", "layout(location = 2) in vec3 aCol;"])
      .concat(lit ? ["layout(location = 3) in float aWireLit;"] : [])
      .concat([
        "out vec3 vCol;",
        "void main() {",
        "  float d0, d1, zf;",
        "  vec3 p = proj(int(aPair.x), d0), p2 = proj(int(aPair.y), d1);",
        "  vec4 q = place(p, zf);",
        "  gl_Position = vec4(q.xy, 0.0, 1.0);",
        // 1 = a typical shadow length; higher = seen nearer its true length
        "  float t = length(p - p2) / max(aLen, 1e-6) * " + wireScale + ";",
        "  vCol = aCol * (0.03 + 0.2 * t * t * t) * uGain / (1.0 + uWireDof * zf * zf)" + colourTail + ";",
        "}",
      ])
      .join("\n");
  }

  function shaderSources(lay) {
    var T = lay.texelsPerPoint;
    var P = lay.pointsPerRow;
    var wireScale = Math.sqrt(lay.dimension / 3).toFixed(4);
    var head = "#version 300 es\nprecision highp float; precision highp int; precision highp sampler2D;\n";
    // proj(): the centred vector's coordinates along the three frame rows, plus its
    // true distance from the centre, all in the full dimension.
    var proj = [
      "uniform sampler2D uX; uniform sampler2D uF;",
      "const int TEXELS = " + T + ";",
      "const int PER_ROW = " + P + ";",
      "vec3 proj(int id, out float dist) {",
      "  int base = (id % PER_ROW) * TEXELS; int row = id / PER_ROW;",
      "  vec3 p = vec3(0.0); float dd = 0.0;",
      "  for (int k = 0; k < TEXELS; k++) {",
      "    vec4 x = texelFetch(uX, ivec2(base + k, row), 0) - texelFetch(uF, ivec2(k, 3), 0);",
      "    p += vec3(dot(x, texelFetch(uF, ivec2(k, 0), 0)), dot(x, texelFetch(uF, ivec2(k, 1), 0)),",
      "              dot(x, texelFetch(uF, ivec2(k, 2), 0)));",
      "    dd += dot(x, x);",
      "  }",
      "  dist = sqrt(dd);",
      "  return p;",
      "}",
      "uniform vec4 uRot; uniform vec2 uView; uniform float uZoom; uniform float uFocus;",
      // place(): turn by yaw and pitch, then a gentle perspective. zf is the depth
      // relative to the focus plane, used for depth of field.
      "vec4 place(vec3 p, out float zf) {",
      "  p *= uZoom;",
      "  float x1 = p.x * uRot.x + p.z * uRot.y, z1 = -p.x * uRot.y + p.z * uRot.x;",
      "  float y2 = p.y * uRot.z - z1 * uRot.w; float z2 = p.y * uRot.w + z1 * uRot.z;",
      "  float s = 3.0 / max(0.6, 3.0 + z2);",
      "  zf = z2 - uFocus;",
      "  return vec4(x1 * s * uView.x, y2 * s * uView.y, 0.0, s);",
      "}",
    ].join("\n");
    var pointVertex = head + proj + "\n" + pointMain(false);
    var pointVertexLit = head + proj + "\n" + pointMain(true);
    var pointFragment = [
      "#version 300 es",
      "precision mediump float;",
      "in vec3 vCol; out vec4 o;",
      "void main() {",
      "  vec2 q = gl_PointCoord * 2.0 - 1.0;",
      "  float r2 = dot(q, q);",
      "  if (r2 > 1.0) discard;",
      "  float g = exp(-r2 * 4.5) * (1.0 - r2) + 0.9 * exp(-r2 * 38.0);",
      "  o = vec4(vCol * g, 1.0);",
      "}",
    ].join("\n");
    var lineVertex = head + proj + "\n" + lineMain(false, wireScale);
    var lineVertexLit = head + proj + "\n" + lineMain(true, wireScale);
    var lineFragment =
      "#version 300 es\nprecision mediump float; in vec3 vCol; out vec4 o; void main() { o = vec4(vCol, 1.0); }";
    var quadVertex = [
      "#version 300 es",
      "out vec2 vUV;",
      "void main() {",
      "  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));",
      "  vUV = p; gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);",
      "}",
    ].join("\n");
    var fadeFragment =
      "#version 300 es\nprecision mediump float; uniform float uK; out vec4 o; void main() { o = vec4(uK, uK, uK, 1.0); }";
    var toneFragment = [
      "#version 300 es",
      "precision highp float;",
      "uniform sampler2D uT; uniform float uBloom, uExposure, uGamma, uVignette; uniform vec3 uBackground;",
      "in vec2 vUV; out vec4 o;",
      "void main() {",
      "  vec3 c = texture(uT, vUV).rgb;",
      "  vec3 bloom = textureLod(uT, vUV, 2.0).rgb * 0.5 + textureLod(uT, vUV, 3.5).rgb * 0.45",
      "             + textureLod(uT, vUV, 5.0).rgb * 0.4 + textureLod(uT, vUV, 6.5).rgb * 0.3;",
      "  c = c + bloom * uBloom;",
      "  c = 1.0 - exp(-c * uExposure);", // bright cores burn toward white
      "  float v = smoothstep(1.25, 0.35, length(vUV - 0.5) * 1.6);",
      "  o = vec4(uBackground + pow(c, vec3(uGamma)) * mix(uVignette, 1.0, v), 1.0);",
      "}",
    ].join("\n");
    return {
      pointVertex: pointVertex,
      pointVertexLit: pointVertexLit,
      pointFragment: pointFragment,
      lineVertex: lineVertex,
      lineVertexLit: lineVertexLit,
      lineFragment: lineFragment,
      quadVertex: quadVertex,
      fadeFragment: fadeFragment,
      toneFragment: toneFragment,
    };
  }

  // ---------- how tightly the wires pile up on screen ----------

  // The wire light per pixel where the wires' light lands, before any gain: the light of an
  // even sample of the wires (each wire's brightness as the wire shader computes it, times
  // its length on screen) is spread over a coarse grid of the stage, and the light-weighted
  // mean of the cells' light per pixel is returned, scaled up from the sample to every wire.
  // It grows when the frame packs the wires tightly (many wires through the same cells) and
  // with the number of wires. src: { vectors (stride floats per point), stride, dimension,
  // pairs, lengths, count }; view: a merged draw state plus width and height in pixels.
  function wireDensity(src, view) {
    var m = Math.min(src.count, WIRE_SAMPLE);
    if (m <= 0) return 0;
    var W = view.width;
    var H = view.height;
    var cell = Math.max(2, Math.min(W, H) / WIRE_CELLS);
    var cols = Math.ceil(W / cell);
    var grid = new Float64Array(cols * Math.ceil(H / cell));
    var scale = Math.sqrt(src.dimension / 3);
    var a = new Float64Array(6);
    for (var k = 0; k < m; k++) {
      var e = Math.floor((k * src.count) / m);
      projectInto(src, view, src.pairs[2 * e], a, 0);
      projectInto(src, view, src.pairs[2 * e + 1], a, 3);
      var t = (Math.hypot(a[0] - a[3], a[1] - a[4], a[2] - a[5]) / Math.max(src.lengths[e], 1e-6)) * scale;
      var ends = [screenOf(a, 0, view), screenOf(a, 3, view)];
      var dof = 1 + (view.wireDepthOfField * (ends[0].zf * ends[0].zf + ends[1].zf * ends[1].zf)) / 2;
      splat(grid, cols, cell, ends, ((0.03 + 0.2 * t * t * t) / dof) * (src.count / m));
    }
    var total = 0;
    var squares = 0;
    for (var c of grid) {
      total += c;
      squares += c * c;
    }
    return total > 0 ? squares / total / (cell * cell) : 0;
  }

  // Point i's coordinates along the frame (centred), into out[at .. at + 3).
  function projectInto(src, view, i, out, at) {
    var D = src.dimension;
    var o = i * src.stride;
    var x = 0;
    var y = 0;
    var z = 0;
    for (var d = 0; d < D; d++) {
      var v = src.vectors[o + d] - (view.centre ? view.centre[d] : 0);
      x += v * view.frame[d];
      y += v * view.frame[D + d];
      z += v * view.frame[2 * D + d];
    }
    out[at] = x;
    out[at + 1] = y;
    out[at + 2] = z;
  }

  // Canvas pixels and depth from the focus plane of the coordinates at p[at .. at + 3).
  function screenOf(p, at, view) {
    var q = place([p[at], p[at + 1], p[at + 2]], view, view.width, view.height);
    return { x: q.x, y: q.y, zf: q.depth };
  }

  // Add `light` per pixel of the segment's length along it, cell by cell.
  function splat(grid, cols, cell, ends, light) {
    var dx = ends[1].x - ends[0].x;
    var dy = ends[1].y - ends[0].y;
    var len = Math.max(1, Math.hypot(dx, dy));
    var steps = Math.max(1, Math.ceil(len / cell));
    var rows = grid.length / cols;
    for (var i = 0; i < steps; i++) {
      var f = (i + 0.5) / steps;
      var cx = Math.floor((ends[0].x + dx * f) / cell);
      var cy = Math.floor((ends[0].y + dy * f) / cell);
      if (cx >= 0 && cx < cols && cy >= 0 && cy < rows) grid[cy * cols + cx] += (light * len) / steps;
    }
  }

  // ---------- the screen mapping, in JavaScript (mirrors place() in the shader) ----------

  // p: [x, y, z] coordinates along the frame (already centred). Returns canvas pixels
  // (y grows downward), the perspective scale and the depth relative to the focus plane.
  function place(p, state, width, height) {
    var s = merge(state);
    var cy = Math.cos(s.yaw),
      sy = Math.sin(s.yaw),
      cp = Math.cos(s.pitch),
      sp = Math.sin(s.pitch);
    var R = Math.min(width, height) * s.radius;
    var x = p[0] * s.zoom,
      y = p[1] * s.zoom,
      z = p[2] * s.zoom;
    var x1 = x * cy + z * sy,
      z1 = -x * sy + z * cy;
    var y2 = y * cp - z1 * sp,
      z2 = y * sp + z1 * cp;
    var k = 3 / Math.max(0.6, 3 + z2);
    return { x: width / 2 + x1 * k * R, y: height / 2 - y2 * k * R, scale: k, depth: z2 - s.focus };
  }

  // place() for many points under one state: the state is merged once, not per point
  // (a merge copies every draw parameter into a new object). placer(...)(x, y, z, out)
  // writes out.x and out.y, the same numbers place() returns, and returns out.
  function placer(state, width, height) {
    var s = merge(state);
    var cy = Math.cos(s.yaw),
      sy = Math.sin(s.yaw),
      cp = Math.cos(s.pitch),
      sp = Math.sin(s.pitch);
    var R = Math.min(width, height) * s.radius;
    var zoom = s.zoom;
    return function (p0, p1, p2, out) {
      var x = p0 * zoom,
        y = p1 * zoom,
        z = p2 * zoom;
      var x1 = x * cy + z * sy,
        z1 = -x * sy + z * cy;
      var y2 = y * cp - z1 * sp,
        z2 = y * sp + z1 * cp;
      var k = 3 / Math.max(0.6, 3 + z2);
      out.x = width / 2 + x1 * k * R;
      out.y = height / 2 - y2 * k * R;
      return out;
    };
  }

  function merge(state) {
    var out = {};
    var key;
    for (key in DEFAULTS) out[key] = DEFAULTS[key];
    if (state) {
      for (key in state) {
        if (Object.hasOwn(state, key) && state[key] !== undefined) {
          out[key] = state[key];
        }
      }
    }
    return out;
  }

  function isFloatArray(a) {
    return a instanceof Float32Array || a?.constructor?.name === "Float32Array";
  }

  function isByteArray(a) {
    return a instanceof Uint8Array || a?.constructor?.name === "Uint8Array";
  }

  // The GPU form of the lit values: each clamped to 0..1 (NaN reads as 0), plus 2 where
  // the shared mark is drawn. Written into out[0 .. lit.length).
  function encodeLit(lit, shared, out) {
    for (var i = 0; i < lit.length; i++) {
      var v = lit[i] > 0 ? Math.min(1, lit[i]) : 0;
      out[i] = shared?.[i] ? v + 2 : v;
    }
  }

  // A GPU lit value without its mark: the lit value in 0..1.
  function plainLit(x) {
    return x >= 1.5 ? x - 2 : x;
  }

  function isIndexArray(a) {
    if (a instanceof Uint32Array || a instanceof Int32Array) return true;
    var name = a?.constructor?.name;
    return name === "Uint32Array" || name === "Int32Array";
  }

  // Check a block of points; returns its count.
  function checkPoints(input, dimension) {
    if (!input || !isFloatArray(input.vectors)) throw new TypeError("vectors must be a Float32Array");
    if (input.vectors.length % dimension !== 0) {
      throw new TypeError("vectors length " + input.vectors.length + " is not a multiple of dimension " + dimension);
    }
    var n = input.vectors.length / dimension;
    if (input.count !== undefined && input.count !== n) {
      throw new TypeError("count " + input.count + " does not match vectors (" + n + " points)");
    }
    if (input.colours !== undefined && input.colours !== null) {
      if (!isFloatArray(input.colours) || input.colours.length !== n * 3) {
        throw new TypeError("colours must be a Float32Array of length 3 * count");
      }
    }
    if (input.weights !== undefined && input.weights !== null) {
      if (!isFloatArray(input.weights) || input.weights.length !== n) {
        throw new TypeError("weights must be a Float32Array of length count");
      }
    }
    return n;
  }

  // ---------- one renderer bound to one canvas ----------

  function create(canvas, options) {
    var opts = options || {};
    var gl = null;
    try {
      if (typeof canvas?.getContext === "function") {
        gl = canvas.getContext("webgl2", {
          alpha: !!opts.alpha,
          antialias: false,
          depth: false,
          premultipliedAlpha: false,
          preserveDrawingBuffer: !!opts.preserveDrawingBuffer,
          powerPreference: opts.powerPreference || "high-performance",
        });
      }
    } catch (e) {
      gl = null;
    }
    if (!gl) return unavailable("webgl2-unavailable", "WebGL 2 is not available, so the embedding view cannot be drawn.");

    var onContextChange = typeof opts.onContextChange === "function" ? opts.onContextChange : null;
    var maxTextureSize = wholeOr0(gl.getParameter(gl.MAX_TEXTURE_SIZE));

    // Data kept on the CPU: the source for appends and for a rebuild after context loss.
    var store = {
      dimension: 0,
      count: 0,
      capacity: 0,
      lay: null,
      vectors: null, // Float32Array(capacityRows * pointsPerRow * floatsPerPoint), zero-padded
      attr: null, // Float32Array(capacity * 4): r, g, b, weight
      lit: null, // Float32Array(capacity), encoded lit values (encodeLit), or null: no search
    };
    var wires = { pairs: null, lengths: null, count: 0 };

    var gpu = null; // every GL object lives here; rebuilt after a context loss
    var lost = false;
    var disposed = false;
    var error = null; // set when a rebuild failed
    var hdr = false;
    var needClear = true;
    var wireScale = 1; // the wire crowding factor of the last frame that drew wires

    function track(kind, obj) {
      gpu.objects.push({ kind: kind, obj: obj });
      return obj;
    }

    // A failure while building or uploading: shader-failed for compile and link errors,
    // gpu-failed for anything else a GL call threw.
    function failure(e) {
      var msg = e?.message ? e.message : String(e);
      if (e?.isShaderError) return unavailable("shader-failed", "The view could not be drawn: " + msg);
      return unavailable("gpu-failed", "The view could not be sent to the GPU: " + msg);
    }

    // Drop a half-built GPU state after a failed upload and remember why. The CPU copy
    // is kept, so rebuild() (or a context restore) can try again.
    function failGpu(e) {
      freeGpu();
      gpu = null;
      error = failure(e);
      return error;
    }

    function compile(vsSrc, fsSrc, uniformNames) {
      var prog = track("program", gl.createProgram());
      var pair = [
        [gl.VERTEX_SHADER, vsSrc],
        [gl.FRAGMENT_SHADER, fsSrc],
      ];
      var shaders = [];
      for (var stage of pair) {
        var sh = gl.createShader(stage[0]);
        shaders.push(sh);
        gl.shaderSource(sh, stage[1]);
        gl.compileShader(sh);
        if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
          var log = gl.getShaderInfoLog(sh);
          for (var made of shaders) gl.deleteShader(made);
          throw shaderError("shader did not compile: " + log);
        }
        gl.attachShader(prog, sh);
      }
      gl.linkProgram(prog);
      var linked = gl.getProgramParameter(prog, gl.LINK_STATUS);
      var linkLog = linked ? "" : gl.getProgramInfoLog(prog);
      for (var done of shaders) {
        gl.detachShader(prog, done);
        gl.deleteShader(done);
      }
      if (!linked) throw shaderError("shader program did not link: " + linkLog);
      var u = {};
      for (var name of uniformNames) u[name] = gl.getUniformLocation(prog, name);
      return { program: prog, u: u };
    }

    function floatTexture(width, height, data) {
      var t = track("texture", gl.createTexture());
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, width, height, 0, gl.RGBA, gl.FLOAT, data);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      return t;
    }

    function release(obj) {
      // Delete one tracked GL object now (used when a texture or buffer is replaced).
      for (var i = 0; i < gpu.objects.length; i++) {
        if (gpu.objects[i].obj === obj) {
          deleteObject(gpu.objects[i]);
          gpu.objects.splice(i, 1);
          return;
        }
      }
    }

    function deleteObject(entry) {
      var o = entry.obj;
      if (!o) return;
      if (entry.kind === "texture") gl.deleteTexture(o);
      else if (entry.kind === "buffer") gl.deleteBuffer(o);
      else if (entry.kind === "program") gl.deleteProgram(o);
      else if (entry.kind === "framebuffer") gl.deleteFramebuffer(o);
      else if (entry.kind === "vertexArray") gl.deleteVertexArray(o);
    }

    function freeGpu() {
      if (!gpu) return;
      if (!lost) {
        for (var i = gpu.objects.length - 1; i >= 0; i--) deleteObject(gpu.objects[i]);
      }
      gpu = null;
    }

    // The parts that do not depend on the data: the tone and fade passes and the HDR target.
    function buildBase() {
      var src = shaderSources(layout(4, 1, Math.max(1, maxTextureSize)));
      gpu.tone = compile(src.quadVertex, src.toneFragment, [
        "uT",
        "uBloom",
        "uExposure",
        "uGamma",
        "uVignette",
        "uBackground",
      ]);
      gpu.fade = compile(src.quadVertex, src.fadeFragment, ["uK"]);
      gpu.quadVao = track("vertexArray", gl.createVertexArray());
      hdr = false;
      if (opts.hdr !== false) {
        hdr = !!(gl.getExtension("EXT_color_buffer_float") || gl.getExtension("EXT_color_buffer_half_float"));
      }
      if (hdr) {
        gpu.fbo = track("framebuffer", gl.createFramebuffer());
        gpu.texHdr = track("texture", gl.createTexture());
        // Float targets advertised but not usable here: fall back to direct drawing.
        if (!sizeHdr()) dropHdr();
      }
    }

    // Free the HDR target and draw directly from now on.
    function dropHdr() {
      release(gpu.fbo);
      release(gpu.texHdr);
      gpu.fbo = null;
      gpu.texHdr = null;
      hdr = false;
    }

    function sizeHdr() {
      var w = Math.max(1, wholeOr0(gl.drawingBufferWidth));
      var h = Math.max(1, wholeOr0(gl.drawingBufferHeight));
      if (w === gpu.hdrW && h === gpu.hdrH) return true;
      gl.bindTexture(gl.TEXTURE_2D, gpu.texHdr);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.bindFramebuffer(gl.FRAMEBUFFER, gpu.fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, gpu.texHdr, 0);
      var ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gpu.hdrW = w;
      gpu.hdrH = h;
      needClear = true;
      return ok;
    }

    // Programs whose loop bound and row packing come from the layout.
    function buildPrograms(lay) {
      if (gpu.progLayout?.texelsPerPoint === lay.texelsPerPoint && gpu.progLayout.pointsPerRow === lay.pointsPerRow) {
        return;
      }
      for (var key of ["point", "pointLit", "line", "lineLit"]) {
        if (gpu[key]) release(gpu[key].program);
        gpu[key] = null;
      }
      var src = shaderSources(lay);
      gpu.point = compile(src.pointVertex, src.pointFragment, VIEW_UNIFORMS.concat(POINT_UNIFORMS));
      gpu.line = compile(src.lineVertex, src.lineFragment, VIEW_UNIFORMS.concat(["uGain", "uWireDof"]));
      gpu.progLayout = lay;
      // the frame texture: rows 0..2 the frame, row 3 the centre
      if (gpu.texF) release(gpu.texF);
      gpu.fWidth = lay.texelsPerPoint;
      gpu.fStage = new Float32Array(gpu.fWidth * 4 * 4);
      gpu.texF = floatTexture(gpu.fWidth, 4, gpu.fStage);
    }

    // Upload the whole point store (texture and colour buffer) at its capacity.
    function uploadAllPoints() {
      var lay = store.lay;
      buildPrograms(lay);
      if (gpu.texX) release(gpu.texX);
      gpu.texXRows = lay.rows(store.capacity);
      gpu.texX = floatTexture(lay.width, gpu.texXRows, store.vectors);
      if (gpu.vboPoint) release(gpu.vboPoint);
      if (gpu.vaoPoint) release(gpu.vaoPoint);
      gpu.vaoPoint = track("vertexArray", gl.createVertexArray());
      gl.bindVertexArray(gpu.vaoPoint);
      gpu.vboPoint = track("buffer", gl.createBuffer());
      gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboPoint);
      gl.bufferData(gl.ARRAY_BUFFER, store.attr, gl.DYNAMIC_DRAW);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 16, 0);
      gl.bindVertexArray(null);
      gl.bindBuffer(gl.ARRAY_BUFFER, null);
      // the lit vertex array names the colour buffer just replaced: make it again
      dropLit();
      if (store.lit) uploadLit();
    }

    // Free the lit buffers and their vertex arrays (the lit programs are kept).
    function dropLit() {
      dropPointLit();
      dropWireLit();
    }

    function dropPointLit() {
      if (gpu.vaoPointLit) release(gpu.vaoPointLit);
      if (gpu.vboLit) release(gpu.vboLit);
      gpu.vaoPointLit = null;
      gpu.vboLit = null;
      gpu.litCapacity = 0;
    }

    function dropWireLit() {
      if (gpu.vaoLineLit) release(gpu.vaoLineLit);
      if (gpu.vboWireLit) release(gpu.vboWireLit);
      gpu.vaoLineLit = null;
      gpu.vboWireLit = null;
    }

    // Each wire's lit value, the smaller of its two ends' (the mark removed), once per wire
    // end: 1 only when both ends are lit.
    function wireLitValues() {
      var out = new Float32Array(wires.count * 2);
      for (var e = 0; e < wires.count; e++) {
        var v = Math.min(plainLit(store.lit[wires.pairs[2 * e]]), plainLit(store.lit[wires.pairs[2 * e + 1]]));
        out[2 * e] = v;
        out[2 * e + 1] = v;
      }
      return out;
    }

    // The wires' lit values on the GPU, with a vertex array that reads the wire buffer and
    // them; dropped when there are no lit values, no wires or no wire buffer.
    function uploadWireLit() {
      dropWireLit();
      if (!store.lit || !wires.count || !gpu.vboLine) return;
      gpu.vaoLineLit = track("vertexArray", gl.createVertexArray());
      gl.bindVertexArray(gpu.vaoLineLit);
      gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboLine);
      lineAttributes();
      gpu.vboWireLit = track("buffer", gl.createBuffer());
      gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboWireLit);
      gl.bufferData(gl.ARRAY_BUFFER, wireLitValues(), gl.DYNAMIC_DRAW);
      gl.enableVertexAttribArray(3);
      gl.vertexAttribPointer(3, 1, gl.FLOAT, false, 4, 0);
      gl.bindVertexArray(null);
      gl.bindBuffer(gl.ARRAY_BUFFER, null);
    }

    // Send the CPU lit values to the GPU: one bufferSubData of the current points when the
    // buffer is already the right size, else a new buffer (bufferData of the whole store)
    // and its vertex array. The point vectors and colours are never re-sent here.
    function uploadLit() {
      if (!gpu.pointLit) {
        var src = shaderSources(gpu.progLayout);
        gpu.pointLit = compile(
          src.pointVertexLit,
          src.pointFragment,
          VIEW_UNIFORMS.concat(POINT_UNIFORMS, ["uFilter", "uUnlit"])
        );
        gpu.lineLit = compile(src.lineVertexLit, src.lineFragment, VIEW_UNIFORMS.concat(["uGain", "uWireDof", "uFilter", "uUnlit"]));
      }
      uploadWireLit();
      if (gpu.vboLit && gpu.litCapacity === store.capacity) {
        gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboLit);
        gl.bufferSubData(gl.ARRAY_BUFFER, 0, store.lit.subarray(0, store.count));
        gl.bindBuffer(gl.ARRAY_BUFFER, null);
        return;
      }
      dropPointLit();
      gpu.vaoPointLit = track("vertexArray", gl.createVertexArray());
      gl.bindVertexArray(gpu.vaoPointLit);
      gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboPoint);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 16, 0);
      gpu.vboLit = track("buffer", gl.createBuffer());
      gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboLit);
      gl.bufferData(gl.ARRAY_BUFFER, store.lit, gl.DYNAMIC_DRAW);
      gl.enableVertexAttribArray(1);
      gl.vertexAttribPointer(1, 1, gl.FLOAT, false, 4, 0);
      gl.bindVertexArray(null);
      gl.bindBuffer(gl.ARRAY_BUFFER, null);
      gpu.litCapacity = store.capacity;
    }

    function uploadWires() {
      if (gpu.vboLine) release(gpu.vboLine);
      if (gpu.vaoLine) release(gpu.vaoLine);
      gpu.vboLine = null;
      gpu.vaoLine = null;
      if (!wires.count) return;
      // per vertex, 24 bytes: u32 id, u32 other, f32 true length, f32 r, g, b
      var buf = new ArrayBuffer(wires.count * 2 * 24);
      var u32 = new Uint32Array(buf);
      var f32 = new Float32Array(buf);
      for (var e = 0; e < wires.count; e++) {
        var a = wires.pairs[2 * e],
          b = wires.pairs[2 * e + 1],
          len = wires.lengths[e];
        for (var end = 0; end < 2; end++) {
          var me = end ? b : a,
            other = end ? a : b,
            o = (2 * e + end) * 6;
          u32[o] = me;
          u32[o + 1] = other;
          f32[o + 2] = len;
          f32[o + 3] = store.attr[me * 4];
          f32[o + 4] = store.attr[me * 4 + 1];
          f32[o + 5] = store.attr[me * 4 + 2];
        }
      }
      gpu.vaoLine = track("vertexArray", gl.createVertexArray());
      gl.bindVertexArray(gpu.vaoLine);
      gpu.vboLine = track("buffer", gl.createBuffer());
      gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboLine);
      gl.bufferData(gl.ARRAY_BUFFER, buf, gl.STATIC_DRAW);
      lineAttributes();
      gl.bindVertexArray(null);
      gl.bindBuffer(gl.ARRAY_BUFFER, null);
      if (gpu.lineLit) uploadWireLit(); // the wires' lit vertex array named the old buffer
    }

    // The wire buffer's three attributes (pair, true length, colour) on the bound vertex
    // array, read from the buffer bound to ARRAY_BUFFER.
    function lineAttributes() {
      gl.enableVertexAttribArray(0);
      gl.vertexAttribIPointer(0, 2, gl.UNSIGNED_INT, 24, 0);
      gl.enableVertexAttribArray(1);
      gl.vertexAttribPointer(1, 1, gl.FLOAT, false, 24, 8);
      gl.enableVertexAttribArray(2);
      gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 24, 12);
    }

    // Build (or rebuild after a context loss) every GPU object from the kept data.
    function buildAll() {
      freeGpu();
      gpu = freshGpu();
      try {
        buildBase();
        if (store.lay) {
          uploadAllPoints();
          uploadWires();
        }
        needClear = true;
        return { ok: true };
      } catch (e) {
        freeGpu();
        gpu = null;
        return failure(e);
      }
    }

    // Copy a block of points into the padded store starting at point `at`.
    function writePoints(input, n, at) {
      var d = store.dimension,
        stride = store.lay.floatsPerPoint,
        v = input.vectors;
      var pad = stride !== d;
      if (!pad) {
        store.vectors.set(v, at * stride);
      } else {
        for (var i = 0; i < n; i++) store.vectors.set(v.subarray(i * d, i * d + d), (at + i) * stride);
      }
      var c = input.colours,
        w = input.weights;
      for (var j = 0; j < n; j++) {
        var o = (at + j) * 4;
        store.attr[o] = c ? c[j * 3] : 1;
        store.attr[o + 1] = c ? c[j * 3 + 1] : 1;
        store.attr[o + 2] = c ? c[j * 3 + 2] : 1;
        store.attr[o + 3] = w ? w[j] : 1;
      }
    }

    // Wire endpoints must be point indices, two per wire.
    function checkWirePairs(pairs) {
      if (!isIndexArray(pairs)) throw new TypeError("pairs must be a Uint32Array (or Int32Array)");
      if (pairs.length % 2 !== 0) throw new TypeError("pairs must hold two indices per wire");
      for (var p of pairs) {
        if (p < 0 || p >= store.count) {
          throw new RangeError("wire endpoint " + p + " is not a point index (count " + store.count + ")");
        }
      }
    }

    // The given true lengths (checked), or ones measured from the kept vectors.
    function wireLengths(pairs, lengths, m) {
      if (lengths !== undefined && lengths !== null) {
        if (!isFloatArray(lengths) || lengths.length !== m) throw new TypeError("lengths must be a Float32Array, one per wire");
        return lengths;
      }
      var lens = new Float32Array(m);
      var stride = store.lay ? store.lay.floatsPerPoint : 0;
      for (var e = 0; e < m; e++) {
        var a = pairs[2 * e] * stride,
          b = pairs[2 * e + 1] * stride,
          s = 0;
        for (var k = 0; k < stride; k++) {
          var t = store.vectors[a + k] - store.vectors[b + k];
          s += t * t;
        }
        lens[e] = Math.sqrt(s);
      }
      return lens;
    }

    // The frame (rows 0..2) and the centre (row 3) into the frame texture, on unit 1.
    function uploadFrame(s, D) {
      if (!isFloatArray(s.frame) || s.frame.length !== 3 * D) throw new TypeError("frame must be a Float32Array of length 3 * " + D);
      if (s.centre !== undefined && s.centre !== null && (!isFloatArray(s.centre) || s.centre.length !== D)) {
        throw new TypeError("centre must be a Float32Array of length " + D);
      }
      var st = gpu.fStage,
        row = gpu.fWidth * 4;
      st.fill(0);
      for (var a = 0; a < 3; a++) st.set(s.frame.subarray(a * D, a * D + D), a * row);
      if (s.centre) st.set(s.centre, 3 * row);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, gpu.texF);
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gpu.fWidth, 4, gl.RGBA, gl.FLOAT, st);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, gpu.texX);
    }

    // Wipe the target, or (trails on an HDR target) dim what is already there.
    // Returns the gain to draw with.
    function clearOrFade(s, bg, gain) {
      var fading = hdr && s.trails > 0;
      if (needClear || s.clear || !fading) {
        if (hdr) gl.clearColor(0, 0, 0, 1);
        else gl.clearColor(bg[0], bg[1], bg[2], 1);
        gl.clear(gl.COLOR_BUFFER_BIT);
        needClear = false;
        return gain;
      }
      // dim what is already there instead of wiping it: motion leaves trails
      var k = Math.exp(-Math.max(0, s.dt) / s.trails);
      gl.blendFunc(gl.ZERO, gl.SRC_COLOR);
      gl.useProgram(gpu.fade.program);
      gl.uniform1f(gpu.fade.u.uK, k);
      gl.bindVertexArray(gpu.quadVao);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gain *= (1 - k) * s.trailGain;
      return gain;
    }

    // The uniforms shared by the point and wire programs.
    function setView(p, s, W, H, R) {
      gl.useProgram(p.program);
      gl.uniform1i(p.u.uX, 0);
      gl.uniform1i(p.u.uF, 1);
      gl.uniform4f(p.u.uRot, Math.cos(s.yaw), Math.sin(s.yaw), Math.cos(s.pitch), Math.sin(s.pitch));
      gl.uniform2f(p.u.uView, (2 * R) / W, (2 * R) / H);
      gl.uniform1f(p.u.uZoom, s.zoom);
      gl.uniform1f(p.u.uFocus, s.focus);
    }

    // True when this frame draws with the lit values: some are set and filter is above 0.
    // Otherwise the points are drawn by the program and calls used before search existed.
    function litApplies(s) {
      return store.lit !== null && s.filter > 0 && gpu.vaoPointLit !== null;
    }

    // The wires (when shown), then the points.
    function drawScene(s, gain, W, H) {
      var R = Math.min(W, H) * s.radius;
      var lit = litApplies(s);
      if (wires.count && s.wires > 0.02 && gpu.vaoLine) drawWires(s, gain, W, H, R, lit && gpu.vaoLineLit !== null);
      var prog = lit ? gpu.pointLit : gpu.point;
      var pu = prog.u;
      setView(prog, s, W, H, R);
      gl.uniform1f(pu.uPx, s.pointSize);
      gl.uniform1f(pu.uMinPx, s.minPointSize);
      gl.uniform1f(pu.uFog, s.fog);
      gl.uniform1f(pu.uTime, s.time);
      gl.uniform1f(pu.uGain, gain);
      gl.uniform1f(pu.uDim, s.dim);
      gl.uniform1f(pu.uTwinkle, s.twinkle);
      gl.uniform1f(pu.uDof, s.depthOfField);
      gl.uniform1f(pu.uFogNear, s.fogNear);
      gl.uniform1f(pu.uFogWidth, Math.max(1e-6, s.fogWidth));
      if (lit) {
        gl.uniform1f(pu.uFilter, Math.min(1, s.filter));
        gl.uniform1f(pu.uUnlit, Math.max(0, s.unlitGain));
      }
      gl.bindVertexArray(lit ? gpu.vaoPointLit : gpu.vaoPoint);
      gl.drawArrays(gl.POINTS, 0, store.count);
    }

    // The wires. litWires false: the program and calls used before search existed.
    function drawWires(s, gain, W, H, R, litWires) {
      var prog = litWires ? gpu.lineLit : gpu.line;
      setView(prog, s, W, H, R);
      wireScale = s.wireLoad > 0 ? wireCrowding(s, W, H) : 1;
      gl.uniform1f(prog.u.uGain, wireScale === 1 ? gain * s.wires * s.wireGain : gain * s.wires * s.wireGain * wireScale);
      gl.uniform1f(prog.u.uWireDof, s.wireDepthOfField);
      if (litWires) {
        gl.uniform1f(prog.u.uFilter, Math.min(1, s.filter));
        gl.uniform1f(prog.u.uUnlit, Math.max(0, s.unlitGain));
      }
      gl.bindVertexArray(litWires ? gpu.vaoLineLit : gpu.vaoLine);
      gl.drawArrays(gl.LINES, 0, wires.count * 2);
    }

    // The factor that keeps the wires' light per pixel, where it lands, at s.wireLoad or
    // below: 1 while the wires are spread out, less while the frame packs them tightly.
    function wireCrowding(s, W, H) {
      var view = { ...s, width: W, height: H };
      var src = {
        vectors: store.vectors,
        stride: store.lay.floatsPerPoint,
        dimension: store.dimension,
        pairs: wires.pairs,
        lengths: wires.lengths,
        count: wires.count,
      };
      var light = wireDensity(src, view) * s.wires * s.wireGain * s.gain;
      return light > s.wireLoad ? s.wireLoad / light : 1;
    }

    // Tone-map the HDR target onto the canvas, with the mip-chain bloom.
    function toneMap(s, bg) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.disable(gl.BLEND);
      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, gpu.texHdr);
      gl.generateMipmap(gl.TEXTURE_2D);
      var tu = gpu.tone.u;
      gl.useProgram(gpu.tone.program);
      gl.uniform1i(tu.uT, 2);
      gl.uniform1f(tu.uBloom, s.bloom);
      gl.uniform1f(tu.uExposure, s.exposure);
      gl.uniform1f(tu.uGamma, s.gamma);
      gl.uniform1f(tu.uVignette, s.vignette);
      gl.uniform3f(tu.uBackground, bg[0], bg[1], bg[2]);
      gl.bindVertexArray(gpu.quadVao);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.activeTexture(gl.TEXTURE0);
    }

    // True when the GPU state is whole: not disposed, not lost, no failed build.
    function usable() {
      return !disposed && !lost && gpu !== null && error === null;
    }

    // Makes room for `total` points when the CPU copy is too small: a bigger layout if
    // needed, double the capacity at least, the old points and lit values copied over.
    // Returns { ok: true, reallocated } or the failed layout.
    function growStorage(total) {
      if (total <= store.capacity) return { ok: true, reallocated: false };
      var lay = store.lay;
      if (total > lay.maxPoints) {
        lay = layout(store.dimension, total, maxTextureSize);
        if (!lay.ok) return lay;
      }
      var cap = Math.min(lay.maxPoints, Math.max(total, store.capacity * 2));
      var mem = allocate(lay, cap);
      // points are contiguous at a fixed stride whatever the row packing
      mem.vectors.set(store.vectors.subarray(0, store.count * lay.floatsPerPoint));
      mem.attr.set(store.attr.subarray(0, store.count * 4));
      store.vectors = mem.vectors;
      store.attr = mem.attr;
      if (store.lit) {
        var grown = new Float32Array(cap); // appended points: lit value 0, no mark
        grown.set(store.lit.subarray(0, store.count));
        store.lit = grown;
      }
      store.capacity = cap;
      store.lay = lay;
      return { ok: true, reallocated: true };
    }

    // Uploads only the texture rows the points first..total touch, and their slice of
    // the colour (and lit) buffers.
    function uploadAppended(first, total) {
      var lay = store.lay;
      var P = lay.pointsPerRow,
        r0 = Math.floor(first / P),
        r1 = Math.floor((total - 1) / P),
        rowFloats = lay.width * 4;
      gl.activeTexture(gl.TEXTURE0); // never rely on whichever unit was left active
      gl.bindTexture(gl.TEXTURE_2D, gpu.texX);
      gl.texSubImage2D(
        gl.TEXTURE_2D,
        0,
        0,
        r0,
        lay.width,
        r1 - r0 + 1,
        gl.RGBA,
        gl.FLOAT,
        store.vectors.subarray(r0 * rowFloats, (r1 + 1) * rowFloats)
      );
      gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboPoint);
      gl.bufferSubData(gl.ARRAY_BUFFER, first * 16, store.attr.subarray(first * 4, total * 4));
      if (gpu.vboLit) {
        gl.bindBuffer(gl.ARRAY_BUFFER, gpu.vboLit);
        gl.bufferSubData(gl.ARRAY_BUFFER, first * 4, store.lit.subarray(first, total));
      }
      gl.bindBuffer(gl.ARRAY_BUFFER, null);
    }

    var api = {
      // Replace all points. Returns { ok: true, layout, uploaded } or { ok: false, reason, message }.
      setData: function (input) {
        if (disposed) return unavailable("disposed", "The renderer has been disposed.");
        var d = input?.dimension;
        if (typeof d !== "number" || d < 1 || Math.floor(d) !== d) throw new TypeError("dimension must be a positive integer");
        var n = checkPoints(input, d);
        var lay = layout(d, n, maxTextureSize);
        if (!lay.ok) return lay;
        var cap = Math.max(1, n);
        var mem = allocate(lay, cap);
        store.dimension = d;
        store.count = n;
        store.capacity = cap;
        store.lay = lay;
        store.vectors = mem.vectors;
        store.attr = mem.attr;
        store.lit = null; // a replace starts with no search
        writePoints(input, n, 0);
        wires = { pairs: null, lengths: null, count: 0 };
        needClear = true;
        if (!usable()) return { ok: true, layout: lay, uploaded: false };
        try {
          uploadAllPoints();
          uploadWires();
        } catch (e) {
          return failGpu(e);
        }
        return { ok: true, layout: lay, uploaded: true };
      },

      // Add points after the existing ones. Wires are kept. Returns
      // { ok: true, reallocated, uploaded } (reallocated: the GPU copy was rebuilt at a
      // larger size; uploaded: false when only the CPU copy changed because the context is
      // lost or a build failed).
      appendData: function (input) {
        if (disposed) return unavailable("disposed", "The renderer has been disposed.");
        if (!store.lay) throw new TypeError("appendData needs a prior setData");
        if (input.dimension !== undefined && input.dimension !== store.dimension) {
          throw new TypeError("dimension " + input.dimension + " differs from the data's " + store.dimension);
        }
        var n = checkPoints(input, store.dimension);
        if (n === 0) return { ok: true, reallocated: false, uploaded: usable() };
        var total = store.count + n;
        var grown = growStorage(total);
        if (!grown.ok) return grown;
        var reallocated = grown.reallocated;
        var first = store.count;
        writePoints(input, n, first);
        if (store.lit) store.lit.fill(0, first, total); // appended points: lit value 0, no mark
        store.count = total;
        if (!usable()) return { ok: true, reallocated: reallocated, uploaded: false };
        try {
          if (reallocated) uploadAllPoints();
          else uploadAppended(first, total);
        } catch (e) {
          return failGpu(e);
        }
        return { ok: true, reallocated: reallocated, uploaded: true };
      },

      // Neighbour wires as index pairs (two per wire). lengths: optional true distances,
      // one per wire; measured from the kept vectors when absent.
      setWires: function (pairs, lengths) {
        if (disposed) return unavailable("disposed", "The renderer has been disposed.");
        checkWirePairs(pairs);
        var m = pairs.length / 2;
        var lens = wireLengths(pairs, lengths, m);
        wires = { pairs: new Uint32Array(pairs), lengths: new Float32Array(lens), count: m };
        if (!usable()) return { ok: true, uploaded: false };
        try {
          uploadWires();
        } catch (e) {
          return failGpu(e);
        }
        return { ok: true, uploaded: true };
      },

      // Per-point lit values (Float32Array(count), read as 0..1) and an optional shared mark
      // (Uint8Array(count), 1 = marked); null clears them. Only the lit buffer is uploaded.
      // Returns { ok: true, uploaded } or { ok: false, reason, message }.
      setLit: function (lit, shared) {
        if (disposed) return unavailable("disposed", "The renderer has been disposed.");
        if (lit === null) {
          store.lit = null;
          if (usable()) dropLit();
          return { ok: true, uploaded: usable() };
        }
        if (!store.lay) throw new TypeError("setLit needs a prior setData");
        if (!isFloatArray(lit) || lit.length !== store.count) {
          throw new TypeError("lit must be a Float32Array of length count (" + store.count + ")");
        }
        if (shared !== undefined && shared !== null && (!isByteArray(shared) || shared.length !== store.count)) {
          throw new TypeError("shared must be a Uint8Array of length count (" + store.count + ")");
        }
        if (store.lit?.length !== store.capacity) store.lit = new Float32Array(store.capacity);
        encodeLit(lit, shared, store.lit);
        if (!usable()) return { ok: true, uploaded: false };
        try {
          uploadLit();
        } catch (e) {
          return failGpu(e);
        }
        return { ok: true, uploaded: true };
      },

      // Retry building every GPU object from the CPU copy, after a failed restore or a
      // failed upload. Returns { ok: true } or { ok: false, reason, message }. draw()
      // never retries by itself.
      rebuild: function () {
        if (disposed) return unavailable("disposed", "The renderer has been disposed.");
        if (lost || (typeof gl.isContextLost === "function" && gl.isContextLost())) {
          return unavailable("context-lost", "The graphics context is lost; wait for it to be restored.");
        }
        error = null;
        var res = buildAll();
        if (!res.ok) {
          error = res;
          return res;
        }
        return { ok: true };
      },

      // Set the drawing-buffer size in device pixels.
      resize: function (width, height) {
        if (disposed || !canvas) return;
        var w = Math.max(1, Math.round(width)),
          h = Math.max(1, Math.round(height));
        if (canvas.width !== w) canvas.width = w;
        if (canvas.height !== h) canvas.height = h;
        needClear = true;
      },

      // Draw one frame. state: see DEFAULTS, plus frame (Float32Array 3 * D) and
      // centre (Float32Array D, default zeros). Returns false when nothing could be
      // drawn (disposed, context lost, or a failed build or upload until rebuild()).
      draw: function (state) {
        if (!usable()) return false;
        var s = merge(state);
        var hasData = store.count > 0 && gpu.point;
        if (hasData) uploadFrame(s, store.dimension);
        // the target became unusable at this size; fall back for good
        if (hdr && !sizeHdr()) dropHdr();
        var W = Math.max(1, wholeOr0(gl.drawingBufferWidth)),
          H = Math.max(1, wholeOr0(gl.drawingBufferHeight));
        gl.bindFramebuffer(gl.FRAMEBUFFER, hdr ? gpu.fbo : null);
        gl.viewport(0, 0, W, H);
        gl.disable(gl.DEPTH_TEST);
        gl.enable(gl.BLEND);
        var gain = s.gain * (hdr ? 1 : s.fallbackGain);
        var bg = s.background || DEFAULTS.background;
        gain = clearOrFade(s, bg, gain);
        gl.blendFunc(gl.ONE, gl.ONE);
        if (hasData) drawScene(s, gain, W, H);
        if (hdr) toneMap(s, bg);
        gl.bindVertexArray(null);
        return true;
      },

      status: function () {
        return {
          ok: !disposed && error === null,
          available: true,
          disposed: disposed,
          lost: lost,
          hdr: hdr,
          error: error ? error.message : null,
          dimension: store.dimension,
          count: store.count,
          capacity: store.capacity,
          wires: wires.count,
          wireScale: wireScale,
          lit: store.lit !== null,
          maxTextureSize: maxTextureSize,
          layout: store.lay,
        };
      },

      // Free every GPU object this renderer made and stop listening to the canvas.
      dispose: function () {
        if (disposed) return;
        canvas.removeEventListener("webglcontextlost", onLost);
        canvas.removeEventListener("webglcontextrestored", onRestored);
        freeGpu();
        disposed = true;
        store.vectors = null;
        store.attr = null;
        store.lit = null;
        wires = { pairs: null, lengths: null, count: 0 };
        if (opts.releaseContext && !lost) {
          var ext = gl.getExtension("WEBGL_lose_context");
          if (ext) ext.loseContext();
        }
      },
    };

    function notify(type, message) {
      if (onContextChange) onContextChange({ type: type, message: message || "" });
    }

    function onLost(ev) {
      if (typeof ev?.preventDefault === "function") ev.preventDefault(); // allow a restore
      lost = true;
      if (gpu) gpu = null; // the GPU objects are gone with the context; nothing to delete
      notify("lost", "The graphics context was lost; drawing is paused until it is restored.");
    }

    function onRestored() {
      if (disposed) return;
      lost = false;
      var res = buildAll();
      if (res.ok) {
        error = null;
        notify("restored", "");
      } else {
        error = res;
        notify("restore-failed", res.message);
      }
    }

    canvas.addEventListener("webglcontextlost", onLost, false);
    canvas.addEventListener("webglcontextrestored", onRestored, false);

    var built = buildAll();
    if (!built.ok) {
      api.dispose();
      return built;
    }
    return { ok: true, renderer: api };
  }

  return {
    DEFAULTS: DEFAULTS,
    layout: layout,
    shaderSources: shaderSources,
    wireDensity: wireDensity,
    place: place,
    placer: placer,
    create: create,
  };
})();
// ---------------------------------------------------------------------------
// 39-modes.js: the mode interface and registry (ET.modes).
//
// A mode owns its motion and its draw parameters and nothing else. It never
// touches WebGL or the DOM. Given the loaded set, a seed and the time in the
// mode, it answers a frame (three orthonormal rows of length D), a centre, a
// plain draw-parameter object for ET.renderer.draw, optional wires (index
// pairs) and a one-line plain-text status. The viewer owns the renderer, the
// clock, the data and the DOM.
//
// The three shipped modes live in 40-mode-tumble.js, 41-mode-lattice.js and
// 42-mode-wander.js and register themselves here. A fourth mode registers the
// same way, without touching them or the data contract.
//
// Documented in js/api/40-modes.md.
// ---------------------------------------------------------------------------
ET.modes = (function () {
  // Members every mode instance must have (see js/api/40-modes.md).
  // Optional members: mark(t) (fix the time of a finished event), face(target,
  // t, options) (the swing toward the searches) and, for Tumble, refit(t).
  var INTERFACE = ["enter", "prepare", "isReady", "stateAt", "step", "status", "dataChanged", "describe", "leave"];
  var ID_PATTERN = /^[a-z][a-z0-9-]{0,31}$/;
  var registry = [];

  function copyDef(def) {
    return { id: def.id, title: def.title, summary: def.summary, create: def.create };
  }

  // register({ id, title, summary, create(options) -> instance })
  function register(def) {
    if (!def || typeof def !== "object") throw new TypeError("a mode definition must be an object");
    if (typeof def.id !== "string" || !ID_PATTERN.test(def.id)) {
      throw new TypeError("a mode id must be lower-case letters, digits and hyphens, starting with a letter");
    }
    if (typeof def.title !== "string" || def.title.length === 0) throw new TypeError("a mode needs a title");
    if (typeof def.summary !== "string") throw new TypeError("a mode needs a summary string");
    if (typeof def.create !== "function") throw new TypeError("a mode needs a create(options) function");
    for (var known of registry) {
      if (known.id === def.id) throw new Error("mode '" + def.id + "' is already registered");
    }
    registry.push(copyDef(def));
  }

  function find(id) {
    for (var d of registry) if (d.id === id) return d;
    return null;
  }

  function get(id) {
    var d = find(id);
    return d ? copyDef(d) : null;
  }

  function list() {
    return registry.map(copyDef);
  }

  function ids() {
    return registry.map(function (d) {
      return d.id;
    });
  }

  // Names of interface members the instance lacks ([] when it conforms).
  function check(instance) {
    if (!instance || typeof instance !== "object") return INTERFACE.slice();
    return INTERFACE.filter(function (name) {
      return typeof instance[name] !== "function";
    });
  }

  function create(id, options) {
    var d = find(id);
    if (!d) throw new RangeError("no mode is registered as '" + id + "'");
    var inst = d.create(options || {});
    var missing = check(inst);
    if (missing.length) throw new TypeError("mode '" + id + "' is missing " + missing.join(", "));
    return inst;
  }

  // ----- bounded preparation ------------------------------------------------

  function now() {
    if (typeof performance !== "undefined" && typeof performance?.now === "function") {
      return performance.now();
    }
    return Date.now();
  }

  // A stepper over tasks { run() -> done, required?, weight?, progress?() }.
  // Each run() call does one bounded unit of work. step(budgetMs) runs units
  // until the budget is spent (always at least one); step() with no budget runs
  // everything. The clock only decides how much work happens per call, never
  // what the work computes.
  function stepper(tasks) {
    var list = tasks.slice();
    var units = list.map(function () {
      return 0;
    });
    var finished = list.map(function () {
      return false;
    });
    var api = { done: false, ready: false, progress: 0, step: step };

    // Share of task i done so far: 1 when finished, else its own estimate
    // (kept below 1), else a guess from the units it has run.
    function taskProgress(i) {
      if (finished[i]) return 1;
      if (typeof list[i].progress === "function") return Math.max(0, Math.min(0.999, list[i].progress()));
      return 1 - 1 / (1 + units[i]);
    }

    function refresh() {
      var total = 0;
      var got = 0;
      var ready = true;
      var done = true;
      for (var i = 0; i < list.length; i++) {
        var w = list[i].weight === undefined ? 1 : list[i].weight;
        total += w;
        var p = taskProgress(i);
        got += w * p;
        if (!finished[i]) {
          done = false;
          if (list[i].required) ready = false;
        }
      }
      api.done = done;
      api.ready = ready;
      if (done) api.progress = 1;
      else api.progress = total > 0 ? got / total : 1;
    }

    function step(budgetMs) {
      var limit = budgetMs === undefined ? Infinity : budgetMs;
      var start = now();
      var first = true;
      while (!api.done && (first || now() - start < limit)) {
        first = false;
        for (var i = 0; i < list.length; i++) {
          if (finished[i]) continue;
          units[i]++;
          if (list[i].run()) finished[i] = true;
          break;
        }
        refresh();
      }
      return api.done;
    }

    refresh();
    return api;
  }

  // ----- set statistics (mean, spread), cached per set and extended on append

  var statsCache = typeof WeakMap === "function" ? new WeakMap() : null;

  function addRows(st, X, from, to, D) {
    sumRows(st, X, from, to, D);
    finishStats(st, D);
  }

  // The sums over rows [from, to), without the mean and spread (finishStats).
  function sumRows(st, X, from, to, D) {
    for (var i = from; i < to; i++) {
      var o = i * D;
      for (var d = 0; d < D; d++) {
        var x = X[o + d];
        st.sum[d] += x;
        st.sumSq += x * x;
      }
    }
    st.count = to;
  }

  function finishStats(st, D) {
    var n = st.count;
    var m2 = 0;
    for (var d = 0; d < D; d++) {
      var m = n > 0 ? st.sum[d] / n : 0;
      st.mean[d] = m;
      m2 += m * m;
    }
    var tv = n > 0 ? st.sumSq / n - m2 : 0;
    st.totalVariance = Math.max(tv, 0);
    // Root mean squared distance from the mean: the cloud's typical radius.
    st.radius = Math.sqrt(st.totalVariance) || 1;
  }

  // Cheap check that `set` starts with `previous` (an append of it): same
  // dimension, no fewer points, and the first and last rows of `previous` are
  // equal in both. Not a proof; it catches a wrong `previous` in O(D).
  function isPrefix(previous, set) {
    var D = set.dimension;
    var grows = previous?.count <= set.count; // false for a missing or NaN count too
    if (!previous) return false;
    if (previous.dimension !== D || !grows) return false;
    var n = previous.count;
    if (n === 0) return true;
    var a = previous.vectors;
    var b = set.vectors;
    var last = (n - 1) * D;
    for (var d = 0; d < D; d++) {
      if (a[d] !== b[d] || a[last + d] !== b[last + d]) return false;
    }
    return true;
  }

  // stats(set) -> { count, dimension, mean: Float32Array(D), radius, totalVariance }.
  // O(N * D) the first time for a set; an appended set built from a set seen
  // before (pass it as `previous`) costs O(k * D) for the k new rows.
  // Precondition: `set` is `previous` with points appended. A `previous` that
  // fails the cheap check (isPrefix) is ignored and the stats are recomputed.
  function stats(set, previous) {
    if (statsCache?.has(set)) return statsCache.get(set);
    var D = set.dimension;
    var st;
    var prev = previous && statsCache ? statsCache.get(previous) : null;
    if (prev && isPrefix(previous, set) && prev.count === previous.count) {
      st = { count: prev.count, dimension: D, sum: Float64Array.from(prev.sum), sumSq: prev.sumSq, mean: new Float32Array(D) };
      addRows(st, set.vectors, prev.count, set.count, D);
    } else {
      st = { count: 0, dimension: D, sum: new Float64Array(D), sumSq: 0, mean: new Float32Array(D) };
      addRows(st, set.vectors, 0, set.count, D);
    }
    if (statsCache) statsCache.set(set, st);
    return st;
  }

  // A sliced form of stats(set) for a stepper task. run() adds the next rows
  // (about STATS_WORK values: a few microseconds of compiled arithmetic, under a
  // millisecond on a device that runs JavaScript without a compiler, where the
  // 2^19 values it used to add took 20 to 45 ms) and returns true
  // once the statistics are complete and cached; job.result is then the same
  // object stats(set) returns, with the same values bit for bit (the rows are
  // added in the same order, and the mean and spread are worked out from the
  // finished sums). A set whose statistics are cached finishes at once.
  var STATS_WORK = 1 << 13;
  function statsJob(set) {
    var D = set.dimension;
    var rows = Math.max(1, Math.floor(STATS_WORK / Math.max(1, D)));
    var st = null;
    var job = {
      result: null,
      progress: function () {
        if (job.result) return 1;
        return st && set.count > 0 ? st.count / set.count : 0;
      },
      run: function () {
        if (job.result) return true;
        if (!st && statsCache?.has(set)) {
          job.result = statsCache.get(set);
          return true;
        }
        if (!st) st = { count: 0, dimension: D, sum: new Float64Array(D), sumSq: 0, mean: new Float32Array(D) };
        sumRows(st, set.vectors, st.count, Math.min(set.count, st.count + rows), D);
        if (st.count < set.count) return false;
        finishStats(st, D);
        if (statsCache && !statsCache.has(set)) statsCache.set(set, st);
        job.result = statsCache ? statsCache.get(set) : st;
        return true;
      },
    };
    return job;
  }

  // ----- the fitted directions, kept per set -----------------------------------
  //
  // Tumble and Lattice fit the same strongest directions of the same set (the
  // same seed, the same number of directions, the same rows). The fit is by far
  // the longest preparation there is (700 million multiply-adds for 999 points
  // in 1,024-d: half a second compiled, over a minute on a device that runs
  // JavaScript without a compiler), so a finished fit is kept with its set and
  // the next mode to ask for the same one gets it at once. It is the very result
  // the fit would produce again (ET.math.makeGuidedTour takes it as `pca`), so
  // nothing a mode shows depends on whether it was kept.

  var fitCache = typeof WeakMap === "function" ? new WeakMap() : null;

  function sameFit(e, seed, subspace, sampleRows) {
    return e.seed === seed && e.subspace === subspace && e.sampleRows === sampleRows;
  }

  // The kept fit of `set` for these options, or undefined.
  function fittedDirections(set, seed, subspace, sampleRows) {
    var list = fitCache?.get(set);
    if (!list) return undefined;
    for (var e of list) if (sameFit(e, seed, subspace, sampleRows)) return e.pca;
    return undefined;
  }

  function keepDirections(set, seed, subspace, sampleRows, pca) {
    if (!fitCache || !pca || fittedDirections(set, seed, subspace, sampleRows)) return;
    var list = fitCache.get(set) || [];
    list.push({ seed: seed, subspace: subspace, sampleRows: sampleRows, pca: pca });
    fitCache.set(set, list);
  }

  // ----- shared motion helpers ------------------------------------------------

  // A centre that glides exponentially (time constant tau seconds) from where it
  // is toward a target; retarget(t, target) starts a new segment at time t from
  // wherever the glide is then, so a moved target never makes it jump. Pure in t
  // for a fixed list of retargets.
  function makeGlide(start, target, tau, D) {
    var segs = [{ t0: 0, from: Float64Array.from(start), to: Float64Array.from(target) }];
    function segFor(t) {
      var s = segs[0];
      for (var i = 1; i < segs.length; i++) if (segs[i].t0 <= t) s = segs[i];
      return s;
    }
    function at(t, out) {
      var res = out || new Float32Array(D);
      var s = segFor(t);
      var dt = t - s.t0;
      var k = dt <= 0 ? 1 : Math.exp(-dt / tau);
      for (var d = 0; d < D; d++) res[d] = s.to[d] + (s.from[d] - s.to[d]) * k;
      return res;
    }
    function retarget(t, newTarget) {
      var here = Float64Array.from(at(t));
      // drop segments that start after t: they belonged to a future that changed
      segs = segs.filter(function (s) {
        return s.t0 <= t;
      });
      segs.push({ t0: t, from: here, to: Float64Array.from(newTarget) });
    }
    return { at: at, retarget: retarget };
  }

  // The permutation and signs that alignTo applied to `target` to match `ref`,
  // so the same relabelling of axes can be applied to later frames.
  function alignment(target, ref, D) {
    var aligned = ET.math.alignTo(target, ref, D);
    var perm = [0, 1, 2];
    var sign = [1, 1, 1];
    for (var j = 0; j < 3; j++) {
      var best = 0;
      var bestAbs = -1;
      var bestDot = 0;
      for (var i = 0; i < 3; i++) {
        var dp = 0;
        for (var d = 0; d < D; d++) dp += aligned[j * D + d] * target[i * D + d];
        if (Math.abs(dp) > bestAbs) {
          bestAbs = Math.abs(dp);
          best = i;
          bestDot = dp;
        }
      }
      perm[j] = best;
      sign[j] = bestDot < 0 ? -1 : 1;
    }
    return { perm: perm, sign: sign };
  }

  function applyAlignment(frame, al, D, out) {
    var res = out || new Float32Array(3 * D);
    for (var j = 0; j < 3; j++) {
      var src = al.perm[j] * D;
      var s = al.sign[j];
      for (var d = 0; d < D; d++) res[j * D + d] = s * frame[src + d];
    }
    return res;
  }

  // Copy of an entry state handed to enter({ from }), or null.
  function entryFrom(from, D) {
    if (!from?.frame) return null;
    if (from.frame.length !== 3 * D) return null;
    var e = { frame: new Float32Array(from.frame), centre: null, draw: {} };
    ET.math.orthonormalize(e.frame, 3, D);
    if (from.centre?.length === D) e.centre = new Float32Array(from.centre);
    if (from.draw && typeof from.draw === "object") {
      for (var k in from.draw) {
        if (Object.hasOwn(from.draw, k) && typeof from.draw[k] === "number" && Number.isFinite(from.draw[k])) {
          e.draw[k] = from.draw[k];
        }
      }
    }
    return e;
  }

  // Blend numeric draw parameters from the entry's toward the mode's own over
  // `duration` seconds (smoothstep). Keys the entry lacks are the mode's at once.
  function blendDraw(draw, entry, t, duration) {
    var blending = t < duration; // false for a NaN duration too
    if (!entry || !blending) return draw;
    var e = ET.math.smoothstep(t / duration);
    for (var k in draw) {
      if (Object.hasOwn(entry.draw, k)) draw[k] = entry.draw[k] + (draw[k] - entry.draw[k]) * e;
    }
    return draw;
  }

  // A deterministic starting frame for a mode entered with no previous view.
  var SALT_START = 0x5157a7;
  function startFrame(D, seed) {
    return ET.math.randomFrame(D, ET.math.makeRandom(ET.math.mixSeed(seed, SALT_START)));
  }

  // Auto-framing. The reference's rule is zoom = 0.78 / rms of the projected
  // coordinates. On a guided tour the regions sit far apart as compact blobs,
  // so the outermost ones (and their names) left the stage although the rms was
  // the reference's (measured on the sample set: the tour's 98th-percentile
  // radius is 1.6 times its rms, and the group names sit on the outermost
  // blobs). So the zoom is also capped so that the 98th-percentile radius of the
  // sample lands at AUTO_FIT units, which leaves room for the names inside the
  // shorter side of the stage (the renderer maps 1 unit to 0.46 of it, so the
  // edge is at 1.087 units). zoom = min(0.78 / rms, AUTO_FIT / p98). An even
  // cloud keeps the reference's framing. The sample is fixed (the first
  // `sample` points, 512 by default) so an append past it does not change the
  // framing. A pure function of the data, the frame and the centre.
  var AUTO_FIT = 0.88;
  var radii = new Float64Array(0);
  function autoZoom(X, N, D, frame, centre, sample) {
    var n = Math.min(N, sample || 512);
    if (n <= 0) return 1;
    if (radii.length < n) radii = new Float64Array(n);
    var sq = 0;
    for (var i = 0; i < n; i++) {
      var o = i * D;
      var a = 0;
      var b = 0;
      var c = 0;
      for (var d = 0; d < D; d++) {
        var x = X[o + d] - centre[d];
        a += x * frame[d];
        b += x * frame[D + d];
        c += x * frame[2 * D + d];
      }
      var r2 = a * a + b * b + c * c;
      sq += r2;
      radii[i] = r2;
    }
    return zoomFromRadii(n, sq);
  }

  // The zoom from the first n squared radii (in `radii`) and their sum.
  function zoomFromRadii(n, sq) {
    var rms = Math.sqrt(sq / n);
    var spread = rms > 0; // false for NaN too
    if (!spread) return 1;
    var view = radii.subarray(0, n);
    view.sort();
    var p98 = Math.sqrt(view[Math.min(n - 1, Math.floor(0.98 * (n - 1)))]);
    var zoom = 0.78 / rms;
    return p98 > 0 && AUTO_FIT / p98 < zoom ? AUTO_FIT / p98 : zoom;
  }

  // ----- auto-framing inside a known subspace ---------------------------------
  //
  // autoZoom projects its sample through the frame in full dimension: 3 * n * D
  // multiply-adds on every frame (1.5 million for 512 points in 1,024-d), which
  // on a device that runs JavaScript without a compiler is most of a tenth of a
  // second per frame. A mode whose frames stay inside the span of a few fixed
  // directions (Tumble: the tour's basis; Lattice: the fitted directions and its
  // starting frame) hands those directions over once. A zoom basis keeps them
  // orthonormal (B) with the sample's coordinates along each (Z, one column per
  // direction), and zoomWith() then needs the frame's coefficients in B
  // (3 * k * D) and 3 * k * n more: about a thirtieth of the work.
  //
  // It is a pure function of the data, the directions, the frame and the centre,
  // so the rule that a frame depends on data, seed and time alone still holds.
  // A frame that is not inside the span (a row keeps more than ZOOM_TOL of its
  // length outside it: an entry blend from another view, a turn onto a refitted
  // tour, a swing) is framed by autoZoom itself; which of the two answers
  // depends on the frame and the basis only. Inside the span the two agree to
  // about ZOOM_TOL times the ratio of a point's distance to its projected
  // radius (measured: within 2e-5 of each other, relative, on the demo sets).

  var ZOOM_TOL2 = 1e-10; // a frame row may keep this share of its squared length outside the span
  var ZOOM_PIECE = 1 << 12; // multiply-adds between two pauses while a basis is built

  function removeFrom(q, b, D) {
    var dp = 0;
    for (var d = 0; d < D; d++) dp += q[d] * b[d];
    for (var d2 = 0; d2 < D; d2++) q[d2] -= dp * b[d2];
  }

  // col[i] = (row i of X) . q for i in [from, to).
  function columnPart(X, D, q, col, from, to) {
    for (var i = from; i < to; i++) {
      var o = i * D;
      var s = 0;
      for (var d = 0; d < D; d++) s += X[o + d] * q[d];
      col[i] = s;
    }
  }

  // Add `count` directions (rows of `rows`, D values each) to the basis zb: each
  // is made orthogonal to the ones before it (twice) and normalised, then the
  // sample's coordinates along it are worked out. A direction already inside
  // the span adds a zero row. Pauses (yields) every ZOOM_PIECE multiply-adds or
  // so; where they fall changes nothing.
  function* zoomRowsGen(zb, X, rows, count, work) {
    var D = zb.D;
    var n = zb.n;
    var per = Math.max(1, Math.floor(ZOOM_PIECE / D));
    for (var r = 0; r < count; r++) {
      var q = new Float64Array(D);
      var before = loadDirection(rows, r, D, q);
      for (var pass = 0; pass < 2; pass++) {
        for (var b of zb.B) {
          removeFrom(q, b, D);
          work.done += 2 * D;
          yield;
        }
      }
      var col = new Float64Array(n);
      if (unitOrZero(q, D, before)) {
        for (var i = 0; i < n; i += per) {
          columnPart(X, D, q, col, i, Math.min(n, i + per));
          work.done += per * D;
          yield;
        }
      }
      zb.B.push(q);
      zb.Z.push(col);
    }
    return zb;
  }

  // Row r of `rows` into q; returns its squared length.
  function loadDirection(rows, r, D, q) {
    var before = 0;
    for (var d = 0; d < D; d++) {
      q[d] = rows[r * D + d];
      before += q[d] * q[d];
    }
    return before;
  }

  // q scaled to unit length (true), or set to zero when nothing of the
  // direction it started as (squared length `before`) is left (false).
  function unitOrZero(q, D, before) {
    var nn = 0;
    for (var d = 0; d < D; d++) nn += q[d] * q[d];
    var left = nn > 1e-24 && nn > 1e-12 * before; // false for NaN too
    if (!left) {
      q.fill(0);
      return false;
    }
    var inv = 1 / Math.sqrt(nn);
    for (var d2 = 0; d2 < D; d2++) q[d2] *= inv;
    return true;
  }

  function newZoomBasis(n, D) {
    return { n: n, D: D, B: [], Z: [], coef: null, fast: 0, exact: 0 };
  }

  // A stepper task's job that builds a zoom basis over the first min(N, sample)
  // rows of X from `count` directions (rows of `rows`): { run() -> done,
  // progress(), result }. Each run() is one small piece.
  function zoomBasisJob(X, N, D, rows, count, sample) {
    var n = Math.max(0, Math.min(N, sample || 512));
    return zoomJob(newZoomBasis(n, D), X, rows, count);
  }

  // The same for a copy of `base` with `count` more directions (the base is
  // not changed; the two share what they have in common).
  function zoomExtendJob(base, X, rows, count) {
    var zb = newZoomBasis(base.n, base.D);
    zb.B = base.B.slice();
    zb.Z = base.Z.slice();
    return zoomJob(zb, X, rows, count);
  }

  function zoomJob(zb, X, rows, count) {
    var work = { done: 0 };
    var total = Math.max(1, count * (zb.n * zb.D + 4 * (zb.B.length + count) * zb.D));
    var gen = zoomRowsGen(zb, X, rows, count, work);
    var job = {
      result: null,
      progress: function () {
        return job.result ? 1 : Math.min(0.99, work.done / total);
      },
      run: function () {
        if (job.result) return true;
        if (!gen.next().done) return false;
        job.result = zb;
        return true;
      },
    };
    return job;
  }

  // zoomExtendJob run to the end in one call: `base` with `count` more
  // directions (3 by default: a frame's rows).
  function extendZoomBasis(base, X, rows, count) {
    var job = zoomExtendJob(base, X, rows, count === undefined ? 3 : count);
    var done = job.run();
    while (!done) done = job.run();
    return job.result;
  }

  // The frame's coefficients in the basis, into zb.coef (3 rows of k); false
  // when a row is not inside the span (or is not finite).
  function zoomCoefficients(zb, frame) {
    var D = zb.D;
    var k = zb.B.length;
    if (zb.coef?.length !== 3 * k) zb.coef = new Float64Array(3 * k);
    for (var r = 0; r < 3; r++) {
      var o = r * D;
      var nf = 0;
      for (var d = 0; d < D; d++) nf += frame[o + d] * frame[o + d];
      var got = 0;
      for (var j = 0; j < k; j++) {
        var b = zb.B[j];
        var c = 0;
        for (var d2 = 0; d2 < D; d2++) c += frame[o + d2] * b[d2];
        zb.coef[r * k + j] = c;
        got += c * c;
      }
      var inside = nf - got <= ZOOM_TOL2 * nf; // false for NaN too
      if (!inside) return false;
    }
    return true;
  }

  var zoomA = new Float64Array(0);
  var zoomB = new Float64Array(0);
  var zoomC = new Float64Array(0);

  // autoZoom's answer for a frame inside the basis's span, from the sample's
  // coordinates in the basis; autoZoom itself otherwise (no basis, another
  // sample size, a frame outside the span).
  function zoomWith(zb, X, N, D, frame, centre, sample) {
    var n = Math.min(N, sample || 512);
    var usable = !!zb && zb.n === n && zb.D === D && n > 0;
    if (!usable || !zoomCoefficients(zb, frame)) {
      if (zb) zb.exact++;
      return autoZoom(X, N, D, frame, centre, sample);
    }
    zb.fast++;
    var k = zb.B.length;
    if (zoomA.length < n) {
      zoomA = new Float64Array(n);
      zoomB = new Float64Array(n);
      zoomC = new Float64Array(n);
    }
    if (radii.length < n) radii = new Float64Array(n);
    var f0 = 0;
    var f1 = 0;
    var f2 = 0;
    for (var d = 0; d < D; d++) {
      f0 += centre[d] * frame[d];
      f1 += centre[d] * frame[D + d];
      f2 += centre[d] * frame[2 * D + d];
    }
    zoomA.fill(-f0, 0, n);
    zoomB.fill(-f1, 0, n);
    zoomC.fill(-f2, 0, n);
    for (var j = 0; j < k; j++) {
      var col = zb.Z[j];
      var c0 = zb.coef[j];
      var c1 = zb.coef[k + j];
      var c2 = zb.coef[2 * k + j];
      for (var i = 0; i < n; i++) {
        zoomA[i] += c0 * col[i];
        zoomB[i] += c1 * col[i];
        zoomC[i] += c2 * col[i];
      }
    }
    var sq = 0;
    for (var i2 = 0; i2 < n; i2++) {
      var r2 = zoomA[i2] * zoomA[i2] + zoomB[i2] * zoomB[i2] + zoomC[i2] * zoomC[i2];
      sq += r2;
      radii[i2] = r2;
    }
    return zoomFromRadii(n, sq);
  }

  // The sample set's typical radius (root mean squared distance from the mean,
  // measured: 0.963 at 384-d and 0.968 at 1024-d). The reference's distances
  // (fog, Wander's zoom) were tuned by eye at this scale; modes scale them by
  // radius / REFERENCE_RADIUS so other data looks the same.
  var REFERENCE_RADIUS = 0.963;

  // "12,345": a fixed thousands separator (no locale dependence).
  function thousands(n) {
    var s = String(Math.round(n));
    var neg = s.startsWith("-");
    if (neg) s = s.slice(1);
    var out = "";
    while (s.length > 3) {
      out = "," + s.slice(-3) + out;
      s = s.slice(0, -3);
    }
    return (neg ? "-" : "") + s + out;
  }

  // A point is labelled when its label is non-empty and is not just its id
  // (a labels-only set repeats the id as the label).
  function isLabelled(p) {
    return typeof p?.label === "string" && p.label.trim() !== "" && p.label !== p.id;
  }

  // Throws a RangeError naming the data when a set has too few dimensions.
  function requireDimension(set, min, title) {
    var D = set ? set.dimension : set; // a missing set names itself in the message
    var enough = D >= min; // false for a missing or non-numeric dimension too
    if (!enough) {
      throw new RangeError(
        "the set has dimension " + D + "; " + title + " needs at least " + min + " dimensions",
      );
    }
  }

  // The state a mode shows while it has nothing to move through (no points
  // yet, or still preparing): the hold frame, the entry centre (or zeros) and
  // the entry's draw parameters, no wires.
  function holdState(out, frame, entry, t, status) {
    out.t = t;
    out.frame.set(frame);
    if (entry?.centre) out.centre.set(entry.centre);
    else out.centre.fill(0);
    out.draw = entry ? { ...entry.draw } : { wires: 0, fog: 0 };
    out.wires = null;
    out.focus = null;
    out.status = status;
    return out;
  }

  // What dataChanged returns: more work to pump (or null), and whether mode
  // time restarted at 0 (the mode re-entered; the viewer resets its clock and
  // waits for isReady()).
  function changed(work, restart) {
    return { work: work || null, restart: !!restart };
  }

  var EMPTY_STATUS = "no points yet";

  function checkTime(t) {
    if (!Number.isFinite(t)) throw new RangeError("time must be a finite number");
    // Not Math.max(t, 0): that turns -0 into +0, and -0 is passed through as given.
    if (t < 0) return 0;
    return t;
  }

  // ----- the swing toward the searches (js/api/40-modes.md, "Facing the searches")
  //
  // A swing is an event at a fixed time T. From T to its end U the frame is
  // pulled toward the facing frame Q with weight w = 1 - exp(-PULL (t - T)) while
  // it keeps drifting: the frame is the closed-form solution of the reference's
  // per-frame pull (F += (Q - F)(1 - exp(-2 dt))) with a drift velocity of
  // SWING_DRIFT rad/s per axis whose direction turns at SWING_TURN rad/s, then
  // orthonormalised. The drift's directions are drawn from the view seed and the
  // swing's number, so the frames are a pure function of the calls. The centre
  // and zoom are pulled toward the target's with the same weight. After U the
  // mode's own motion carries on from the state shown at U (each mode file).
  var SWING_DURATION = 6; // seconds of mode time (the reference's)
  var SWING_PULL = 2; // 1/s: the reference's pull, 1 - exp(-2 dt) per frame
  var SWING_DRIFT = 0.21; // rad/s per axis: half the reference tumble's 0.42
  var SWING_TURN = 1.5; // rad/s: how fast the drift's direction turns
  var SALT_SWING = 0x5e1f0c;

  function allFinite(a) {
    for (var x of a) if (!Number.isFinite(x)) return false;
    return true;
  }

  // A checked copy of a facing target { frame, centre, zoom }, or null.
  function faceTarget(target, D) {
    if (!target || typeof target !== "object") return null;
    var f = target.frame;
    var c = target.centre;
    var z = target.zoom;
    if (f?.length !== 3 * D || c?.length !== D) return null;
    var good = z > 0 && Number.isFinite(z); // false for a missing or non-numeric zoom too
    if (!good) return null;
    var frame = Float32Array.from(f);
    var centre = Float32Array.from(c);
    if (!allFinite(frame) || !allFinite(centre)) return null;
    ET.math.orthonormalize(frame, 3, D);
    return { frame: frame, centre: centre, zoom: z };
  }

  // { duration, searches } from face()'s options, or null when the duration is
  // not a positive finite number.
  function swingOptions(options) {
    var o = options || {};
    var duration = o.duration === undefined ? SWING_DURATION : o.duration;
    var good = duration > 0 && Number.isFinite(duration);
    if (!good) return null;
    var n = Math.round(o.searches);
    if (Number.isNaN(n) || n < 1) n = 1; // a missing or non-numeric count is one search
    return { duration: duration, searches: Math.min(4, n) };
  }

  function makeSwing(tg, shown, T, op, seed, index, D) {
    var Q = tg.frame;
    var A = shown.frame;
    // Each target axis is flipped to the shorter turn from the frame shown, so
    // the pull never passes through a row that cancels out.
    for (var r = 0; r < 3; r++) {
      var dp = 0;
      for (var d = 0; d < D; d++) dp += Q[r * D + d] * A[r * D + d];
      if (dp < 0) for (var d2 = 0; d2 < D; d2++) Q[r * D + d2] = -Q[r * D + d2];
    }
    var rng = ET.math.makeRandom(ET.math.mixSeed(ET.math.mixSeed(seed, SALT_SWING), index));
    var H = new Float64Array(6 * D);
    rng.fillGauss(H, 0, 6 * D);
    for (var row = 0; row < 6; row++) {
      var n = 0;
      for (var d3 = 0; d3 < D; d3++) n += H[row * D + d3] * H[row * D + d3];
      n = Math.sqrt(n) || 1;
      for (var d4 = 0; d4 < D; d4++) H[row * D + d4] /= n;
    }
    return {
      index: index,
      T: T,
      U: T + op.duration,
      n: op.searches,
      A: A,
      C0: shown.centre,
      Z0: shown.zoom,
      Q: Q,
      Qc: tg.centre,
      Qz: tg.zoom,
      H: H,
      info: shown.info || null,
      cache: {},
    };
  }

  // The swing's frame and centre at mode time t (clamped to [T, U]) written
  // into `frame` and `centre`; returns the zoom.
  function swingState(s, t, frame, centre) {
    var D = s.Qc.length;
    var tau = Math.min(Math.max(t - s.T, 0), s.U - s.T);
    var k = Math.exp(-SWING_PULL * tau); // 1 - w
    var c = Math.cos(SWING_TURN * tau) - k;
    var sn = Math.sin(SWING_TURN * tau);
    var den = SWING_PULL * SWING_PULL + SWING_TURN * SWING_TURN;
    // The drift's offset: the integral of exp(-PULL (tau - u)) times the turning
    // velocity, in closed form (zero at tau = 0, so the swing starts with no jump).
    var a = (SWING_DRIFT * (SWING_PULL * c + SWING_TURN * sn)) / den;
    var b = (SWING_DRIFT * (SWING_PULL * sn - SWING_TURN * c)) / den;
    var x = new Float64Array(3 * D);
    var H = s.H;
    for (var i = 0; i < 3 * D; i++) x[i] = s.Q[i] + k * (s.A[i] - s.Q[i]) + a * H[i] + b * H[3 * D + i];
    ET.math.orthonormalize(x, 3, D);
    for (var i2 = 0; i2 < 3 * D; i2++) frame[i2] = x[i2];
    for (var d = 0; d < D; d++) centre[d] = s.Qc[d] + k * (s.C0[d] - s.Qc[d]);
    return s.Qz + k * (s.Z0 - s.Qz);
  }

  // The state shown at the swing's end U: { frame, centre, zoom }, computed once.
  function swingEnd(s) {
    if (!s.cache.end) {
      var D = s.Qc.length;
      var e = { frame: new Float32Array(3 * D), centre: new Float32Array(D), zoom: 0 };
      e.zoom = swingState(s, s.U, e.frame, e.centre);
      s.cache.end = e;
    }
    return s.cache.end;
  }

  // How far the mode has come back after the swing: 0 at U, 1 from U + duration on.
  function swingRelease(s, t, duration) {
    var blending = t - s.U < duration; // false for a NaN duration too
    return blending ? ET.math.smoothstep((t - s.U) / duration) : 1;
  }

  // centre := from + (centre - from) e, in place; returns the zoom blended the same way.
  function releaseCentreZoom(end, e, centre, zoom) {
    if (e >= 1) return zoom;
    for (var d = 0; d < centre.length; d++) centre[d] = end.centre[d] + (centre[d] - end.centre[d]) * e;
    return end.zoom + (zoom - end.zoom) * e;
  }

  function swingStatus(s, verb) {
    return "swinging to face " + (s.n > 1 ? "the " + s.n + " searches" : "the search") + ", then " + verb + " on";
  }

  // The swings of one mode entry, in start order. shownAt(T) answers the state
  // shown at T as { frame, centre, zoom, info? } (copies); `info` is kept on the
  // swing for the mode's own use.
  function makeSwings(D, seed) {
    var list = [];

    // The latest swing that has started by t (it may have ended), or null.
    function at(t) {
      for (var i = list.length - 1; i >= 0; i--) if (list[i].T <= t) return list[i];
      return null;
    }

    function face(target, time, options, shownAt) {
      var tg = faceTarget(target, D);
      var op = swingOptions(options);
      if (!tg || !op) return false;
      var T = checkTime(time);
      var last = list.length ? list.at(-1) : null;
      if (last && last.T > T) T = last.T; // a fixed past is never rewritten
      var shown = shownAt(T);
      if (last && last.U > T) {
        last.U = T; // a new swing starts from the frame shown at its time
        last.cache = {};
      }
      list.push(makeSwing(tg, shown, T, op, seed, list.length, D));
      return true;
    }

    // End the newest swing at t if it is in progress then.
    function end(time) {
      var t = checkTime(time);
      var last = list.length ? list.at(-1) : null;
      if (!last || t < last.T || t >= last.U) return false;
      last.U = t;
      last.cache = {};
      return true;
    }

    function describe() {
      var last = list.length ? list.at(-1) : null;
      return last ? { at: last.T, until: last.U } : null;
    }

    return { at: at, face: face, end: end, describe: describe, list: list };
  }

  return {
    INTERFACE: INTERFACE.slice(),
    register: register,
    get: get,
    list: list,
    ids: ids,
    check: check,
    create: create,
    stepper: stepper,
    now: now,
    stats: stats,
    statsJob: statsJob,
    fittedDirections: fittedDirections,
    keepDirections: keepDirections,
    makeGlide: makeGlide,
    alignment: alignment,
    applyAlignment: applyAlignment,
    entryFrom: entryFrom,
    blendDraw: blendDraw,
    startFrame: startFrame,
    autoZoom: autoZoom,
    zoomBasisJob: zoomBasisJob,
    zoomExtendJob: zoomExtendJob,
    extendZoomBasis: extendZoomBasis,
    zoomWith: zoomWith,
    AUTO_FIT: AUTO_FIT,
    REFERENCE_RADIUS: REFERENCE_RADIUS,
    thousands: thousands,
    isLabelled: isLabelled,
    checkTime: checkTime,
    requireDimension: requireDimension,
    holdState: holdState,
    changed: changed,
    isPrefix: isPrefix,
    EMPTY_STATUS: EMPTY_STATUS,
    SWING_DURATION: SWING_DURATION,
    makeSwings: makeSwings,
    swingState: swingState,
    swingEnd: swingEnd,
    swingRelease: swingRelease,
    releaseCentreZoom: releaseCentreZoom,
    swingStatus: swingStatus,
  };
})();
// ---------------------------------------------------------------------------
// 40-mode-tumble.js: Tumble, the guided tour (registered as ET.modes "tumble").
//
// The frame turns inside the span of the data's strongest principal directions
// (ET.math.guidedTour). The frame at time t is the tour's closed-form
// frameAt(t): it depends only on the data, the seed and t. The share of total
// variance those directions hold is reported as a number and in the status
// line. A refit is an event at a fixed time T: before T the old tour, from T
// on the new one, blended in. See js/api/40-modes.md.
// ---------------------------------------------------------------------------
(function () {
  var M = ET.modes;

  var DEFAULTS = {
    subspace: 8, // directions the tour moves through
    speed: 0.42, // rad/s, the reference's rate
    transition: 1.5, // seconds to blend in from the previous view (mode entry only)
    refitTransition: "auto", // seconds to turn onto a refitted tour; "auto" picks it from the turn's size
    refitTransitionMin: 1.5, // "auto" never turns faster than this many seconds
    refitTransitionMax: 12, // nor slower than this many
    fitRows: 4096, // fit the directions on at most this many rows (shares stay exact)
    centreTau: 0.7, // seconds: the camera glides to the data's mean (the reference's)
    zoomSample: 512, // points used for auto-framing
  };

  function create(options) {
    var opt = {};
    for (var k in DEFAULTS) opt[k] = options?.[k] === undefined ? DEFAULTS[k] : options[k];

    var self = {
      time: 0,
      varianceShare: null,
      enter: enter,
      prepare: prepare,
      isReady: isReady,
      stateAt: stateAt,
      step: step,
      status: status,
      dataChanged: dataChanged,
      describe: describe,
      refit: refit,
      mark: mark,
      face: face,
      leave: leave,
    };

    var set = null;
    var D = 0;
    var seed = 0;
    var entry = null;
    var empty = false;
    var emptyReady = false;
    var st = null; // set statistics (mean, radius)
    var glide = null;
    // Fitted tours in switch-time order: { tour, al (alignment or null), t0, share, count,
    // zb (the zoom basis over the tour's directions, M.zoomWith) }.
    // The first has t0 = -Infinity; a refit adds one at its switch time T.
    var tours = [];
    var pending = null; // a finished refit whose switch time is not fixed yet
    var refitRunning = false;
    var requestedAt = null; // the switch time given to refit(t)
    var progress = 0;
    var hold = null;
    var out = null;
    // Each enter() and leave() starts a new generation, and each refit() a new refit
    // generation. A stepper left over from an earlier one (a preparation or refit
    // abandoned midway) does nothing if it is pumped later: it reports done and
    // touches no state, so it can never make the instance ready on old data.
    var gen = 0;
    var refitGen = 0;
    var swings = null; // the swings toward the searches (M.makeSwings)

    function enter(s, opts) {
      M.requireDimension(s, 3, "Tumble");
      var o = opts || {};
      gen++;
      refitGen++;
      set = s;
      D = s.dimension;
      seed = o.seed === undefined ? 0 : o.seed;
      entry = M.entryFrom(o.from, D);
      empty = s.count === 0;
      emptyReady = false;
      st = null;
      glide = null;
      tours = [];
      pending = null;
      refitRunning = false;
      requestedAt = null;
      progress = 0;
      swings = M.makeSwings(D, seed);
      self.time = 0;
      self.varianceShare = null;
      hold = entry ? entry.frame : M.startFrame(D, seed);
      out = { t: 0, frame: new Float32Array(3 * D), centre: new Float32Array(D), draw: null, wires: null, status: "", focus: null };
    }

    // The fit, in small units: centring (ET.math.makeCentre), then the
    // principal directions and the tour (ET.math.makeGuidedTour), each pumped
    // one unit (about a millisecond) per run(). The tour is bit-identical to
    // the blocking ET.math.guidedTour on the same data and seed. Last, the zoom
    // basis over the tour's directions (and, with `extra`, three more rows: the
    // entry frame the first seconds blend from), so that framing a frame of the
    // tour does not cost a pass over the sample in full dimension on every frame.
    function fit(onDone, live, extra) {
      var fitSet = null;
      var cen = null;
      var tourSt = null;
      var tour = null;
      var zoomJob = null;
      var extended = false;
      return [
        {
          required: true,
          weight: 1,
          progress: function () {
            return cen ? cen.progress : 0;
          },
          run: function () {
            if (!live()) return true;
            if (!cen) {
              fitSet = set;
              cen = ET.math.makeCentre(fitSet.vectors, fitSet.count, D);
            }
            return cen.step(0);
          },
        },
        {
          required: true,
          weight: 8,
          progress: function () {
            return tourSt ? tourSt.progress : 0;
          },
          run: function () {
            if (!live()) return true;
            var rows = fitSet.count > opt.fitRows ? opt.fitRows : undefined;
            if (!tourSt) {
              tourSt = ET.math.makeGuidedTour(cen.result.data, fitSet.count, D, {
                seed: seed,
                subspace: opt.subspace,
                speed: opt.speed,
                sampleRows: rows,
                pca: M.fittedDirections(fitSet, seed, opt.subspace, rows),
              });
            }
            if (!tourSt.step(0)) return false;
            tour = tourSt.result;
            M.keepDirections(fitSet, seed, opt.subspace, rows, tour.pca);
            cen = null; // the centred copy is not kept
            tourSt = null;
            return true;
          },
        },
        {
          required: true,
          weight: 0.5,
          progress: function () {
            if (!zoomJob) return 0;
            return extra && !extended ? zoomJob.progress() * 0.7 : zoomJob.progress();
          },
          run: function () {
            if (!live()) return true;
            if (!zoomJob) zoomJob = M.zoomBasisJob(fitSet.vectors, fitSet.count, D, tour.basis, tour.subspace, opt.zoomSample);
            if (!zoomJob.run()) return false;
            if (extra && !extended) {
              extended = true;
              zoomJob = M.zoomExtendJob(zoomJob.result, fitSet.vectors, extra, 3);
              return false;
            }
            onDone(tour, fitSet.count, zoomJob.result);
            return true;
          },
        },
      ];
    }

    function tracked(stp, live) {
      var inner = stp.step;
      stp.step = function (budget) {
        var r = inner(budget);
        if (live()) progress = stp.progress;
        return r;
      };
      return stp;
    }

    // A test of whether the generation `g` is still the current one.
    function liveFor(g) {
      return function () {
        return g === gen;
      };
    }

    function prepare() {
      var live = liveFor(gen);
      if (empty) {
        return M.stepper([
          {
            required: true,
            run: function () {
              if (live()) emptyReady = true;
              return true;
            },
          },
        ]);
      }
      var job = M.statsJob(set);
      var tasks = [
        {
          required: true,
          weight: 1,
          progress: job.progress,
          run: function () {
            if (!live()) return true;
            if (!job.run()) return false;
            st = job.result;
            var start = entry?.centre ? entry.centre : st.mean;
            glide = M.makeGlide(start, st.mean, opt.centreTau, D);
            return true;
          },
        },
      ].concat(
        fit(
          function (tour, count, zb) {
            var al = entry ? M.alignment(tour.frameAt(0), entry.frame, D) : null;
            tours = [{ tour: tour, al: al, t0: -Infinity, share: tour.varianceShare, count: count, zb: zb }];
            self.varianceShare = tour.varianceShare;
          },
          live,
          entry ? entry.frame : null,
        ),
      );
      return tracked(M.stepper(tasks), live);
    }

    function isReady() {
      return empty ? emptyReady : tours.length > 0 && glide !== null;
    }

    function tourFrame(entryT, t, res) {
      var f = entryT.tour.frameAt(t, res);
      if (entryT.al) M.applyAlignment(new Float32Array(f), entryT.al, D, f);
      return f;
    }

    function activeIndex(t) {
      var i = tours.length - 1;
      while (i > 0 && tours[i].t0 > t) i--;
      return i;
    }

    // The frame before the entry blend: the active tour, turned onto from the
    // previous one during a refit's blend.
    function innerFrame(t, res) {
      var i = activeIndex(t);
      var cur = tours[i];
      tourFrame(cur, t, res);
      if (cur.blend && t - cur.t0 < cur.blend.duration) {
        applyRefitBlend(cur.blend, 1 - refitEase((t - cur.t0) / cur.blend.duration), res, D);
      }
      return res;
    }

    function frameAt(t, res) {
      innerFrame(t, res);
      if (entry && t < opt.transition) {
        ET.math.blendFrames(entry.frame, res, ET.math.smoothstep(t / opt.transition), D, res);
      }
      return res;
    }

    function lastSwitch() {
      return tours.length ? tours.at(-1).t0 : -Infinity;
    }

    // Fix a finished refit's switch time. Never earlier than the last switch,
    // so the past already fixed is never rewritten.
    function fixSwitch(T) {
      var t0 = Math.max(T, lastSwitch());
      var shown = innerFrame(t0, new Float32Array(3 * D));
      var al = M.alignment(pending.tour.frameAt(t0), shown, D);
      var next = {
        tour: pending.tour,
        al: al,
        t0: t0,
        share: pending.tour.varianceShare,
        count: pending.count,
        zb: pending.zb,
        blend: null,
      };
      var start = tourFrame(next, t0, new Float32Array(3 * D));
      next.blend = makeRefitBlend(shown, start, D);
      next.blend.duration = refitDuration(next.blend, pending.tour, t0);
      tours.push(next);
      self.varianceShare = pending.tour.varianceShare;
      pending = null;
      refitRunning = false;
      requestedAt = null;
    }

    // How long the turn onto a refitted tour takes. With "auto": long enough
    // that the turn adds at most REFIT_EXTRA times the tour's own mean rate of
    // change at its fastest (so the frame never changes much faster than in
    // normal running), within [refitTransitionMin, refitTransitionMax].
    // A pure function of the blend (the frame shown at the switch and the new
    // tour's start), the new tour and the switch time: tourRate reads only the
    // new tour's closed form, so a later refit cannot change it.
    function refitDuration(bl, tour, t0) {
      if (typeof opt.refitTransition === "number" && opt.refitTransition > 0) return opt.refitTransition;
      var lo = opt.refitTransitionMin;
      var hi = Math.max(lo, opt.refitTransitionMax);
      var v = tourRate(tour, t0);
      var need = v > 0 ? (REFIT_PEAK * bl.rate) / (REFIT_EXTRA * v) : hi;
      // Not Math.min(hi, Math.max(lo, need)): a NaN refitTransitionMin keeps `need` here.
      if (need < lo) return lo;
      if (need > hi) return hi;
      return need;
    }

    // The draw parameters at t. `zoom` is the zoom when the caller has it (a
    // swing sets its own); otherwise the frame is framed through the active
    // tour's zoom basis (M.zoomWith: autoZoom's answer, in the tour's span).
    function drawFor(frame, centre, t, zoom) {
      var sc = st.radius / M.REFERENCE_RADIUS;
      var zb = tours[activeIndex(t)].zb;
      var draw = {
        zoom: zoom === undefined ? M.zoomWith(zb, set.vectors, set.count, D, frame, centre, opt.zoomSample) : zoom,
        wires: 0,
        dim: 1,
        trails: 0.17,
        fog: 0,
        fogNear: 1.2 * sc,
        fogWidth: 0.8 * sc,
        twinkle: 0.18,
        depthOfField: 1.1,
      };
      return M.blendDraw(draw, entry, t, opt.transition);
    }

    function stateAt(time) {
      var t = M.checkTime(time);
      if (!isReady() || empty) return M.holdState(out, hold, entry, t, status(t));
      if (pending) fixSwitch(t); // no time was given: the first query fixes it
      out.t = t;
      var sw = swings.at(t);
      if (sw && t < sw.U) {
        var zoom = M.swingState(sw, t, out.frame, out.centre);
        out.draw = drawFor(out.frame, out.centre, t, zoom);
        out.draw.zoom = zoom;
      } else {
        frameAt(t, out.frame);
        glide.at(t, out.centre);
        if (sw) released(sw, t);
        out.draw = drawFor(out.frame, out.centre, t);
        if (sw) out.draw.zoom = M.releaseCentreZoom(M.swingEnd(sw), M.swingRelease(sw, t, opt.transition), out.centre, out.draw.zoom);
      }
      out.wires = null;
      out.focus = null;
      out.status = status(t);
      return out;
    }

    // After a swing ends at U, Tumble turns back onto its tour from the frame
    // shown at U the way it turns onto a refitted tour: the tour's axes are
    // relabelled (order and sign) to match that frame, and a fixed rotation that
    // takes the tour's frame at U to the frame shown unwinds along refitEase over
    // a length chosen as for a refit ("auto": the turn adds at most half the
    // tour's mean rate). A blend over `transition` seconds, as on entry, turned up
    // to five times faster than the tour moves (measured). The centre and zoom
    // come back over `transition` (stateAt).
    function released(sw, t) {
      var c = sw.cache;
      if (!c.turn) {
        var end = M.swingEnd(sw);
        var raw = frameAt(sw.U, new Float32Array(3 * D));
        c.al = M.alignment(raw, end.frame, D);
        var start = M.applyAlignment(raw, c.al, D);
        c.turn = makeRefitBlend(end.frame, start, D);
        c.turn.duration = refitDuration(c.turn, tours[activeIndex(sw.U)].tour, sw.U);
      }
      M.applyAlignment(new Float32Array(out.frame), c.al, D, out.frame);
      var u = (t - sw.U) / c.turn.duration;
      if (u < 1) applyRefitBlend(c.turn, 1 - refitEase(u), out.frame, D);
    }

    // The swing toward the searches (js/api/40-modes.md, "Facing the searches").
    // face(null, t) ends a swing in progress at t.
    function face(target, time, options) {
      if (!isReady() || empty) return false;
      if (target === null) return swings.end(time);
      return swings.face(target, time, options, function (T) {
        var s = stateAt(T);
        return { frame: new Float32Array(s.frame), centre: new Float32Array(s.centre), zoom: s.draw.zoom };
      });
    }

    function step(dt) {
      self.time = Math.max(0, self.time + dt);
      return stateAt(self.time);
    }

    function status(time) {
      var t = M.checkTime(time === undefined ? self.time : time);
      if (empty) return M.EMPTY_STATUS;
      if (!isReady()) return "finding the strongest directions in " + D + "-d … " + Math.round(progress * 100) + "%";
      var sw = swings.at(t);
      if (sw && t < sw.U) return M.swingStatus(sw, "tumbling");
      var cur = tours[activeIndex(t)];
      var s = "tour of " + cur.tour.subspace + " strongest directions · " + (cur.share * 100).toFixed(1) + "% of variance";
      var since = set.count - cur.count;
      if (since > 0) s += " · before " + M.thousands(since) + " new points";
      return s;
    }

    function snapshot(t) {
      var s = stateAt(t);
      var from = { frame: new Float32Array(s.frame), centre: null, draw: { ...s.draw } };
      if (!empty || entry?.centre) from.centre = new Float32Array(s.centre);
      return from;
    }

    // Append: keep the tour (no jump); the camera glides to the new mean; the
    // reported share is marked stale until refit(). The first points onto an
    // empty set, a replace, or another dimension: start over from the view.
    function dataChanged(newSet, info) {
      var i = info || {};
      var t = i.t === undefined ? self.time : M.checkTime(i.t);
      if (i.op !== "append" || newSet.dimension !== D || empty || !isReady()) {
        var from = isReady() ? snapshot(t) : entry;
        enter(newSet, { seed: seed, from: from });
        return M.changed(prepare(), true);
      }
      var old = set;
      set = newSet;
      st = M.stats(newSet, old);
      glide.retarget(t, st.mean);
      return M.changed(null, false);
    }

    // Fit the directions again on the current data. Returns a stepper. The
    // switch to the new tour happens at time `t` when given (never earlier than
    // a previous switch); otherwise at mark(t) or the first stateAt after the
    // stepper is done. From the switch it turns onto the new tour over the
    // refit turn's duration (refitDuration). A stepper from an earlier refit()
    // or entry does nothing.
    function refit(t) {
      if (empty || !isReady()) return prepare();
      refitRunning = true;
      requestedAt = t === undefined ? null : M.checkTime(t);
      refitGen++;
      var g = gen;
      var rg = refitGen;
      return M.stepper(
        fit(
          function (tour, count, zb) {
            pending = { tour: tour, count: count, zb: zb };
            if (requestedAt !== null) fixSwitch(requestedAt);
          },
          function () {
            return g === gen && rg === refitGen;
          },
        ),
      );
    }

    // Fix the time of a finished event (a refit waiting for its switch).
    function mark(time) {
      if (pending) fixSwitch(M.checkTime(time));
    }

    function describe() {
      var last = tours.length ? tours.at(-1) : null;
      var fittedCount = last ? last.count : 0;
      return {
        id: "tumble",
        projection: "linear: a guided tour, a turning orthonormal 3-frame inside the span of the strongest principal directions",
        seed: seed,
        subspace: last ? last.tour.subspace : opt.subspace,
        speed: opt.speed,
        varianceShare: self.varianceShare,
        varianceShareStale: isReady() && !empty ? set.count !== fittedCount : false,
        pointsSinceFit: isReady() && !empty ? set.count - fittedCount : 0,
        fittedRows: last?.tour.pca ? last.tour.pca.sampledRows : 0,
        method: last?.tour.pca ? last.tour.pca.method : null,
        refitAt: last?.t0 > -Infinity ? last.t0 : null,
        refitTransition: last?.blend ? last.blend.duration : null,
        refitPending: refitRunning,
        facing: swings ? swings.describe() : null,
        empty: empty,
      };
    }

    function leave() {
      gen++;
      refitGen++;
      tours = [];
      pending = null;
      set = null;
      st = null;
      glide = null;
    }

    return self;
  }

  // ----- the turn onto a refitted tour ---------------------------------------
  //
  // At the switch time T the frame shown is A (three orthonormal rows) and the
  // new tour starts at B. The turn is a fixed rotation Q of the whole space
  // with Q B = A, made of a rotation inside B's span (3 x 3, Z) and rotations
  // in mutually orthogonal planes taking B's principal vectors to A's (the
  // shortest turn between the two spans). During the blend the frame is
  // Q(s) applied to the new tour's moving frame, with s going from 1 to 0
  // along refitEase: the tour moves at its own rate (a rotation does not change
  // it) and the turn adds a rate that the duration keeps small. Q(s) is a
  // rotation for every s, so the frame stays orthonormal and never folds.

  var REFIT_RAMP = 0.25; // refitEase speeds up over the first quarter and slows down over the last
  var REFIT_PEAK = 1 / (1 - REFIT_RAMP); // refitEase's largest slope
  var REFIT_EXTRA = 0.5; // the turn adds at most this share of the tour's mean rate
  var REFIT_TINY = 1e-6; // angles (radians) and off-span parts below this do not turn

  // Progress 0..1 with an even rate in the middle and smooth ends.
  function refitEase(u) {
    var x = Math.min(1, Math.max(0, u));
    var a = REFIT_RAMP;
    if (x > 1 - a) return 1 - refitEase(1 - x);
    if (x < a) {
      var y = x / a;
      return REFIT_PEAK * a * (y * y * y - (y * y * y * y) / 2);
    }
    return REFIT_PEAK * (a / 2 + x - a);
  }

  function dotRows(P, i, Q, j, D) {
    var s = 0;
    for (var d = 0; d < D; d++) s += P[i * D + d] * Q[j * D + d];
    return s;
  }

  function makeRefitBlend(A, B, D) {
    // M = A B^T (3 x 3) = U S V^T by the eigenvectors of M^T M.
    var Mt = crossDots(A, B, D);
    var V = ET.math.symmetricEigen(columnGram(Mt), 3).vectors; // row j: v_j
    var U = new Float64Array(9); // row j: u_j
    leftVector(Mt, V, U, 0);
    leftVector(Mt, V, U, 1);
    completeRotation(U, V);
    var pv = principalVectors(A, B, U, V, D);
    var turns = planeTurns(pv.Ap, pv.Bp, D);
    var span = axisAngle(spanRotation(V, U));
    var bl = { Bp: pv.Bp, Tp: turns.Tp, theta: turns.theta, K: span.K, phi: span.phi, duration: 0, rate: 0 };
    bl.rate = blendRate(bl, B, D);
    return bl;
  }

  // M = A B^T as 3 x 3, row-major: M[i][j] = A_i . B_j.
  function crossDots(A, B, D) {
    var Mt = new Float64Array(9);
    for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) Mt[i * 3 + j] = dotRows(A, i, B, j, D);
    return Mt;
  }

  // M^T M (3 x 3).
  function columnGram(Mt) {
    var MtM = new Float64Array(9);
    for (var a = 0; a < 3; a++) {
      for (var b = 0; b < 3; b++) {
        var s0 = 0;
        for (var k = 0; k < 3; k++) s0 += Mt[k * 3 + a] * Mt[k * 3 + b];
        MtM[a * 3 + b] = s0;
      }
    }
    return MtM;
  }

  // Row jj (0 or 1) of U: M v_jj, made orthogonal to u_0 (row 1) and normalised.
  function leftVector(Mt, V, U, jj) {
    var n = 0;
    for (var r = 0; r < 3; r++) {
      var x = 0;
      for (var c = 0; c < 3; c++) x += Mt[r * 3 + c] * V[jj * 3 + c];
      U[jj * 3 + r] = x;
    }
    if (jj === 1) {
      var dp = U[3] * U[0] + U[4] * U[1] + U[5] * U[2];
      for (var r1 = 0; r1 < 3; r1++) U[3 + r1] -= dp * U[r1];
    }
    for (var r2 = 0; r2 < 3; r2++) n += U[jj * 3 + r2] * U[jj * 3 + r2];
    if (n > 1e-18) {
      n = Math.sqrt(n);
      for (var r3 = 0; r3 < 3; r3++) U[jj * 3 + r3] /= n;
    } else {
      fallbackLeftVector(U, jj);
    }
  }

  // M has (almost) no part along v_jj: any unit vector orthogonal to the earlier ones.
  function fallbackLeftVector(U, jj) {
    var best = leastCoveredAxis(U, jj);
    for (var r4 = 0; r4 < 3; r4++) U[jj * 3 + r4] = r4 === best ? 1 : 0;
    if (jj === 1) orthonormaliseSecondRow(U);
  }

  // The standard axis least covered by u_0 (axis 0 for row 0).
  function leastCoveredAxis(U, jj) {
    var best = 0;
    var bestCover = Infinity;
    for (var e = 0; e < 3; e++) {
      var cover = jj === 0 ? 0 : Math.abs(U[e]);
      if (cover < bestCover) {
        bestCover = cover;
        best = e;
      }
    }
    return best;
  }

  // Row 1 of U made orthogonal to row 0, then unit length.
  function orthonormaliseSecondRow(U) {
    var dp2 = U[3] * U[0] + U[4] * U[1] + U[5] * U[2];
    var n2 = 0;
    for (var r5 = 0; r5 < 3; r5++) {
      U[3 + r5] -= dp2 * U[r5];
      n2 += U[3 + r5] * U[3 + r5];
    }
    n2 = Math.sqrt(n2);
    for (var r6 = 0; r6 < 3; r6++) U[3 + r6] /= n2;
  }

  // u_2 completes U so that Z = V^T U is a rotation (det +1).
  function completeRotation(U, V) {
    var detV =
      V[0] * (V[4] * V[8] - V[5] * V[7]) - V[1] * (V[3] * V[8] - V[5] * V[6]) + V[2] * (V[3] * V[7] - V[4] * V[6]);
    var sg = detV < 0 ? -1 : 1;
    U[6] = sg * (U[1] * U[5] - U[2] * U[4]);
    U[7] = sg * (U[2] * U[3] - U[0] * U[5]);
    U[8] = sg * (U[0] * U[4] - U[1] * U[3]);
  }

  // Principal vectors B'_j = sum_k v_j[k] B_k and A'_j = sum_k u_j[k] A_k.
  function principalVectors(A, B, U, V, D) {
    var Bp = new Float64Array(3 * D);
    var Ap = new Float64Array(3 * D);
    for (var j2 = 0; j2 < 3; j2++) {
      for (var k2 = 0; k2 < 3; k2++) {
        var wv = V[j2 * 3 + k2];
        var wu = U[j2 * 3 + k2];
        for (var d = 0; d < D; d++) {
          Bp[j2 * D + d] += wv * B[k2 * D + d];
          Ap[j2 * D + d] += wu * A[k2 * D + d];
        }
      }
    }
    return { Bp: Bp, Ap: Ap };
  }

  // Plane j turns B'_j toward T_j by theta_j, ending at A'_j. T_j is the part
  // of A'_j off B's span, so it is made orthogonal to all three B'_k (in exact
  // arithmetic it already is). When that part is below REFIT_TINY (float32
  // frames carry noise near 1e-7) the plane does not turn: dividing by it would
  // only blow noise up into a direction. The one exception is a reversed
  // principal vector (A'_j = -B'_j, a half turn), which turns through a
  // direction off B's span and off the planes before it; with no room for one
  // (D = 3) it is left as it is.
  function planeTurns(Ap, Bp, D) {
    var Tp = new Float64Array(3 * D);
    var theta = new Float64Array(3);
    for (var j3 = 0; j3 < 3; j3++) theta[j3] = planeTurn(Ap, Bp, Tp, j3, D);
    return { Tp: Tp, theta: theta };
  }

  // Plane j's direction (written into row j of Tp) and angle.
  function planeTurn(Ap, Bp, Tp, j3, D) {
    var cth = dotRows(Ap, j3, Bp, j3, D);
    for (var d2 = 0; d2 < D; d2++) Tp[j3 * D + d2] = Ap[j3 * D + d2];
    var nn = offSpan(Tp, j3, Bp, Tp, 0, D);
    if (nn > REFIT_TINY) {
      for (var d3 = 0; d3 < D; d3++) Tp[j3 * D + d3] /= nn;
      return Math.atan2(nn, cth);
    }
    if (cth < 0 && halfTurnDirection(Tp, j3, Bp, D)) return Math.PI;
    for (var d4 = 0; d4 < D; d4++) Tp[j3 * D + d4] = 0;
    return 0;
  }

  // Z = V^T U: Z[i][j] = v_i . u_j.
  function spanRotation(V, U) {
    var Z = new Float64Array(9);
    for (var zi = 0; zi < 3; zi++) {
      for (var zj = 0; zj < 3; zj++) {
        Z[zi * 3 + zj] = V[zi * 3] * U[zj * 3] + V[zi * 3 + 1] * U[zj * 3 + 1] + V[zi * 3 + 2] * U[zj * 3 + 2];
      }
    }
    return Z;
  }

  // Z as an axis and angle (Z = exp(phi K)): { K, phi }, with phi 0 and K zero
  // when there is no turn inside the span.
  function axisAngle(Z) {
    var cphi = (Z[0] + Z[4] + Z[8] - 1) / 2;
    var phi = Math.acos(Math.max(-1, Math.min(1, cphi)));
    var K = new Float64Array(9);
    var axis = turnAxis(Z, phi);
    if (axis) {
      K[1] = -axis[2];
      K[2] = axis[1];
      K[3] = axis[2];
      K[5] = -axis[0];
      K[6] = -axis[1];
      K[7] = axis[0];
    } else {
      phi = 0;
    }
    return { K: K, phi: phi };
  }

  // Below REFIT_TINY there is no turn inside the span (its axis would be noise):
  // null. A small sine with a large angle is a half turn, found from Z + I.
  function turnAxis(Z, phi) {
    var sphi = Math.sin(phi);
    if (phi > REFIT_TINY && sphi > 1e-6) {
      return [(Z[7] - Z[5]) / (2 * sphi), (Z[2] - Z[6]) / (2 * sphi), (Z[3] - Z[1]) / (2 * sphi)];
    }
    if (phi > Math.PI / 2) return halfTurnAxis(Z);
    return null;
  }

  // A half turn: Z + I = 2 n n^T.
  function halfTurnAxis(Z) {
    var bi = 0;
    for (var q = 1; q < 3; q++) if (Z[q * 4] > Z[bi * 4]) bi = q;
    var len = Math.sqrt(Math.max((Z[bi * 4] + 1) / 2, 1e-300));
    var axis = [0, 0, 0];
    for (var q2 = 0; q2 < 3; q2++) axis[q2] = (Z[q2 * 3 + bi] + (q2 === bi ? 1 : 0)) / (4 * len);
    return axis;
  }

  // Row j of T made orthogonal (twice) to the three rows of B and to rows 0..k-1
  // of P; returns the remaining length.
  function offSpan(T, j, B, P, k, D) {
    var o = j * D;
    for (var pass = 0; pass < 2; pass++) {
      for (var r = 0; r < 3 + k; r++) {
        if (r < 3) removeComponent(T, o, B, r * D, D);
        else removeComponent(T, o, P, (r - 3) * D, D);
      }
    }
    var n = 0;
    for (var d3 = 0; d3 < D; d3++) n += T[o + d3] * T[o + d3];
    return Math.sqrt(n);
  }

  // The row of T at offset o minus its component along the row of R at offset orr.
  function removeComponent(T, o, R, orr, D) {
    var dp = 0;
    for (var d = 0; d < D; d++) dp += T[o + d] * R[orr + d];
    for (var d2 = 0; d2 < D; d2++) T[o + d2] -= dp * R[orr + d2];
  }

  // A unit direction for a half turn of plane j: the standard basis vector that
  // keeps most of its length off B's span and off the plane directions before j
  // (lowest index on a tie), written into row j of Tp. False when there is none.
  function halfTurnDirection(Tp, j, Bp, D) {
    var best = -1;
    var bestLen = 1e-3; // with room, the best keeps at least sqrt((D - 3 - j) / D)
    for (var e = 0; e < D; e++) {
      for (var d = 0; d < D; d++) Tp[j * D + d] = d === e ? 1 : 0;
      var len = offSpan(Tp, j, Bp, Tp, j, D);
      if (len > bestLen) {
        bestLen = len;
        best = e;
      }
    }
    if (best < 0) return false;
    for (var d2 = 0; d2 < D; d2++) Tp[j * D + d2] = d2 === best ? 1 : 0;
    var n = offSpan(Tp, j, Bp, Tp, j, D);
    for (var d3 = 0; d3 < D; d3++) Tp[j * D + d3] /= n;
    return true;
  }

  // Q(s) applied to the rows of F, in place. The turned rows are orthonormalised
  // once, in double precision, before they are stored: a second pass on the
  // stored float32 rows changes no entry by more than about 1e-7 (tested).
  function applyRefitBlend(bl, s, F, D) {
    var x = new Float64Array(3 * D);
    for (var i = 0; i < 3 * D; i++) x[i] = F[i];
    rotateRows(bl, s, x, D);
    ET.math.orthonormalize(x, 3, D);
    for (var i2 = 0; i2 < 3 * D; i2++) F[i2] = x[i2];
    return F;
  }

  function rotateRows(bl, s, x, D) {
    if (s === 0) return x;
    var Z = spanTurnAt(bl.K, Math.sin(s * bl.phi), 1 - Math.cos(s * bl.phi));
    for (var r = 0; r < 3; r++) {
      var o = r * D;
      turnRowInSpan(x, o, bl.Bp, Z, D);
      turnRowInPlanes(x, o, bl, s, D);
    }
    return x;
  }

  // The turn inside B's span at this point of the blend: I + sn K + cm K^2.
  function spanTurnAt(K, sn, cm) {
    var Z = new Float64Array(9);
    for (var a = 0; a < 3; a++) {
      for (var b = 0; b < 3; b++) {
        var k2 = K[a * 3] * K[b] + K[a * 3 + 1] * K[3 + b] + K[a * 3 + 2] * K[6 + b];
        Z[a * 3 + b] = (a === b ? 1 : 0) + sn * K[a * 3 + b] + cm * k2;
      }
    }
    return Z;
  }

  // The row at offset o, its part in the span of Bp turned by Z.
  function turnRowInSpan(x, o, Bp, Z, D) {
    var c0 = 0;
    var c1 = 0;
    var c2 = 0;
    for (var d = 0; d < D; d++) {
      c0 += x[o + d] * Bp[d];
      c1 += x[o + d] * Bp[D + d];
      c2 += x[o + d] * Bp[2 * D + d];
    }
    var e0 = c0 * Z[0] + c1 * Z[3] + c2 * Z[6] - c0;
    var e1 = c0 * Z[1] + c1 * Z[4] + c2 * Z[7] - c1;
    var e2 = c0 * Z[2] + c1 * Z[5] + c2 * Z[8] - c2;
    for (var d2 = 0; d2 < D; d2++) x[o + d2] += e0 * Bp[d2] + e1 * Bp[D + d2] + e2 * Bp[2 * D + d2];
  }

  // The row at offset o turned in each plane (B'_j, T_j) by s * theta_j.
  function turnRowInPlanes(x, o, bl, s, D) {
    var Bp = bl.Bp;
    var Tp = bl.Tp;
    for (var j = 0; j < 3; j++) {
      var th = s * bl.theta[j];
      if (th === 0) continue;
      var oj = j * D;
      var p = 0;
      var q = 0;
      for (var d3 = 0; d3 < D; d3++) {
        p += x[o + d3] * Bp[oj + d3];
        q += x[o + d3] * Tp[oj + d3];
      }
      var cs = Math.cos(th) - 1;
      var si = Math.sin(th);
      var wb = p * cs - q * si;
      var wt = p * si + q * cs;
      for (var d4 = 0; d4 < D; d4++) x[o + d4] += wb * Bp[oj + d4] + wt * Tp[oj + d4];
    }
  }

  // How fast the turn moves the frame per unit of s (Frobenius norm of the
  // change, largest over s), measured on the new tour's starting frame B.
  function blendRate(bl, B, D) {
    var h = 1e-4;
    var worst = 0;
    var x0 = new Float64Array(3 * D);
    var x1 = new Float64Array(3 * D);
    for (var k = 0; k <= 8; k++) {
      var s0 = Math.max(0, k / 8 - h);
      var s1 = Math.min(1, k / 8 + h);
      for (var i = 0; i < 3 * D; i++) {
        x0[i] = B[i];
        x1[i] = B[i];
      }
      rotateRows(bl, s0, x0, D);
      rotateRows(bl, s1, x1, D);
      var n = 0;
      for (var i2 = 0; i2 < 3 * D; i2++) n += (x1[i2] - x0[i2]) * (x1[i2] - x0[i2]);
      var rate = Math.sqrt(n) / (s1 - s0);
      if (rate > worst) worst = rate;
    }
    return worst;
  }

  // The tour's mean rate of change (Frobenius norm per second of mode time)
  // over the 12 s from t0, sampled every half second. The frame is the
  // coefficients times an orthonormal basis, so the coefficients' rate is the
  // frame's.
  function tourRate(tour, t0) {
    var h = 1e-3;
    var m = tour.subspace;
    var a = new Float64Array(3 * m);
    var b = new Float64Array(3 * m);
    var sum = 0;
    for (var k = 0; k < 24; k++) {
      var t = t0 + k * 0.5;
      tour.coefficientsAt(t, a);
      tour.coefficientsAt(t + h, b);
      var n = 0;
      for (var i = 0; i < 3 * m; i++) n += (b[i] - a[i]) * (b[i] - a[i]);
      sum += Math.sqrt(n) / h;
    }
    return sum / 24;
  }

  // The turn's pieces, for tests and for a mode written elsewhere.
  M.refitTurn = {
    make: makeRefitBlend,
    apply: applyRefitBlend,
    ease: refitEase,
    tourRate: tourRate,
  };

  M.register({
    id: "tumble",
    title: "Tumble",
    summary: "The window turns through the strongest directions",
    create: create,
  });
})();
// ---------------------------------------------------------------------------
// 41-mode-lattice.js: Lattice (registered as ET.modes "lattice").
//
// Points are wired to their true nearest neighbours, measured in the full
// space (ET.math.makeKnn, run in bounded slices). One visible axis at a time
// is turned a quarter turn into a hidden direction (ET.math.makeSwapTour), so
// the frame at time t depends only on the starting frame, the seed and t; the
// wires are drawn in addition as soon as they are measured and never change
// the frame. See js/api/40-modes.md.
// ---------------------------------------------------------------------------
(function () {
  var M = ET.modes;
  var KNN_SLICE_MS = 1; // a unit of neighbour work stops after its first piece once this has passed
  var KNN_PIECE = 1 << 12; // multiply-adds between two looks at the clock (a few candidates of one row)
  var SALT_RESUME = 0x1a77ce; // the swap schedule that starts after a swing draws from its own stream

  var DEFAULTS = {
    period: 3.4, // seconds per axis swap (the reference's)
    neighbourLimit: 1000, // only the first this-many points get neighbours (the reference's 1,000)
    wireNeighbours: 3, // wires per point (the reference's 3)
    sliceRows: 16, // at most this many query rows per unit of neighbour work (the reference's 16)
    transition: 1.2, // seconds to blend draw parameters in from the previous view
    wireFade: 1.2, // seconds for the wires to fade in once measured
    centreTau: 0.7, // seconds: the camera glides to the data's mean
    zoomSample: 512, // points used for auto-framing
    // Where hidden directions come from. "strongest": inside the span of the data's
    // `subspace` strongest principal directions, so every picture keeps real spread
    // (in real vectors a direction drawn from the full space holds almost none, and
    // after three swaps the picture would be a random one). "full": anywhere in the
    // space, as the reference does.
    hidden: "strongest",
    subspace: 8,
    fitRows: 4096, // fit the directions on at most this many rows (as Tumble does)
  };

  function create(options) {
    var opt = {};
    for (var k in DEFAULTS) opt[k] = options?.[k] === undefined ? DEFAULTS[k] : options[k];

    var self = {
      time: 0,
      enter: enter,
      prepare: prepare,
      isReady: isReady,
      stateAt: stateAt,
      step: step,
      status: status,
      dataChanged: dataChanged,
      describe: describe,
      mark: mark,
      face: face,
      leave: leave,
    };

    var set = null;
    var D = 0;
    var seed = 0;
    var entry = null;
    var empty = false;
    var emptyReady = false;
    var st = null;
    var glide = null;
    var swap = null;
    var guided = false; // the swap tour draws from the fitted directions
    var fitAtEntry = false; // decided once per entry: the entry waits for the fit
    var fitShare = null; // share of variance in those directions
    var swapBasis = null; // { basis, rows } the swap tour draws hidden directions from, when guided
    // Zoom bases (M.zoomWith), when guided: every frame of a swap schedule lies in the
    // span of the fitted directions and the frame the schedule started from, so the
    // framing need not pass over the sample in full dimension on every frame.
    var zoomBase = null; // over the fitted directions alone
    var zoomBasis = null; // with the entry's starting frame: the entry's schedule
    var swings = null; // the swings toward the searches (M.makeSwings)
    var epoch = 0; // bumped by enter and leave: work queued for an earlier entry does nothing
    var hold = null;
    var knn = null; // the stepper in progress (or finished)
    var version = 0;
    // Wire lists in the order they were shown: { wires: {pairs, lengths, version}, T }.
    // A list is drawn from its time T on; T is fixed by mark(t), or by the first
    // stateAt after the list was measured, and never earlier than the last T.
    var lists = [];
    var pendingWires = null; // a measured list whose time is not fixed yet
    var out = null;

    function enter(s, opts) {
      M.requireDimension(s, 4, "Lattice");
      var o = opts || {};
      set = s;
      D = s.dimension;
      seed = o.seed === undefined ? 0 : o.seed;
      entry = M.entryFrom(o.from, D);
      empty = s.count === 0;
      emptyReady = false;
      st = null;
      glide = null;
      knn = null;
      lists = [];
      pendingWires = null;
      self.time = 0;
      hold = entry ? entry.frame : M.startFrame(D, seed);
      // Until the directions are fitted (or when hidden is "full") the schedule draws
      // from the full space; no frame is answered from it before the mode is ready.
      swap = ET.math.makeSwapTour(hold, D, { seed: seed, period: opt.period });
      guided = false;
      fitShare = null;
      swapBasis = null;
      zoomBase = null;
      zoomBasis = null;
      swings = M.makeSwings(D, seed);
      fitAtEntry = wantsGuided(s);
      epoch++;
      out = { t: 0, frame: new Float32Array(3 * D), centre: new Float32Array(D), draw: null, wires: null, status: "", focus: null };
    }

    function statsTask() {
      var job = M.statsJob(set);
      return {
        required: true,
        weight: 1,
        progress: job.progress,
        run: function () {
          if (!job.run()) return false;
          st = job.result;
          var start = entry?.centre ? entry.centre : st.mean;
          glide = M.makeGlide(start, st.mean, opt.centreTau, D);
          return true;
        },
      };
    }

    // Does set `s` get hidden directions from its strongest directions? Decided
    // once, at entry (fitAtEntry), so an append never leaves the mode waiting for a
    // fit that was not scheduled.
    function wantsGuided(s) {
      return opt.hidden !== "full" && Math.min(opt.subspace, s.dimension) >= 4 && s.count > 1;
    }

    // The fit, in small units: centring, then the strongest directions (the same
    // fit Tumble uses, ET.math.makeGuidedTour, for its basis only), then the swap
    // tour over them. Required: no frame is answered before it is done, so the
    // frames depend on data, seed and time only.
    function fitTasks() {
      var mine = epoch;
      var fitSet = set;
      var cen = null;
      var tourSt = null;
      var zoomJob = null;
      var base = null;
      return [
        {
          required: true,
          weight: 1,
          progress: function () {
            return cen ? cen.progress : 0;
          },
          run: function () {
            if (mine !== epoch) return true;
            if (!cen) cen = ET.math.makeCentre(fitSet.vectors, fitSet.count, D);
            return cen.step(0);
          },
        },
        {
          required: true,
          weight: 6,
          progress: function () {
            return tourSt ? tourSt.progress : 0;
          },
          run: function () {
            if (mine !== epoch) return true;
            var rows = fitSet.count > opt.fitRows ? opt.fitRows : undefined;
            if (!tourSt) {
              tourSt = ET.math.makeGuidedTour(cen.result.data, fitSet.count, D, {
                seed: seed,
                subspace: Math.min(opt.subspace, D),
                sampleRows: rows,
                pca: M.fittedDirections(fitSet, seed, opt.subspace, rows),
              });
            }
            if (!tourSt.step(0)) return false;
            var tour = tourSt.result;
            M.keepDirections(fitSet, seed, opt.subspace, rows, tour.pca);
            cen = null; // the centred copy is not kept
            tourSt = null;
            swap = ET.math.makeSwapTour(hold, D, {
              seed: seed,
              period: opt.period,
              basis: tour.basis,
              basisRows: tour.subspace,
            });
            swapBasis = { basis: tour.basis, rows: tour.subspace };
            fitShare = tour.varianceShare;
            return true;
          },
        },
        {
          required: true,
          weight: 0.5,
          progress: function () {
            if (!zoomJob) return 0;
            return base ? zoomJob.progress() : zoomJob.progress() * 0.7;
          },
          run: function () {
            if (mine !== epoch) return true;
            if (!zoomJob) zoomJob = M.zoomBasisJob(fitSet.vectors, fitSet.count, D, swapBasis.basis, swapBasis.rows, opt.zoomSample);
            if (!zoomJob.run()) return false;
            if (!base) {
              base = zoomJob.result;
              zoomJob = M.zoomExtendJob(base, fitSet.vectors, hold, 3);
              return false;
            }
            zoomBase = base;
            zoomBasis = zoomJob.result;
            guided = true;
            return true;
          },
        },
      ];
    }

    // Neighbour measurement over the current set, then the wire list.
    function knnTask() {
      var s = set;
      var stepper = ET.math.makeKnn(s.vectors, s.count, D, opt.wireNeighbours, { limit: opt.neighbourLimit });
      knn = stepper;
      return {
        required: false,
        weight: 8,
        progress: function () {
          return stepper.count ? stepper.next / stepper.count : 1;
        },
        run: function () {
          if (knn !== stepper) return true; // superseded by a newer measurement
          // A few candidates of the row in progress at a time (about KNN_PIECE
          // multiply-adds) until about KNN_SLICE_MS has passed: at least one
          // piece, at most sliceRows rows' worth. A whole row is up to
          // neighbourLimit * D multiply-adds, which on a device that runs
          // JavaScript slowly held a frame for tens of milliseconds. The rows
          // and their candidates are measured in order whatever the slicing,
          // so the wires never depend on it.
          var start = M.now();
          var piece = Math.max(1, Math.floor(KNN_PIECE / D));
          var from = stepper.next;
          var first = true;
          while (!stepper.done && stepper.next - from < opt.sliceRows && (first || M.now() - start < KNN_SLICE_MS)) {
            stepper.stepPart(piece);
            first = false;
          }
          if (!stepper.done) return false;
          buildWires(s, stepper);
          return true;
        },
      };
    }

    // Each point's first `wireNeighbours` neighbours, deduplicated. Points with no
    // group get no wires of their own when the pool has groups (the reference
    // leaves its unstructured halo unwired); they can still be another point's
    // neighbour.
    function buildWires(s, kn) {
      var S = kn.count;
      var K = kn.k;
      var anyGroup = false;
      for (var i = 0; i < S && !anyGroup; i++) anyGroup = !!s.points[i].group;
      var pairs = [];
      var lengths = [];
      var seen = {};
      for (var a = 0; a < S; a++) {
        if (anyGroup && !s.points[a].group) continue;
        for (var q = 0; q < K; q++) {
          var b = kn.indices[a * K + q];
          var key = a < b ? a * S + b : b * S + a;
          if (seen[key]) continue;
          seen[key] = 1;
          pairs.push(a, b);
          lengths.push(kn.distances[a * K + q]);
        }
      }
      version++;
      pendingWires = { pairs: new Uint32Array(pairs), lengths: new Float32Array(lengths), version: version };
    }

    function prepare() {
      if (empty) {
        return M.stepper([
          {
            required: true,
            run: function () {
              emptyReady = true;
              return true;
            },
          },
        ]);
      }
      var tasks = [statsTask()];
      if (fitAtEntry) tasks = tasks.concat(fitTasks());
      tasks.push(knnTask());
      return M.stepper(tasks);
    }

    function isReady() {
      return empty ? emptyReady : glide !== null && (guided || !fitAtEntry);
    }

    function lastT() {
      return lists.length ? lists.at(-1).T : -Infinity;
    }

    function fixWires(T) {
      lists.push({ wires: pendingWires, T: Math.max(T, lastT()) });
      pendingWires = null;
    }

    // Fix the time of a finished event (a measured wire list waiting to be shown).
    function mark(time) {
      if (pendingWires) fixWires(M.checkTime(time));
    }

    function activeList(t) {
      for (var i = lists.length - 1; i >= 0; i--) if (lists[i].T <= t) return lists[i];
      return null;
    }

    // The first list fades in over wireFade from its time; later lists replace
    // it at full strength.
    function wireOpacity(t) {
      if (!lists.length || t < lists[0].T) return 0;
      return ET.math.smoothstep((t - lists[0].T) / opt.wireFade);
    }

    function stateAt(time) {
      var t = M.checkTime(time);
      if (!isReady() || empty) return M.holdState(out, hold, entry, t, status(t));
      if (pendingWires) fixWires(t); // no time was given: the first query fixes it
      out.t = t;
      var sw = swings.at(t);
      var swinging = sw !== null && t < sw.U;
      var zoom = 0;
      if (swinging) {
        zoom = M.swingState(sw, t, out.frame, out.centre);
      } else {
        swapAt(sw, t).frameAt(sw ? t - sw.U : t, out.frame);
        glide.at(t, out.centre);
        zoom = M.zoomWith(zoomFor(sw), set.vectors, set.count, D, out.frame, out.centre, opt.zoomSample);
      }
      var sc = st.radius / M.REFERENCE_RADIUS;
      var draw = {
        zoom: zoom,
        wires: 0,
        dim: 0.55,
        trails: 0.1,
        fog: 0,
        fogNear: 1.2 * sc,
        fogWidth: 0.8 * sc,
        twinkle: 0.18,
        depthOfField: 1.1,
      };
      out.draw = M.blendDraw(draw, entry, t, opt.transition);
      if (swinging) out.draw.zoom = zoom;
      else if (sw) out.draw.zoom = M.releaseCentreZoom(M.swingEnd(sw), M.swingRelease(sw, t, opt.transition), out.centre, out.draw.zoom);
      // the wire fade-in is its own ramp, not part of the entry blend
      out.draw.wires = wireOpacity(t);
      var list = activeList(t);
      out.wires = list ? list.wires : null;
      out.focus = null;
      out.status = status(t);
      return out;
    }

    // The swap schedule in force at t: the entry's, or after a swing (sw, ended
    // by t) a new schedule that starts from the frame shown at the swing's end, in
    // the time since then. It keeps swapping axes from there with no jump.
    function swapAt(sw, t) {
      if (!sw || t < sw.U) return swap;
      if (!sw.cache.swap) {
        var o = { seed: ET.math.mixSeed(ET.math.mixSeed(seed, SALT_RESUME), sw.index), period: opt.period };
        if (swapBasis) {
          o.basis = swapBasis.basis;
          o.basisRows = swapBasis.rows;
        }
        sw.cache.swap = ET.math.makeSwapTour(M.swingEnd(sw).frame, D, o);
      }
      return sw.cache.swap;
    }

    // The zoom basis of the schedule in force (swapAt): the entry's, or after a
    // swing the fitted directions with the frame shown at the swing's end, built
    // once per swing (three passes over the sample, the cost of one frame before).
    // Null when the hidden directions come from the full space.
    function zoomFor(sw) {
      if (!sw || !zoomBase) return zoomBasis;
      if (!sw.cache.zoomBasis) sw.cache.zoomBasis = M.extendZoomBasis(zoomBase, set.vectors, M.swingEnd(sw).frame);
      return sw.cache.zoomBasis;
    }

    function swapStateAt(sw, t) {
      return sw ? swapAt(sw, t).stateAt(t - sw.U) : swap.stateAt(t);
    }

    // The swing toward the searches (js/api/40-modes.md, "Facing the searches").
    // face(null, t) ends a swing in progress at t.
    function face(target, time, options) {
      if (!isReady() || empty) return false;
      if (target === null) return swings.end(time);
      return swings.face(target, time, options, function (T) {
        var s = stateAt(T);
        return { frame: new Float32Array(s.frame), centre: new Float32Array(s.centre), zoom: s.draw.zoom };
      });
    }

    function step(dt) {
      self.time = Math.max(0, self.time + dt);
      return stateAt(self.time);
    }

    // Short on purpose (about 70 characters at most); detail is in describe().
    function status(time) {
      var t = M.checkTime(time === undefined ? self.time : time);
      if (empty) return M.EMPTY_STATUS;
      var sw = isReady() ? swings.at(t) : null;
      if (sw && t < sw.U) return M.swingStatus(sw, "swapping axes");
      var s = swapStateAt(sw, t);
      var pctSwap = String(Math.round(Math.min(1, s.u) * 100));
      while (pctSwap.length < 3) pctSwap = " " + pctSwap;
      var line = "swap " + (s.cycle + 1) + " · axis " + "XYZ".charAt(s.axis) + " trading for a hidden direction · " + pctSwap + "%";
      var list = isReady() ? activeList(t) : null;
      if (list) {
        var nw = list.wires.pairs.length / 2;
        line += " · " + M.thousands(nw) + (nw === 1 ? " wire" : " wires");
      }
      else if (knn) line += " · measuring " + Math.round((knn.next / Math.max(1, knn.count)) * 100) + "%";
      else line += " · no wires yet";
      return line;
    }

    // Append: the swap tour goes on unchanged and the camera glides to the new
    // mean. If new points fall inside the neighbour limit, neighbours are
    // measured again (the old wires stay until the new ones are shown). The
    // first points onto an empty set, the points that make a set entered without a
    // fit (one point) big enough for one, a replace, or another dimension: start
    // over from the current view.
    function dataChanged(newSet, info) {
      var i = info || {};
      var t = i.t === undefined ? self.time : M.checkTime(i.t);
      var fitNow = !fitAtEntry && newSet.dimension === D && wantsGuided(newSet);
      if (i.op !== "append" || newSet.dimension !== D || empty || fitNow || !isReady()) {
        var from = entry;
        if (isReady()) {
          var s = stateAt(t);
          from = { frame: new Float32Array(s.frame), centre: null, draw: { ...s.draw } };
          if (!empty || entry?.centre) from.centre = new Float32Array(s.centre);
        }
        enter(newSet, { seed: seed, from: from });
        return M.changed(prepare(), true);
      }
      var old = set;
      set = newSet;
      st = M.stats(newSet, old);
      glide.retarget(t, st.mean);
      if (old.count < opt.neighbourLimit) return M.changed(M.stepper([knnTask()]), false);
      return M.changed(null, false);
    }

    function describe() {
      var last = lists.length ? lists.at(-1) : null;
      return {
        id: "lattice",
        projection: "linear: an orthonormal 3-frame; one axis at a time turns a quarter turn into a hidden direction",
        hidden: guided ? "strongest" : "full",
        subspace: guided ? Math.min(opt.subspace, D) : null,
        seed: seed,
        period: opt.period,
        neighbourLimit: opt.neighbourLimit,
        wireNeighbours: opt.wireNeighbours,
        wires: last ? last.wires.pairs.length / 2 : 0,
        neighboursMeasured: !!knn?.done,
        wiresShownAt: lists.length ? lists[0].T : null,
        wiresReplacedAt: lists.length > 1 ? last.T : null,
        wiresPending: pendingWires !== null,
        facing: swings ? swings.describe() : null,
        empty: empty,
        varianceShare: fitShare,
      };
    }

    function leave() {
      epoch++;
      knn = null;
      lists = [];
      pendingWires = null;
      set = null;
    }

    return self;
  }

  M.register({
    id: "lattice",
    title: "Lattice",
    summary: "True neighbours wired together, one axis swapped at a time",
    create: create,
  });
})();
// ---------------------------------------------------------------------------
// 42-mode-wander.js: Wander (registered as ET.modes "wander").
//
// The camera flies from labelled point to labelled point. At every stop the
// three axes are fitted again to that point's 24 true nearest neighbours
// (ET.math.localFrame), aligned to the previous axes (ET.math.alignTo) so the
// flight twists as little as possible, and blended in (ET.math.blendFrames).
// Each hop travels for 2.8 s and dwells for 2.0 s; every fifth hop leaps to
// another group. The route is drawn from the seed and the data only, hop by
// hop from its own random stream, so the frame at time t depends only on the
// data, the seed, the entry view and t. See js/api/40-modes.md.
//
// Hop h depends on hop h - 1 (its stop, its frame and the recent stops), so a
// far query must replay the route; what is kept is bounded: the last WINDOW
// hops, plus at most MAX_CHECKPOINTS checkpoints (a hop's frame and recent
// stops), spaced further apart as the route grows. Replays start from the
// nearest checkpoint. An append only records which point count was in force
// from which hop (`segs`): the points of a set never change on append, so the
// neighbour pool and the visit list in force at any earlier hop can be rebuilt
// from the current set and that count.
// ---------------------------------------------------------------------------
(function () {
  var M = ET.modes;
  var SALT_WANDER = 0x3a7d3e;
  var SCAN_WORK = 1 << 17; // values compared per piece of a neighbour scan done ahead of need
  var WINDOW = 64; // hops kept after the newest one computed
  var CHECKPOINT_SPACING = 16; // hops between checkpoints at first (doubles as the route grows)
  var MAX_CHECKPOINTS = 32; // checkpoints kept, besides the route's start

  var DEFAULTS = {
    neighbours: 24, // neighbours a local frame is fitted to (the reference's K)
    neighbourLimit: 1000, // neighbours are searched among the first this-many points, plus every labelled point
    travel: 2.8, // seconds of flight per hop (the reference's)
    dwell: 2.0, // seconds at each stop (the reference's)
    leapEvery: 5, // every n-th hop leaps to another group (the reference's 5)
    nearChoices: 6, // a near hop picks among the first this-many labelled neighbours
    recent: 16, // stops not revisited within this many hops
    transition: 1.0, // seconds to blend draw parameters in from the previous view
    zoom: 2.7, // the reference's fixed zoom, at the reference's scale
    spokes: 6, // labelled neighbours listed in `focus` for the viewer's spokes
  };

  // Insert pool point i, at squared distance s, into a scan's best lists (nearest
  // first, ties to the lower index, at most K kept). Returns the new fill count.
  function insertNearest(bestD, bestI, filled, K, s, i) {
    if (filled === K && (s > bestD[K - 1] || (s === bestD[K - 1] && i > bestI[K - 1]))) return filled;
    var pos = filled < K ? filled : K - 1;
    while (pos > 0 && (bestD[pos - 1] > s || (bestD[pos - 1] === s && bestI[pos - 1] > i))) {
      bestD[pos] = bestD[pos - 1];
      bestI[pos] = bestI[pos - 1];
      pos--;
    }
    bestD[pos] = s;
    bestI[pos] = i;
    return filled < K ? filled + 1 : filled;
  }

  // A finished scan: its neighbours, nearest first, cached on its context.
  function scanFinish(sc) {
    var nb = sc.bestI.subarray(0, sc.filled);
    sc.c.nbr.set(sc.j, nb);
    return nb;
  }

  function create(options) {
    var opt = {};
    for (var k in DEFAULTS) opt[k] = options?.[k] === undefined ? DEFAULTS[k] : options[k];
    var cycle = opt.travel + opt.dwell;

    var self = {
      time: 0,
      enter: enter,
      prepare: prepare,
      isReady: isReady,
      stateAt: stateAt,
      step: step,
      status: status,
      dataChanged: dataChanged,
      describe: describe,
      route: route,
      neighboursOf: neighboursOf,
      retained: retained,
      mark: function () {}, // Wander has no events to fix
      face: face,
      leave: leave,
    };

    var set = null;
    var D = 0;
    var seed = 0;
    var seedU = 0;
    var entry = null;
    var startFrame = null;
    var startCentre = null;
    var scale = 1;
    var ready = false;
    var empty = false;
    // The data context of a point count n: { n, visit, inVisit, pool, labelled, nbr }
    // (visit: Int32Array, the points the route may stop at; inVisit: Uint8Array(n);
    // pool: Int32Array, the points searched for neighbours; nbr: neighbour cache).
    var ctx = null; // the current set's
    var oldCtx = null; // one earlier count's, for replays across an append
    var segs = []; // [{ from, n }]: from hop `from` on, stops were chosen among the first n points
    var win = null; // Map hop -> { target, frame }: the last WINDOW hops computed
    var cps = []; // checkpoints [{ h, prev, recent, frame }], by hop; cps[0] is the start (h -1)
    var spacing = CHECKPOINT_SPACING;
    var cur = null; // the route's cursor: the newest hop computed { h, prev, recent, frame }
    var hopsComputed = 0; // hops computed in all (replays included), for retained()
    var ahead = null; // the next hop's work in progress: { h, j, c, scan, fit }
    var out = null;
    var tmpC = null;
    var swings = null; // the swings toward the searches (M.makeSwings)

    function enter(s, opts) {
      M.requireDimension(s, 3, "Wander");
      var o = opts || {};
      set = s;
      D = s.dimension;
      seed = o.seed === undefined ? 0 : o.seed;
      seedU = ET.math.toSeed(seed);
      entry = M.entryFrom(o.from, D);
      startFrame = entry ? entry.frame : M.startFrame(D, seed);
      startCentre = null;
      ready = false;
      empty = s.count === 0;
      ctx = null;
      oldCtx = null;
      segs = [{ from: 0, n: s.count }];
      win = new Map();
      cps = [{ h: -1, prev: -1, recent: [], frame: startFrame }];
      spacing = CHECKPOINT_SPACING;
      cur = { h: -1, prev: -1, recent: [], frame: startFrame };
      hopsComputed = 0;
      ahead = null;
      swings = M.makeSwings(D, seed);
      self.time = 0;
      out = { t: 0, frame: new Float32Array(3 * D), centre: new Float32Array(D), draw: null, wires: null, status: "", focus: null };
      tmpC = new Float64Array(D);
    }

    // Visit candidates (labelled points, or every pooled point when fewer than
    // two are labelled) and the neighbour pool, among the first N points. O(N).
    function makeCtx(N) {
      var lab = [];
      for (var i = 0; i < N; i++) if (M.isLabelled(set.points[i])) lab.push(i);
      var limit = Math.min(N, opt.neighbourLimit);
      var p = [];
      var mark = new Uint8Array(N);
      for (var a = 0; a < limit; a++) {
        p.push(a);
        mark[a] = 1;
      }
      for (var l of lab) {
        if (!mark[l]) {
          p.push(l);
          mark[l] = 1;
        }
      }
      var visit = lab.length >= 2 ? Int32Array.from(lab) : Int32Array.from(p);
      var inVisit = new Uint8Array(N);
      for (var v of visit) inVisit[v] = 1;
      return { n: N, visit: visit, inVisit: inVisit, pool: Int32Array.from(p), labelled: lab.length, nbr: new Map() };
    }

    // The context stops of hop h were chosen in.
    function ctxFor(h) {
      var n = segs[0].n;
      for (var i = 1; i < segs.length && segs[i].from <= h; i++) n = segs[i].n;
      if (n === ctx.n) return ctx;
      if (!oldCtx || oldCtx.n !== n) oldCtx = makeCtx(n);
      return oldCtx;
    }

    // Preparation: the set's statistics (sliced), the visit list and the
    // neighbour pool (one unit, O(N)), then the first stop, computed in slices
    // as every later stop is (see workAhead), so the first frame does no heavy
    // work. The stops are the same whenever and however they are computed.
    function prepare() {
      if (empty) {
        return M.stepper([
          {
            required: true,
            run: function () {
              ready = true;
              return true;
            },
          },
        ]);
      }
      var job = M.statsJob(set);
      var pooled = false;
      return M.stepper([
        {
          required: true,
          weight: 1,
          progress: job.progress,
          run: function () {
            if (!job.run()) return false;
            var st = job.result;
            scale = st.radius / M.REFERENCE_RADIUS;
            startCentre = entry?.centre ? new Float32Array(entry.centre) : new Float32Array(st.mean);
            return true;
          },
        },
        {
          required: true,
          weight: 1,
          run: function () {
            if (!pooled) {
              ctx = makeCtx(set.count);
              pooled = true;
              return false;
            }
            if (!workAhead(0)) return false;
            ready = true;
            return true;
          },
        },
      ]);
    }

    function isReady() {
      return ready;
    }

    // The point's `neighbours` nearest points in the pool, in the full space,
    // nearest first, ties to the lower index. O(pool * D), cached per point.
    function nearest(c, j) {
      var got = c.nbr.get(j);
      if (got) return got;
      var sc = scanStart(c, j);
      scanRows(sc, c.pool.length);
      return scanFinish(sc);
    }

    // The same search, resumable: scanRows(sc, rows) measures the next `rows`
    // pool points. The pool is scanned in order, so the result does not depend
    // on how the scan was sliced.
    function scanStart(c, j) {
      var K = Math.max(0, Math.min(opt.neighbours, c.pool.length - 1));
      return { c: c, j: j, K: K, q: 0, filled: 0, bestD: new Float64Array(K), bestI: new Int32Array(K) };
    }

    function scanRows(sc, rows) {
      var X = set.vectors;
      var pool = sc.c.pool;
      var K = sc.K;
      var bestD = sc.bestD;
      var bestI = sc.bestI;
      var filled = sc.filled;
      var j = sc.j;
      var oj = j * D;
      var stop = Math.min(pool.length, sc.q + rows);
      for (var q = sc.q; q < stop; q++) {
        var i = pool[q];
        if (i === j) continue;
        var oi = i * D;
        var s = 0;
        for (var d = 0; d < D; d++) {
          var x = X[oi + d] - X[oj + d];
          s += x * x;
        }
        filled = insertNearest(bestD, bestI, filled, K, s, i);
      }
      sc.q = stop;
      sc.filled = filled;
      return stop >= pool.length;
    }

    function nearVisits(c, i, max) {
      var nb = nearest(c, i);
      var res = [];
      for (var q = 0; q < nb.length && res.length < max; q++) if (c.inVisit[nb[q]]) res.push(nb[q]);
      return res;
    }

    function groupOf(i) {
      return i >= 0 && set.points[i] ? set.points[i].group || "" : "";
    }

    // The stop of hop h = cur.h + 1, from hop h's own random stream (the
    // reference's rules), among the points of context c.
    function pick(h, c) {
      var rng = ET.math.makeRandom(ET.math.mixSeed(seedU ^ SALT_WANDER, h));
      var i = h > 0 ? cur.prev : -1;
      var recent = cur.recent;
      var visit = c.visit;
      var hopNo = h + 1;
      if (i >= 0 && hopNo % opt.leapEvery !== 0) {
        var near = nearVisits(c, i, opt.neighbours).filter(function (j) {
          return !recent.includes(j);
        });
        if (near.length) return near[Math.floor(rng.next() * Math.min(near.length, opt.nearChoices))];
      }
      var gi = groupOf(i);
      for (var tries = 0; tries < 40; tries++) {
        var j = visit[Math.floor(rng.next() * visit.length)];
        if (j !== i && !recent.includes(j) && (gi === "" || groupOf(j) !== gi)) return j;
      }
      var idx = Math.floor(rng.next() * visit.length);
      if (visit[idx] === i && visit.length > 1) idx = (idx + 1) % visit.length;
      return visit[idx];
    }

    // Hop k's stop and frame, if kept (the window or a checkpoint), else null.
    // Hop -1 is the start: no stop, the entry frame.
    function rec(k) {
      if (k < 0) return { target: -1, frame: startFrame };
      var w = win.get(k);
      if (w) return w;
      for (var i = cps.length - 1; i >= 0 && cps[i].h >= k; i--) if (cps[i].h === k) return { target: cps[i].prev, frame: cps[i].frame };
      return null;
    }

    // Move the cursor back to the newest checkpoint before hop k.
    function resetBefore(k) {
      var c = cps[0];
      for (var i = cps.length - 1; i >= 0; i--) {
        if (cps[i].h < k) {
          c = cps[i];
          break;
        }
      }
      cur = { h: c.h, prev: c.prev, recent: c.recent.slice(), frame: c.frame };
      win = new Map();
      ahead = null;
    }

    // Make hop k available through rec(k): from the cursor when it is behind k and
    // no checkpoint is nearer, else from the newest checkpoint before k.
    function ensure(k) {
      if (rec(k)) return;
      var near = cps[0];
      for (var i = cps.length - 1; i >= 0; i--) {
        if (cps[i].h < k) {
          near = cps[i];
          break;
        }
      }
      if (cur.h >= k || near.h > cur.h) resetBefore(k);
      while (cur.h < k) advance(null, -1);
    }

    function stopIds(c, j) {
      return [j].concat(Array.prototype.slice.call(nearest(c, j)));
    }

    // Compute hop cur.h + 1: its stop (j, or picked when j is -1) and its local
    // frame (fitted to the stop and its neighbours, or `fitted`), aligned to the
    // previous hop's. Keeps it in the window and, on the spacing, as a checkpoint.
    function advance(fitted, j) {
      var n = cur.h + 1;
      var c = ctxFor(n);
      if (j < 0) j = pick(n, c);
      var lf = fitted || ET.math.localFrame(set.vectors, set.count, D, stopIds(c, j));
      var frame = ET.math.alignTo(lf, cur.frame, D);
      var recent = cur.recent;
      recent.push(j);
      while (recent.length > Math.max(0, opt.recent)) recent.shift();
      cur.h = n;
      cur.prev = j;
      cur.frame = frame;
      hopsComputed++;
      win.set(n, { target: j, frame: frame });
      win.delete(n - WINDOW);
      if ((n + 1) % spacing === 0) checkpoint();
      ahead = null;
    }

    function checkpoint() {
      var at = cps.length;
      while (at > 0 && cps[at - 1].h > cur.h) at--;
      if (at > 0 && cps[at - 1].h === cur.h) return;
      cps.splice(at, 0, { h: cur.h, prev: cur.prev, recent: cur.recent.slice(), frame: cur.frame });
      if (cps.length > MAX_CHECKPOINTS + 1) {
        spacing *= 2;
        cps = cps.filter(function (c) {
          return c.h < 0 || (c.h + 1) % spacing === 0;
        });
      }
    }

    // One small piece of the work for hop h, ahead of need: pick its stop,
    // then scan the pool for the stop's neighbours SCAN_WORK values at a time,
    // then fit its frame (ET.math.makeLocalFrame, one unit per call) and align
    // it. Returns true once hop h is kept.
    // stateAt calls it every frame for the next hop, so by the time the flight
    // reaches a stop (4.8 s later) nothing is left to compute in that frame.
    // The pieces compute exactly what ensure(h) computes in one go.
    function workAhead(h) {
      if (rec(h)) return true;
      if (cur.h !== h - 1) return false; // only the hop after the cursor is worked on ahead
      if (!ahead || ahead.h !== h) {
        var c = ctxFor(h);
        var j = pick(h, c);
        ahead = { h: h, j: j, c: c, scan: c.nbr.has(j) ? null : scanStart(c, j), fit: null };
        return false;
      }
      if (ahead.scan) {
        if (scanRows(ahead.scan, Math.max(1, Math.floor(SCAN_WORK / D)))) {
          scanFinish(ahead.scan);
          ahead.scan = null;
        }
        return false;
      }
      if (!ahead.fit) ahead.fit = ET.math.makeLocalFrame(set.vectors, set.count, D, stopIds(ahead.c, ahead.j));
      if (!ahead.fit.step(0)) return false;
      advance(ahead.fit.result, ahead.j);
      return true;
    }

    function hopAt(t) {
      var h = Math.floor(t / cycle);
      return { h: h, local: t - h * cycle };
    }

    // The hop at t (not during a swing): with no swing before t, hopAt(t). After
    // a swing (sw, ended by t) a new leg starts at its end U with the hop after
    // the one the swing interrupted (sw.info.hT); `first` marks the leg's first
    // hop, which flies from the frame and centre shown at U.
    function legAt(sw, t) {
      if (!sw) return hopAt(t);
      var lt = t - sw.U;
      var k = Math.floor(lt / cycle);
      return { h: sw.info.hT + 1 + k, local: lt - k * cycle, first: k === 0 };
    }

    // The hop in progress at t: during a swing, the hop it interrupted.
    function hopInProgress(t) {
      var sw = swings.at(t);
      if (sw && t < sw.U) return sw.info.hT;
      return legAt(sw, t).h;
    }

    // A route frame as shown in the leg after swing sw: its axes relabelled
    // (order and sign) to match the frame shown at the swing's end, the same
    // relabelling for every hop of the leg, so the hops stay aligned to each other.
    function legFrame(sw, f) {
      return sw ? M.applyAlignment(f, sw.cache.al, D) : f;
    }

    function stateAt(time) {
      var t = M.checkTime(time);
      out.t = t;
      if (!ready || empty) return M.holdState(out, startFrame, entry, t, status(t));
      var sw = swings.at(t);
      if (sw && t < sw.U) return swingingState(sw, t);
      var hp = legAt(sw, t);
      var h = hp.h;
      var end = sw ? legEnd(sw) : null;
      ensure(h - 1);
      ensure(h);
      var prevRec = rec(h - 1);
      var hereRec = rec(h);
      workAhead(h + 1);
      var first = !!hp.first;
      var j = hereRec.target;
      var prev = h > 0 && !first ? prevRec.target : -1; // the stop flown from, or -1
      var travelling = hp.local < opt.travel;
      var e = travelling ? ET.math.smoothstep(hp.local / opt.travel) : 1;
      var from = flightStart(sw, first, prevRec);
      if (travelling) travelCentre(prev, from.centre, j, e);
      else stopCentre(j);
      ET.math.blendFrames(from.frame, legFrame(sw, hereRec.frame), e, D, out.frame);
      out.focus = {
        phase: travelling ? "travel" : "dwell",
        from: prev,
        to: j,
        e: e,
        neighbours: Int32Array.from(nearVisits(ctx, j, opt.spokes)),
      };
      out.draw = drawAt(t);
      // The centre needs no blend: the leg's first hop flies from the centre shown at U.
      if (sw) out.draw.zoom = end.zoom + (out.draw.zoom - end.zoom) * M.swingRelease(sw, t, opt.transition);
      out.status = status(t);
      return out;
    }

    // The centre during a flight: e of the way from stop `prev` (from `fromC` when there is
    // no previous stop, prev < 0) to stop j.
    function travelCentre(prev, fromC, j, e) {
      var X = set.vectors;
      var oc = prev * D;
      var oj = j * D;
      for (var d = 0; d < D; d++) {
        var a = prev >= 0 ? X[oc + d] : fromC[d];
        tmpC[d] = a + (X[oj + d] - a) * e;
      }
      for (var d2 = 0; d2 < D; d2++) out.centre[d2] = tmpC[d2];
    }

    // The centre while the camera dwells at stop j: the stop itself.
    function stopCentre(j) {
      var X = set.vectors;
      var oj = j * D;
      for (var d = 0; d < D; d++) out.centre[d] = X[oj + d];
    }

    // The state shown at swing sw's end, with the leg's relabelling of route
    // frames worked out (once) against it.
    function legEnd(sw) {
      var end = M.swingEnd(sw);
      if (!sw.cache.al) {
        ensure(sw.info.hT + 1);
        sw.cache.al = M.alignment(rec(sw.info.hT + 1).frame, end.frame, D);
      }
      return end;
    }

    // Where a flight starts: the frame and the centre used when there is no
    // previous stop. A leg's first hop starts from the state shown at the swing's end.
    function flightStart(sw, first, prevRec) {
      if (first) return M.swingEnd(sw);
      return { frame: legFrame(sw, prevRec.frame), centre: startCentre };
    }

    // During a swing: the swing's frame, centre and zoom; the spokes of the hop
    // it interrupted, as they were at its start.
    function swingingState(sw, t) {
      var zoom = M.swingState(sw, t, out.frame, out.centre);
      workAhead(sw.info.hT + 1); // the next leg's first stop, ahead of need
      out.focus = sw.info.focus;
      out.draw = drawAt(t);
      out.draw.zoom = zoom;
      out.status = status(t);
      return out;
    }

    function drawAt(t) {
      var draw = {
        zoom: opt.zoom / scale,
        wires: 0,
        dim: 1,
        trails: 0.17,
        fog: 1,
        fogNear: 1.2 * scale,
        fogWidth: 0.8 * scale,
        twinkle: 0.18,
        depthOfField: 1.1,
      };
      return M.blendDraw(draw, entry, t, opt.transition);
    }

    // The swing toward the searches (js/api/40-modes.md, "Facing the searches").
    // face(null, t) ends a swing in progress at t. The swing remembers the hop it
    // interrupts (hT) and that hop's spokes.
    function face(target, time, options) {
      if (!ready || empty) return false;
      if (target === null) return swings.end(time);
      return swings.face(target, time, options, function (T) {
        var prior = swings.at(T);
        var hT = prior && T < prior.U ? prior.info.hT : legAt(prior, T).h;
        var s = stateAt(T);
        var f = s.focus ? { ...s.focus, neighbours: new Int32Array(s.focus.neighbours) } : null;
        return {
          frame: new Float32Array(s.frame),
          centre: new Float32Array(s.centre),
          zoom: s.draw.zoom,
          info: { hT: hT, focus: f },
        };
      });
    }

    // A point's name for the status line, cut to 24 characters so the line
    // stays short (the full label is the viewer's to show).
    function nameOf(i) {
      var p = set.points[i];
      var n = M.isLabelled(p) ? p.label : p.id;
      return n.length > 24 ? n.slice(0, 23) + "…" : n;
    }

    function describeStop(h, phase, first) {
      var j = rec(h).target;
      if (phase === "dwell") {
        var g = groupOf(j);
        return 'at "' + nameOf(j) + '"' + (g ? " · " + g : "") + " · stop " + (h + 1);
      }
      var i = h > 0 && !first ? rec(h - 1).target : -1;
      var gj = groupOf(j);
      var far = i >= 0 && gj !== "" && groupOf(i) !== gj;
      return (i >= 0 ? '"' + nameOf(i) + '" → ' : "heading to ") + '"' + nameOf(j) + '"' + (far ? " · long leap to " + gj : "");
    }

    function step(dt) {
      self.time = Math.max(0, self.time + dt);
      return stateAt(self.time);
    }

    function status(time) {
      var t = M.checkTime(time === undefined ? self.time : time);
      if (empty) return M.EMPTY_STATUS;
      if (!ready) return "getting ready to wander …";
      var sw = swings.at(t);
      if (sw && t < sw.U) return M.swingStatus(sw, "wandering");
      var hp = legAt(sw, t);
      ensure(hp.h - 1);
      ensure(hp.h);
      return describeStop(hp.h, hp.local < opt.travel ? "travel" : "dwell", hp.first);
    }

    // Append: the hops up to the one in progress at time t are kept (so the view
    // does not jump); later hops are chosen again with the new points, which can
    // become stops and neighbours. Replace: start over from the current view.
    function dataChanged(newSet, info) {
      var i = info || {};
      var t = i.t === undefined ? self.time : M.checkTime(i.t);
      if (i.op !== "append" || newSet.dimension !== D || !ready || empty) {
        var from = entry;
        if (ready) {
          var s = stateAt(t);
          from = { frame: new Float32Array(s.frame), centre: null, draw: { ...s.draw } };
          if (!empty || entry?.centre) from.centre = new Float32Array(s.centre);
        }
        enter(newSet, { seed: seed, from: from });
        return M.changed(prepare(), true);
      }
      var h = hopInProgress(t);
      // A leg that starts after h re-relabels its frames against the stops chosen again.
      for (var sw of swings.list) if (sw.info.hT >= h) sw.cache.al = null;
      // Keep the route up to hop h (computed with the data so far); drop the rest.
      ensure(h);
      if (cur.h > h) {
        resetBefore(h + 1);
        while (cur.h < h) advance(null, -1);
      }
      cps = cps.filter(function (c) {
        return c.h <= h;
      });
      segs = segs.filter(function (sg) {
        return sg.from <= h;
      });
      segs.push({ from: h + 1, n: newSet.count });
      ahead = null;
      if (!oldCtx || oldCtx.n !== ctx.n) oldCtx = ctx; // the route so far may be replayed with it
      set = newSet;
      ctx = makeCtx(set.count);
      return M.changed(null, false);
    }

    function route(n) {
      if (!ready || empty) return new Int32Array(0);
      var res = new Int32Array(Math.max(0, n));
      for (var k = 0; k < n; k++) {
        ensure(k);
        res[k] = rec(k).target;
      }
      return res;
    }

    function neighboursOf(j) {
      return ready && !empty ? Int32Array.from(nearest(ctx, j)) : new Int32Array(0);
    }

    // What the route keeps (for tests and diagnostics): hops in the window,
    // checkpoints, the Float32 values their frames hold, append segments, and
    // the hops computed in all.
    function retained() {
      return {
        hops: win ? win.size : 0,
        checkpoints: cps.length,
        floats: ((win ? win.size : 0) + cps.length) * 3 * D,
        segments: segs.length,
        hopsComputed: hopsComputed,
      };
    }

    function describe() {
      return {
        id: "wander",
        projection: "linear: an orthonormal 3-frame fitted to each stop's neighbourhood (its top three principal directions)",
        seed: seed,
        neighbours: opt.neighbours,
        neighbourLimit: opt.neighbourLimit,
        travel: opt.travel,
        dwell: opt.dwell,
        labelled: ctx ? ctx.labelled : 0,
        visiting: ctx?.labelled >= 2 ? "labelled points" : "any point",
        facing: swings ? swings.describe() : null,
        empty: empty,
        varianceShare: null,
      };
    }

    function leave() {
      set = null;
      ctx = null;
      oldCtx = null;
      win = new Map();
      cps = [];
      ahead = null;
      ready = false;
    }

    return self;
  }

  M.register({
    id: "wander",
    title: "Wander",
    summary: "Fly through the space, hopping neighbour to neighbour",
    create: create,
  });
})();
// ---------------------------------------------------------------------------
// 43-mode-focus.js: Focus (registered as ET.modes "focus").
//
// The view is fitted to what is being searched for: with searches active, the
// frame is the facing frame of the union of every search's query and named
// results (ET.searchSets.makeFacingFrame, seeded); with none it is the fit of
// the whole set (its three strongest directions). When the searches change the
// view turns smoothly onto the new fit. The viewer keeps spinning the cloud on
// top of the frame (yaw); while a search is shown Focus asks for the Focus
// reference's spin (the mode's `spin` member, 0.13 rad/s), so the view keeps
// turning at a clearly visible speed; with none it turns as before. A results fit is zoomed the way the reference zooms it: the results'
// reach fills 0.36 of the stage's shorter side. Unlit points are dimmer than in
// the other modes (unlitGain FOCUS_UNLIT); the Only results setting is reported
// as the draw key unlitGain 0, which hides points whose lit value is 0. See
// docs/search-interface.md and js/api/43-mode-focus.md.
// ---------------------------------------------------------------------------
(function () {
  var M = ET.modes;
  var MAX_TURNS = 64; // turns kept; older ones are dropped (a seek that far back shows the oldest kept)
  // Corrected after the owner's browser look (2026-11-14), to match
  // docs/specs/reference/tumbler-focus-view.html:
  var SPIN = 0.13; // rad/s of yaw the viewer turns Focus at with a search (the reference's; otherwise 0.06)
  // The reference maps the results' reach to 0.36 of the stage's shorter side; the renderer
  // maps one unit to 0.46 of it (ET.renderer.DEFAULTS.radius), so the reach is drawn at 0.36 / 0.46 units.
  var FOCUS_UNIT = 0.36 / 0.46;
  // The query may sit up to this many results' reaches from the centre (the stage's shorter
  // half-side is 0.5 / 0.36 = 1.39 reaches), so a query far from its results stays on stage.
  var QUERY_ROOM = 1.3;
  var MIN_REACH = 1e-3; // a reach below this (all rows on one spot) reads as this
  // Brightness of an unlit point in Focus while a search is shown (the renderer's default
  // elsewhere is 0.07). The reference draws unlit points at 0.13 of a result's alpha on a
  // 124-point page; the sample set's 12,288 points pile up under the bloom, so the value
  // that reads as faint as the reference's is lower.
  var FOCUS_UNLIT = 0.05;

  var DEFAULTS = {
    transition: 1.5, // seconds to turn from the entry view onto the first fit, and to blend draw parameters in
    turn: 1.6, // seconds to turn from the view shown onto a new fit (smoothstep)
    fitRows: 4096, // the whole-set fit uses at most this many rows (at an even stride)
    zoomSample: 512, // points used for auto-framing of the whole-set fit
  };

  function copyOf(a) {
    return Float32Array.from(a);
  }

  // The caller's search, copied so later changes by the caller cannot reach it.
  function snapshotOf(search) {
    var list = search?.searches;
    if (!Array.isArray(list) || list.length === 0) return null;
    return {
      searches: list.slice(0, 4).map(function (s, j) {
        return {
          letter: typeof s?.letter === "string" ? s.letter : ET.searchSets.LETTERS[j],
          query: copyOf(s?.query || []),
          indices: Int32Array.from(s?.indices || []),
        };
      }),
      scale: search.scale ? copyOf(search.scale) : null,
      onlyResults: search.onlyResults === true,
    };
  }

  function sameArray(a, b) {
    if (a === b) return true;
    if (!a || !b || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }

  // Do two snapshots ask for the same fit? (The Only results setting is not part of a fit.)
  function sameFit(a, b) {
    if (!a || !b) return a === b;
    if (a.searches.length !== b.searches.length || !sameArray(a.scale, b.scale)) return false;
    for (var j = 0; j < a.searches.length; j++) {
      if (!sameArray(a.searches[j].query, b.searches[j].query)) return false;
      if (!sameArray(a.searches[j].indices, b.searches[j].indices)) return false;
    }
    return true;
  }

  function create(options) {
    var opt = {};
    for (var k in DEFAULTS) opt[k] = options?.[k] === undefined ? DEFAULTS[k] : options[k];

    var self = {
      time: 0,
      spin: undefined, // SPIN while a usable search is asked for (see updateSpin)
      enter: enter,
      prepare: prepare,
      isReady: isReady,
      stateAt: stateAt,
      step: step,
      status: status,
      dataChanged: dataChanged,
      describe: describe,
      mark: mark,
      leave: leave,
      searchChanged: searchChanged,
    };

    var set = null;
    var D = 0;
    var seed = 0;
    var entry = null;
    var empty = false;
    var emptyReady = false;
    var ready = false;
    var hold = null;
    var epoch = 0; // bumped by enter and leave: work queued for an earlier entry does nothing
    var want = null; // the searches asked for now (a snapshot), or null: kept across a data change
    var wantVersion = 0; // bumped when the fit asked for changes
    var whole = null; // the whole-set fit, once made for this entry
    var turns = []; // { T, from, to, dur, kind, letters }: each fixed once recorded
    var pending = null; // a finished fit waiting for its time: { result, minT, kind, letters }
    var prepared = null;
    var out = null;

    function enter(s, opts) {
      M.requireDimension(s, 3, "Focus");
      var o = opts || {};
      set = s;
      D = s.dimension;
      seed = o.seed === undefined ? 0 : o.seed;
      entry = M.entryFrom(o.from, D);
      empty = s.count === 0;
      emptyReady = false;
      ready = false;
      whole = null;
      turns = [];
      pending = null;
      prepared = null;
      self.time = 0;
      hold = entry ? entry.frame : M.startFrame(D, seed);
      epoch++;
      out = { t: 0, frame: new Float32Array(3 * D), centre: new Float32Array(D), draw: null, wires: null, status: "", focus: null };
      updateSpin();
    }

    // True when a search the set can use is asked for (a query of the set's dimension).
    function hasUsableSearch() {
      return !!want?.searches.some((s) => s.query.length === D);
    }

    // The reference's spin while a usable search is asked for; with none the member is left
    // undefined, so the viewer turns Focus at its own speed and the no-search frames are as before.
    function updateSpin() {
      self.spin = hasUsableSearch() ? SPIN : undefined;
    }

    // ----- the fits, in bounded units -------------------------------------------

    // The searches this set can use: a query of the set's dimension, hits that are rows.
    function usableSearches() {
      if (!want) return [];
      var list = [];
      for (var s of want.searches) {
        if (s.query.length !== D) continue;
        var hits = [];
        for (var i of s.indices) if (i >= 0 && i < set.count) hits.push({ index: i });
        list.push({ letter: s.letter, query: s.query, hits: hits });
      }
      return list;
    }

    // The whole set: its three strongest directions about its mean.
    function wholeJob() {
      var mine = set;
      var phase = 0;
      var stats = M.statsJob(mine);
      var cen = null;
      var pca = null;
      var job = {
        done: false,
        result: null,
        kind: "all",
        letters: [],
        progress: function () {
          if (job.done) return 1;
          return [stats.progress() * 0.1, 0.1 + (cen ? cen.progress : 0) * 0.1, 0.2 + (pca ? pca.progress : 0) * 0.8][phase];
        },
        unit: function () {
          if (phase === 0) {
            if (!stats.run()) return false;
            cen = ET.math.makeCentre(mine.vectors, mine.count, D);
            phase = 1;
          } else if (phase === 1) {
            if (!cen.step(0)) return false;
            pca = ET.math.makePrincipalDirections(cen.result.data, mine.count, D, 3, {
              seed: seed,
              sampleRows: mine.count > opt.fitRows ? opt.fitRows : undefined,
            });
            cen = null; // the centred copy is not kept
            phase = 2;
          } else if (pca.step(0)) {
            finishWhole(job, stats.result, pca.result.directions);
          }
          return job.done;
        },
      };
      return job;
    }

    function finishWhole(job, st, directions) {
      var frame = copyOf(directions);
      ET.math.orthonormalize(frame, 3, D);
      var centre = copyOf(st.mean);
      job.result = { frame: frame, centre: centre, zoom: M.autoZoom(set.vectors, set.count, D, frame, centre, opt.zoomSample) };
      job.done = true;
      whole = job.result;
    }

    // The union of the searches' queries and named results, in the facing frame.
    function resultsJob(list) {
      var fs = ET.searchSets.makeFacingFrame(set, list, { seed: seed, scale: usableScale() });
      var job = {
        done: false,
        result: null,
        kind: "results",
        letters: list.map(function (s) {
          return s.letter;
        }),
        progress: function () {
          return job.done ? 1 : fs.progress;
        },
        unit: function () {
          if (!fs.step(0)) return false;
          job.result = { frame: fs.result.frame, centre: fs.result.centre, zoom: resultsZoom(fs.result, list) };
          job.done = true;
          return true;
        },
      };
      return job;
    }

    // The length of (x - centre) in the fitted frame; x is D numbers of `a` from `at`.
    function shownLength(fit, a, at) {
      var sq = 0;
      for (var k = 0; k < 3; k++) {
        var p = 0;
        for (var d = 0; d < D; d++) p += (a[at + d] - fit.centre[d]) * fit.frame[k * D + d];
        sq += p * p;
      }
      return Math.sqrt(sq);
    }

    // The reference's zoom for a results fit: the farthest named result at FOCUS_UNIT units,
    // pulled back only as far as needed to keep each query within QUERY_ROOM of that.
    function resultsZoom(fit, list) {
      var hits = 0;
      var queries = 0;
      for (var s of list) {
        queries = Math.max(queries, shownLength(fit, s.query, 0));
        for (var h of s.hits) hits = Math.max(hits, shownLength(fit, set.vectors, h.index * D));
      }
      var reach = Math.max(hits, queries / QUERY_ROOM, MIN_REACH);
      return Number.isFinite(reach) ? FOCUS_UNIT / reach : fit.zoom;
    }

    function usableScale() {
      return want?.scale?.length === D ? want.scale : null;
    }

    function wantedJob() {
      var list = usableSearches();
      if (list.length) return resultsJob(list);
      if (whole) return { done: true, result: whole, kind: "all", letters: [], progress: 1, unit: () => true };
      return wholeJob();
    }

    // ----- turns ----------------------------------------------------------------

    // The view shown at time t, written into `into` ({ frame, centre }); returns the zoom.
    function sampleAt(t, into) {
      var i = turns.length - 1;
      while (i > 0 && turns[i].T > t) i--;
      var tn = turns[i];
      var e = tn.dur > 0 ? ET.math.smoothstep((t - tn.T) / tn.dur) : 1;
      if (e >= 1 || e <= 0) {
        // before the turn starts, and after it ends, the exact frame (no blend rounding)
        var end = e <= 0 ? tn.from : tn.to;
        into.frame.set(end.frame);
        into.centre.set(end.centre);
        return end.zoom;
      }
      ET.math.blendFrames(tn.from.frame, tn.to.frame, e, D, into.frame);
      for (var d = 0; d < D; d++) into.centre[d] = tn.from.centre[d] + (tn.to.centre[d] - tn.from.centre[d]) * e;
      return tn.from.zoom + (tn.to.zoom - tn.from.zoom) * e;
    }

    // Record the turn onto `fitted` at time T (never earlier than the last turn).
    function record(T, fitted, kind, letters) {
      var first = turns.length === 0;
      var at = first ? T : Math.max(T, turns.at(-1).T);
      var to = { frame: copyOf(fitted.frame), centre: copyOf(fitted.centre), zoom: fitted.zoom };
      var from = to;
      var dur = 0; // nothing to turn from: the first fit with no entry view is simply the view
      if (!first || entry) {
        var shown = { frame: new Float32Array(3 * D), centre: new Float32Array(D) };
        shown.zoom = first ? to.zoom : sampleAt(at, shown);
        if (first) {
          shown.frame.set(entry.frame);
          shown.centre.set(entry.centre || to.centre);
        }
        to.frame = ET.math.alignTo(to.frame, shown.frame, D);
        from = shown;
        dur = first ? opt.transition : opt.turn;
      }
      turns.push({ T: at, from: from, to: to, dur: dur, kind: kind, letters: letters });
      if (turns.length > MAX_TURNS) turns.shift();
    }

    function fixPending(t) {
      var p = pending;
      pending = null;
      record(Math.max(t, p.minT), p.result, p.kind, p.letters);
    }

    // ----- the interface --------------------------------------------------------

    function prepare() {
      if (empty) {
        return M.stepper([
          {
            required: true,
            run: function () {
              emptyReady = true;
              return true;
            },
          },
        ]);
      }
      var mine = epoch;
      var job = null;
      var jobVersion = -1;
      prepared = M.stepper([
        {
          required: true,
          weight: 1,
          progress: function () {
            return job ? job.progress() : 0;
          },
          run: function () {
            if (mine !== epoch || ready) return true;
            // A search that changed during the preparation restarts the fit on the new one.
            if (!job || jobVersion !== wantVersion) {
              job = wantedJob();
              jobVersion = wantVersion;
            }
            if (!job.unit()) return false;
            record(0, job.result, job.kind, job.letters);
            ready = true;
            return true;
          },
        },
      ]);
      return prepared;
    }

    function isReady() {
      return empty ? emptyReady : ready;
    }

    // The searches changed at mode time t (null: none). Returns a stepper to pump when
    // a fit has to be made (the view keeps its place until it is done and then turns
    // onto it), or null when there is nothing to pump.
    function searchChanged(search, t) {
      var next = snapshotOf(search);
      var same = sameFit(want, next);
      want = next;
      updateSpin();
      if (same) return null;
      wantVersion++;
      if (!ready || empty || !set) return null; // the preparation reads `want` when it runs
      var at = M.checkTime(t === undefined ? self.time : t);
      var job = wantedJob();
      if (job.done) {
        pending = { result: job.result, minT: at, kind: job.kind, letters: job.letters };
        fixPending(at);
        return null;
      }
      return fitStepper(job, at);
    }

    function fitStepper(job, at) {
      var mine = epoch;
      var version = wantVersion;
      return M.stepper([
        {
          required: true,
          weight: 1,
          progress: job.progress,
          run: function () {
            if (mine !== epoch || version !== wantVersion) return true; // superseded
            if (!job.unit()) return false;
            pending = { result: job.result, minT: at, kind: job.kind, letters: job.letters };
            return true;
          },
        },
      ]);
    }

    // Fix the time of a finished fit waiting to be turned onto.
    function mark(time) {
      if (pending) fixPending(M.checkTime(time));
    }

    function drawFor(zoom, t) {
      var draw = {
        zoom: zoom,
        wires: 0,
        dim: 1,
        trails: 0.17,
        fog: 0,
        fogNear: 1.2,
        fogWidth: 0.8,
        twinkle: 0.18,
        depthOfField: 1.1,
      };
      if (hasUsableSearch()) draw.unlitGain = want.onlyResults ? 0 : FOCUS_UNLIT;
      return M.blendDraw(draw, entry, t, opt.transition);
    }

    function stateAt(time) {
      var t = M.checkTime(time);
      if (!isReady() || empty) return M.holdState(out, hold, entry, t, status(t));
      if (pending) fixPending(t); // no time was given: the first query fixes it
      out.t = t;
      var zoom = sampleAt(t, out);
      out.draw = drawFor(zoom, t);
      out.wires = null;
      out.focus = null;
      out.status = status(t);
      return out;
    }

    function step(dt) {
      self.time = Math.max(0, self.time + dt);
      return stateAt(self.time);
    }

    function turnAt(t) {
      var i = turns.length - 1;
      while (i > 0 && turns[i].T > t) i--;
      return turns[i];
    }

    function status(time) {
      var t = M.checkTime(time === undefined ? self.time : time);
      if (empty) return M.EMPTY_STATUS;
      if (!isReady()) {
        var pct = Math.round((prepared ? prepared.progress : 0) * 100);
        return "fitting the view to the set in " + D + "-d … " + pct + "%";
      }
      var tn = turnAt(t);
      return tn.kind === "results" ? "fitted to the results of " + tn.letters.join(", ") : "fitted to every point";
    }

    // Any change of the data starts the mode again from the view shown (the
    // searches are kept: the viewer asks for them again when their results change).
    function dataChanged(newSet, info) {
      var i = info || {};
      var t = i.t === undefined ? self.time : M.checkTime(i.t);
      var from = entry;
      if (isReady()) {
        var s = stateAt(t);
        from = { frame: copyOf(s.frame), centre: null, draw: { ...s.draw } };
        if (!empty || entry?.centre) from.centre = copyOf(s.centre);
      }
      enter(newSet, { seed: seed, from: from });
      return M.changed(prepare(), true);
    }

    function describe() {
      var last = turns.length ? turns.at(-1) : null;
      var results = last?.kind === "results";
      return {
        id: "focus",
        projection: "linear: an orthonormal 3-frame fitted to the results of the searches, or to the whole set",
        seed: seed,
        fittedTo: results ? "results" : "all",
        searches: results ? last.letters.slice() : [],
        onlyResults: want?.onlyResults === true,
        empty: empty,
        varianceShare: null,
      };
    }

    function leave() {
      epoch++;
      turns = [];
      pending = null;
      prepared = null;
      whole = null;
      set = null;
    }

    return self;
  }

  M.register({
    id: "focus",
    title: "Focus",
    summary: "The view fitted to the search results",
    create: create,
  });
})();
  // ---------- the search panel (task t9 of the search plan) ----------
  //
  // ET.searchPanel builds the panel under the stage: a one-line bar (collapsed by
  // default) that names the searches and how many points are lit, and, when opened, the
  // text box (one search per line, up to four), suggestions from the loaded points, the
  // controls, the note, the pair lines and one result list per search. It also draws the
  // query rings and links on the overlay and puts the result labels over the stage as DOM
  // text, and in Focus it lays the ranked lists beside the stage.
  //
  // It drives the viewer only through the handle (setSearches, clearSearches,
  // setSearchSettings, faceSearches, info, mode), so everything it does can be done
  // without it. Every query, label, result text and message goes in with textContent.
  // Styles are set through element.style, as the viewer does. It makes no request.
  // The interface is docs/search-interface.md, "Panel (t9)", and js/api/45-search-panel.md.

  var SP_DARK = ["#ffc56b", "#6be0ff", "#ff8fb3", "#b6ff8a"];
  var SP_LIGHT = ["#a35f00", "#00708a", "#b0245a", "#3d7a00"];
  var SP_SHARED_DARK = "#ffffff";
  var SP_SHARED_LIGHT = "#1b2130";
  var SP_MAX_LINES = 4;
  var SP_PAUSE_MS = 140; // the reference waits this long after typing before it searches
  var SP_SUGGEST_MAX = 8; // the Focus reference lists up to eight suggestions
  var SP_SUGGEST_CHARS = 60; // a suggestion's button text is cut here; the click uses all of it
  var SP_STAGE_TEXT = 28; // a result's text on the stage is cut here; the list carries all of it
  // Labels on the stage at most. With 4 searches of up to 100 results the overlap rule leaves
  // most out long before this; the lists carry every result.
  var SP_LABEL_POOL = 160;
  var SP_MAX_COUNT = 100; // the most results, candidates or kept a search can ask for
  var SP_K_RERANKED = "With the reranker on, Keep top sets how many results are kept.";
  var SP_CHAR_W = 6.7; // estimated width of one 11 px monospace character, CSS px
  var SP_LABEL_H = 12; // height of one stage label box, CSS px
  var SP_LIT_TEXT = {
    even: "the results, evenly",
    close: "by closeness: nearer is brighter",
    named: "named results only",
  };
  var SP_PALETTE_DARK = { fg: "#e9eef6", muted: "#8a96ab", line: "#1b2436", accent: "#ffc56b", bg: "#04060b" };
  var SP_PALETTE_LIGHT = { fg: "#1b2130", muted: "#5b6578", line: "#d6dae2", accent: "#a35f00", bg: "#f6f4ee" };
  // A value that could name a resource is not used. The "r" is written as an escape so that
  // this file holds no CSS resource function by name (js/test/viewer-static.test.js bans it).
  var SP_UNSAFE = /u\x72l\(|image-set|[\\;{}<>]/i;
  var spCounter = 0;

  // ----- text: the bar, the provenance line, the note, the lists -----

  // 1234567 -> "1,234,567" (fixed, not the host's locale, so tests and screenshots agree).
  function spThousands(n) {
    var s = String(Math.round(Math.abs(Number(n) || 0)));
    var out = "";
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 === 0) out += ",";
      out += s[i];
    }
    return (Number(n) < 0 ? "-" : "") + out;
  }

  function spPlural(n, one, many) {
    return spThousands(n) + " " + (n === 1 ? one : many);
  }

  function spShorten(s, max) {
    var str = String(s);
    return str.length > max ? str.slice(0, max - 1) + "…" : str;
  }

  function spActive(search) {
    return !!search && search.active === true && Array.isArray(search.searches) && search.searches.length > 0;
  }

  // The collapsed bar's text.
  function summaryText(search) {
    var tail = "";
    if (search?.waiting) tail += " · waiting";
    if (search?.stale) tail += " · from before " + spPlural(search.staleBy, "new point", "new points");
    if (!spActive(search)) {
      return (search?.waiting ? "working out the search" : "nothing searched: every point is shown") + tail;
    }
    var names = search.searches.map(function (q) {
      return q.letter + " " + q.text;
    });
    return names.join(" · ") + " · " + spThousands(search.litCount) + " points lit" + tail;
  }

  // Where one search's text went, and what made its query.
  function spMadeBy(q) {
    var form = q.queryForm ? " (query form " + q.queryForm + ")" : "";
    if (q.kind === "embedded") return "embedded by " + q.model + form + "; text sent to the host's embedder";
    if (q.kind === "words") return "words matched among the loaded points (" + q.model + "); nothing sent";
    if (q.kind === "point") return "the loaded point " + q.point + " (" + q.model + "); nothing sent";
    return "a vector from the host (" + q.model + "); nothing sent by the viewer";
  }

  // `others`: some other search was reranked, so a search that was not says what it kept.
  function spRerankedBy(q, others) {
    if (!q.reranker) return others ? "; not reranked: the " + spThousands(q.results.length) + " nearest kept" : "";
    return (
      "; reranked by " +
      q.reranker +
      " (" +
      spKeptOf(q) +
      "): query and candidate texts sent to the reranker"
    );
  }

  // "top 20 of 50 candidates": what one reranked search kept, as it happened.
  function spKeptOf(q) {
    return "top " + spThousands(q.results.length) + " of " + spPlural(q.sent, "candidate", "candidates");
  }

  // The counts the searches used: candidates and kept when a search was reranked, k otherwise
  // (a search the reranker failed on keeps the k nearest, and says so in its note).
  function spCountsUsed(search, reranked) {
    var st = search.settings || {};
    var plain = "the " + spThousands(st.k) + " nearest kept (" + spPlural(st.k, "result", "results") + " per search)";
    if (!reranked) return plain;
    return "the " + spThousands(st.candidates) + " nearest as candidates, the reranker's top " + spThousands(st.top) + " kept";
  }

  // What the searches used, for the provenance row.
  function usedText(search) {
    if (!spActive(search)) return "no search";
    var st = search.settings || {};
    var reranked = search.searches.some(function (q) {
      return !!q.reranker;
    });
    var parts = [search.measure, spCountsUsed(search, reranked), "lit: " + (SP_LIT_TEXT[st.lit] || SP_LIT_TEXT.even)];
    search.searches.forEach(function (q) {
      parts.push(q.letter + ' "' + q.text + '": ' + spMadeBy(q) + spRerankedBy(q, reranked));
    });
    if (!reranked) parts.push("no reranker");
    if (st.pointOfView) parts.push("point of view: " + st.pointOfView + " (each dimension scaled by its query)");
    return parts.join(" · ");
  }

  // The short clause added to the provenance summary.
  function spProvenanceClause(search) {
    if (!spActive(search)) return "";
    var where = [];
    var kinds = spKinds(search);
    if (kinds.embedder) where.push("typed text sent to the host's embedder");
    if (kinds.reranker) where.push("query and candidate texts sent to the reranker");
    if (kinds.local) where.push("searched among the loaded points, nothing sent");
    return " · search: " + where.join(", ");
  }

  function spKinds(search) {
    var out = { embedder: false, reranker: false, local: false };
    search.searches.forEach(function (q) {
      if (q.sentTo === "embedder") out.embedder = true;
      else out.local = true;
      if (q.reranker) out.reranker = true;
    });
    return out;
  }

  // Where typed text goes, said whenever the panel is open and whenever a search is shown.
  function spWhereText(search) {
    var parts = [];
    if (spActive(search)) {
      var kinds = spKinds(search);
      if (kinds.embedder) parts.push("The typed text was sent to the host's embedder.");
      if (kinds.reranker) parts.push("The query and the candidate texts were sent to the reranker.");
      if (kinds.local) parts.push("Searched among the loaded points: nothing was sent anywhere.");
    } else if (search?.embedder?.available) {
      parts.push("Typed text is sent to the host's embedder; nothing else leaves the page.");
    }
    if (!search?.embedder?.available) {
      parts.push(
        "No embedder is connected, so typed words are matched against the labels and texts of the loaded points, and nothing is sent."
      );
    }
    return parts.join(" ");
  }

  function spLitQualifier(setting) {
    if (setting === "close") return ", nearer ones brighter";
    if (setting === "named") return " (named results only)";
    return "";
  }

  // One search's counts: its named results and the other points as near as the last of them.
  function spCountsText(q) {
    var named = q.results.length;
    var others = Math.max(0, (q.insideCount || 0) - named);
    return (
      spPlural(named, "named result", "named results") +
      " and " +
      (others ? spPlural(others, "unnamed point", "unnamed points") : "no unnamed point") +
      " as near as the last of them"
    );
  }

  function spLitSentence(search) {
    var st = search.settings || {};
    var lit = spThousands(search.litCount) + " points lit" + spLitQualifier(st.lit);
    if (search.searches.length === 1) {
      var q = search.searches[0];
      var named = q.results.length;
      var others = Math.max(0, (q.insideCount || 0) - named);
      return (
        lit +
        ": " +
        spPlural(named, "named result", "named results") +
        (others ? " and every unnamed point as near as the last of them (" + spThousands(others) + ")" : "") +
        "."
      );
    }
    var each = search.searches.map(function (q) {
      return q.letter + ": " + spCountsText(q);
    });
    var shared = search.sharedCount
      ? " " + spPlural(search.sharedCount, "point is", "points are") + " inside more than one search."
      : "";
    return lit + ". " + each.join("; ") + "." + shared;
  }

  // Every sentence of the note, in order.
  function spNoteParts(search, ctx) {
    var parts = [];
    if (spActive(search)) parts.push(spLitSentence(search));
    else if (!search?.waiting) parts.push("Nothing searched: every point is shown.");
    if (search?.waiting) parts.push("Working out the searches…");
    if (search?.stale) {
      parts.push(
        "These results are from before " +
          spPlural(search.staleBy, "new point", "new points") +
          "; they are being worked out again."
      );
    }
    var where = spWhereText(search);
    if (where) parts.push(where);
    if (spActive(search)) parts.push("Distances are " + search.measure + ", in every dimension of the data.");
    spSearchNotes(search, parts);
    if (search?.unmatched?.length) parts.push("Not found among the loaded points: " + search.unmatched.join(", ") + ".");
    if (ctx.extraLines > 0) {
      parts.push("Only the first four lines are searched; " + spPlural(ctx.extraLines, "line is", "lines are") + " left out.");
    }
    spTailNotes(search, ctx, parts);
    return parts;
  }

  // Messages, refusals and the two sentences about the stage.
  function spTailNotes(search, ctx, parts) {
    if (search?.message) parts.push(search.message);
    if (ctx.refusal && ctx.refusal !== search?.message) parts.push(ctx.refusal);
    if (!spActive(search)) return;
    if (ctx.focus && !search.faceable) {
      parts.push("Focus is already fitted to the results, so Face the searches is off here.");
    }
    parts.push("Where labels on the stage would overlap, the later ones are left out; the lists carry every result.");
  }

  function spSearchNotes(search, parts) {
    if (!spActive(search)) return;
    search.searches.forEach(function (q) {
      if (q.pointOfView) {
        parts.push(
          q.letter +
            " is measured from its own point of view: every dimension is scaled by the size of its query's value there (a linear change); the other searches keep plain distance."
        );
      }
      if (q.counts) parts.push(q.letter + ": " + q.counts);
      if (q.note) parts.push(q.letter + ": " + q.note);
    });
  }

  // A result's text by id, from the searches' own results.
  function spTextOf(search, id) {
    for (var q of search.searches) {
      for (var r of q.results) {
        if (r.id === id) return r.text;
      }
    }
    return id;
  }

  // One pair line: shared count, named results in common, the closest pair of different results.
  function spPairText(search, pair, sharedWord) {
    var s = pair.a + " and " + pair.b + ": ";
    s += pair.shared ? spPlural(pair.shared, "point", "points") + " found by both (" + sharedWord + ")" : "no point found by both";
    if (pair.common) {
      var common = pair.commonIds.map(function (id) {
        return spTextOf(search, id);
      });
      s += "; " + spPlural(pair.common, "named result", "named results") + " in common (" + common.join(", ") + ")";
    }
    if (pair.closest) {
      s +=
        "; closest pair of different results " +
        spTextOf(search, pair.closest.a) +
        " and " +
        spTextOf(search, pair.closest.b) +
        ", " +
        pair.closest.distance.toFixed(3) +
        " apart";
    }
    return s + ".";
  }

  // How one search's query was made, for its list heading.
  function spKindText(q) {
    if (q.kind === "embedded") return "embedded by " + q.model;
    if (q.kind === "point") return "from the point " + q.point;
    if (q.kind === "vector") return "a vector from the host";
    var used = q.words?.used || [];
    return (
      "words matched: " +
      used
        .map(function (u) {
          return u.how === "prefix" ? u.word + "…" : u.word;
        })
        .join(", ")
    );
  }

  function spListHeading(q) {
    return (
      q.letter +
      " · " +
      q.text +
      " · " +
      spCountsText(q) +
      " · " +
      spKindText(q) +
      (q.reranker ? " · embedding order, then the reranker " + q.reranker + " (" + spKeptOf(q) + ")" : "") +
      (q.pointOfView ? " · from its point of view" : "")
    );
  }

  // The parts of a result's meta line, as the picture and the references show them.
  function spResultMeta(q, r, distances) {
    var out = [];
    if (distances) {
      out.push(
        "distance " + r.distance.toFixed(3) + (q.pointOfView ? " from its point of view" : ""),
        r.gap < 0.0005 ? "the nearest" : "+" + r.gap.toFixed(3) + " farther than the nearest"
      );
    }
    if (q.reranker) out.push(spMoveText(r.embeddingRank - r.rank, r.embeddingRank));
    if (q.pointOfView && r.plainRank !== r.embeddingRank) out.push("plain distance had it at " + r.plainRank);
    return out;
  }

  function spMoveText(by, was) {
    if (by > 0) return "up " + by + " (was " + was + ")";
    if (by < 0) return "down " + -by + " (was " + was + ")";
    return "same place";
  }

  // Suggestions: the texts of named points matching what is typed on the current line
  // (the Focus reference: the whole line starts the text, or the last word starts a word of
  // it), whole-line matches first, at most SP_SUGGEST_MAX, never the line itself.
  function spSuggest(entries, typed) {
    var t = String(typed || "")
      .trim()
      .toLowerCase()
      .replace(/\s+/g, " ");
    if (!t) return [];
    var last = t.split(" ").at(-1);
    var first = [];
    var rest = [];
    for (var e of entries) {
      if (e.lower === t) continue;
      if (e.lower.startsWith(t)) first.push(e.text);
      else if (last.length > 1 && spWordStarts(e.words, last)) rest.push(e.text);
      if (first.length >= SP_SUGGEST_MAX) break;
    }
    return first.concat(rest).slice(0, SP_SUGGEST_MAX);
  }

  function spWordStarts(words, prefix) {
    for (var w of words) {
      if (w.startsWith(prefix)) return true;
    }
    return false;
  }

  // The named points' texts of a set, once per set and count (an append adds to them).
  function spEntries(p) {
    var set = spData(p);
    if (!set?.count || typeof ET.search?.isNamed !== "function") return [];
    var cache = p.suggestCache;
    if (cache.set === set && cache.count === set.count) return cache.entries;
    var seen = new Set();
    var entries = [];
    for (var i = 0; i < set.count; i++) {
      if (!ET.search.isNamed(set, i)) continue;
      var text = String(ET.search.pointText(set, i)).trim().replace(/\s+/g, " ");
      var lower = text.toLowerCase();
      if (seen.has(lower)) continue;
      seen.add(lower);
      entries.push({ text: text, lower: lower, words: lower.split(" ") });
    }
    p.suggestCache = { set: set, count: set.count, entries: entries };
    return entries;
  }

  function spData(p) {
    try {
      return typeof p.opts.data === "function" ? p.opts.data() : null;
    } catch {
      // A data getter that throws gives no suggestions.
      return null;
    }
  }

  // ----- colours -----

  // One channel in 0..1 as 0..255.
  function spByte(x) {
    return Math.round(Math.min(1, Math.max(0, Number(x) || 0)) * 255);
  }

  function spHex(c) {
    // [r, g, b] in 0..1 -> "rgb(r, g, b)"
    return "rgb(" + spByte(c[0]) + ", " + spByte(c[1]) + ", " + spByte(c[2]) + ")";
  }

  function spTheme(p) {
    try {
      return typeof p.opts.theme === "function" ? p.opts.theme() || null : null;
    } catch {
      // A theme getter that throws: the built-in palette for the stage's lightness.
      return null;
    }
  }

  function spLight(p) {
    var t = spTheme(p);
    return t ? !!t.light : !!p.opts.light;
  }

  // The viewer's colours as CSS strings (its theme when given, else the built-in defaults).
  function spPalette(p) {
    var t = spTheme(p);
    var base = spLight(p) ? SP_PALETTE_LIGHT : SP_PALETTE_DARK;
    if (!t) return { ...base };
    return {
      fg: spPick(t.foreground, base.fg),
      muted: spPick(t.muted, base.muted),
      line: spPick(t.line, base.line),
      accent: spPick(t.accent, base.accent),
      bg: spPick(t.background, base.bg),
    };
  }

  // A theme colour ([r, g, b]) as CSS, or the default when the theme does not give one.
  function spPick(c, d) {
    return Array.isArray(c) ? spHex(c) : d;
  }

  // A search's colour for DOM text: the host's custom property, else the default for the stage.
  function spSearchVar(j, light) {
    return "var(--tumbler-search-" + (j + 1) + ", " + (light ? SP_LIGHT : SP_DARK)[j] + ")";
  }

  function spSharedVar(light) {
    return "var(--tumbler-shared, " + (light ? SP_SHARED_LIGHT : SP_SHARED_DARK) + ")";
  }

  // The colours the overlay strokes with: each custom property resolved by the 2-D context
  // itself (an invalid or unsafe value leaves the default in place).
  function spCanvasColours(p, ctx) {
    var light = spLight(p);
    var defaults = (light ? SP_LIGHT : SP_DARK).concat([light ? SP_SHARED_LIGHT : SP_SHARED_DARK]);
    var names = ["--tumbler-search-1", "--tumbler-search-2", "--tumbler-search-3", "--tumbler-search-4", "--tumbler-shared"];
    var cs = null;
    try {
      cs = p.win?.getComputedStyle ? p.win.getComputedStyle(p.parts.panel) : null;
    } catch {
      // No computed style: the defaults.
      cs = null;
    }
    return names.map(function (name, j) {
      var raw = cs ? String(cs.getPropertyValue(name) || "").trim() : "";
      ctx.strokeStyle = defaults[j];
      if (raw && !SP_UNSAFE.test(raw)) ctx.strokeStyle = raw;
      return String(ctx.strokeStyle || defaults[j]);
    });
  }

  // ----- DOM helpers -----

  function spEl(p, tag, cls, styles) {
    var el = p.doc.createElement(tag);
    if (cls) el.className = cls;
    if (styles) spStyle(el, styles);
    return el;
  }

  function spText(p, tag, cls, str, styles) {
    var el = spEl(p, tag, cls, styles);
    el.textContent = str;
    return el;
  }

  function spStyle(el, styles) {
    for (var k in styles) {
      if (Object.hasOwn(styles, k)) el.style[k] = styles[k];
    }
  }

  function spListen(p, el, type, fn) {
    el.addEventListener(type, fn);
    p.listeners.push([el, type, fn]);
  }

  function spShow(el, on, display) {
    el.hidden = !on;
    el.style.display = on ? display : "none";
  }

  var SP_VISUALLY_HIDDEN = {
    position: "absolute",
    width: "1px",
    height: "1px",
    margin: "-1px",
    padding: "0",
    border: "0",
    overflow: "hidden",
    clip: "rect(0 0 0 0)",
    whiteSpace: "nowrap",
  };

  function spControlStyle(pal) {
    return {
      fontFamily: "inherit",
      fontSize: "12px",
      color: pal.fg,
      background: pal.bg,
      border: "1px solid " + pal.line,
      padding: "4px 6px",
      maxWidth: "100%",
    };
  }

  function spButtonStyle(pal) {
    return {
      fontFamily: "inherit",
      fontSize: "12px",
      color: pal.fg,
      background: "transparent",
      border: "1px solid " + pal.line,
      borderRadius: "999px",
      padding: "6px 16px",
      minHeight: "28px",
      cursor: "pointer",
    };
  }

  // ----- building the panel -----

  function spBuildBar(p) {
    var bar = spEl(p, "button", "tumbler-search-bar", {
      display: "flex",
      alignItems: "baseline",
      gap: "12px",
      width: "100%",
      minWidth: "0",
      textAlign: "left",
      cursor: "pointer",
      background: "transparent",
      border: "0",
      borderTop: "1px solid",
      borderBottom: "1px solid",
      padding: "var(--tumbler-search-bar-padding, 10px 0)",
      font: "inherit",
      fontSize: "12px",
      lineHeight: "1.2",
      color: "inherit",
    });
    bar.type = "button";
    bar.setAttribute("aria-expanded", "false");
    bar.setAttribute("aria-controls", p.bodyId);
    p.barTitle = spText(p, "b", "", "Search", {
      fontWeight: "400",
      fontStyle: "italic",
      fontSize: "var(--tumbler-search-title-size, 24px)",
      lineHeight: "1",
    });
    p.barSummary = spText(p, "span", "tumbler-search-summary", summaryText(null), {
      flex: "1",
      minWidth: "0",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
    });
    p.barMark = spText(p, "i", "tumbler-search-mark", "+", { fontStyle: "normal", fontSize: "16px" });
    p.barMark.setAttribute("aria-hidden", "true");
    bar.appendChild(p.barTitle);
    bar.appendChild(p.barSummary);
    bar.appendChild(p.barMark);
    spListen(p, bar, "click", function () {
      spToggle(p);
    });
    return bar;
  }

  function spBuildInput(p) {
    var id = "tumbler-search-input-" + p.n;
    var label = spText(p, "label", "tumbler-search-input-label", "Search: one search per line, up to four", {
      fontSize: "12px",
      letterSpacing: "0.06em",
      textTransform: "uppercase",
    });
    label.htmlFor = id;
    label.setAttribute("for", id);
    var box = spEl(p, "textarea", "tumbler-search-input", {
      width: "100%",
      minHeight: "92px",
      resize: "vertical",
      padding: "10px 12px",
      boxSizing: "border-box",
      fontFamily: "var(--tumbler-font, inherit)",
      fontSize: "16px",
      lineHeight: "1.4",
    });
    box.id = id;
    box.setAttribute("spellcheck", "false");
    box.setAttribute("autocomplete", "off");
    box.setAttribute("rows", "3");
    p.input = box;
    spListen(p, box, "input", function () {
      spTyped(p);
    });
    p.suggestBox = spEl(p, "div", "tumbler-search-suggest", { display: "flex", flexWrap: "wrap", gap: "6px 8px", alignItems: "center" });
    p.suggestBox.setAttribute("role", "group");
    p.suggestBox.setAttribute("aria-label", "Suggestions from the loaded points");
    spShow(p.suggestBox, false, "flex");
    spListen(p, p.suggestBox, "click", function (ev) {
      spSuggestClick(p, ev);
    });
    return [label, box, p.suggestBox];
  }

  function spLabelled(p, cls, words) {
    var label = spEl(p, "label", cls, { display: "inline-flex", alignItems: "center", gap: "8px" });
    if (words) label.appendChild(p.doc.createTextNode(words + " "));
    return label;
  }

  function spCheckbox(p, cls, words, key) {
    var label = spLabelled(p, cls, "");
    var box = spEl(p, "input", "", { width: "15px", height: "15px", margin: "0" });
    box.type = "checkbox";
    label.appendChild(box);
    label.appendChild(p.doc.createTextNode(" " + words));
    spListen(p, box, "change", function () {
      spSetting(p, key, !!box.checked);
    });
    return { label: label, input: box };
  }

  function spSelect(p, cls, words, options) {
    var label = spLabelled(p, cls, words);
    var sel = spEl(p, "select", "", {});
    options.forEach(function (o) {
      sel.appendChild(spOption(p, o[0], o[1]));
    });
    label.appendChild(sel);
    return { label: label, input: sel };
  }

  function spOption(p, value, words) {
    var o = spText(p, "option", "", words);
    o.value = value;
    return o;
  }

  // A labelled range from 3 to 100 with its value beside it; moving it sets `key`.
  function spRange(p, cls, words, key, value) {
    var label = spLabelled(p, cls, words);
    var input = spEl(p, "input", "", { width: "110px" });
    input.type = "range";
    input.min = "3";
    input.max = String(SP_MAX_COUNT);
    input.step = "1";
    input.value = String(value);
    var out = spText(p, "output", "", String(value), { minWidth: "3ch" });
    label.appendChild(input);
    label.appendChild(out);
    spListen(p, input, "input", function () {
      out.textContent = String(input.value);
      spSetting(p, key, Number(input.value));
    });
    return { label: label, input: input, out: out };
  }

  // Show a range's value from the settings (never while it is the same, so a drag is not reset).
  function spRangeValue(r, value, max) {
    if (max && r.input.max !== String(max)) r.input.max = String(max);
    if (value && String(r.input.value) !== String(value)) {
      r.input.value = String(value);
      r.out.textContent = String(value);
    }
  }

  function spBuildControls(p) {
    var row = spEl(p, "div", "tumbler-search-controls", { display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px 22px",
      fontSize: "12px" });
    p.face = spText(p, "button", "tumbler-search-face", "Face the searches");
    p.face.type = "button";
    spListen(p, p.face, "click", function () {
      p.handle.faceSearches();
    });
    var lit = spSelect(p, "tumbler-search-lit", "Lit", [
      ["even", SP_LIT_TEXT.even],
      ["close", SP_LIT_TEXT.close],
      ["named", SP_LIT_TEXT.named],
    ]);
    p.lit = lit.input;
    spListen(p, p.lit, "change", function () {
      spSetting(p, "lit", p.lit.value);
    });
    p.rerank = spCheckbox(p, "tumbler-search-rerank", "Reranker", "rerank");
    p.distances = spCheckbox(p, "tumbler-search-distances", "Distance difference", "distances");
    var k = spRange(p, "tumbler-search-k", "Results", "k", 8);
    p.kLabel = k.label;
    p.k = k.input;
    p.kOut = k.out;
    // Beside the Reranker, and like it in the row only while a reranker is offered.
    p.cand = spRange(p, "tumbler-search-candidates", "Candidates", "candidates", 50);
    p.top = spRange(p, "tumbler-search-top", "Keep top", "top", 20);
    var pov = spSelect(p, "tumbler-search-pov", "From this search's point of view", [["", "off"]]);
    p.pov = pov.input;
    p.povLabel = pov.label;
    spListen(p, p.pov, "change", function () {
      spSetting(p, "pointOfView", p.pov.value || null);
    });
    p.only = spCheckbox(p, "tumbler-search-only", "Only results", "onlyResults");
    p.clear = spText(p, "button", "tumbler-search-clear", "Clear");
    p.clear.type = "button";
    spListen(p, p.clear, "click", function () {
      spClear(p);
    });
    p.litLabel = lit.label;
    [p.face, lit.label, p.rerank.label, p.cand.label, p.top.label, p.distances.label, p.kLabel, pov.label, p.only.label, p.clear].forEach(function (c) {
      row.appendChild(c);
    });
    return row;
  }

  function spBuild(p) {
    var section = spEl(p, "section", "tumbler-search", { display: "flex", flexDirection: "column", gap: "10px", minWidth: "0" });
    section.setAttribute("aria-label", "Search");
    p.section = section;
    section.appendChild(spBuildBar(p));
    p.live = spEl(p, "p", "tumbler-search-live", SP_VISUALLY_HIDDEN);
    p.live.setAttribute("role", "status");
    p.live.setAttribute("aria-live", "polite");
    section.appendChild(p.live);
    var body = spEl(p, "div", "tumbler-search-body", { flexDirection: "column", gap: "10px", minWidth: "0" });
    body.id = p.bodyId;
    spShow(body, false, "flex");
    p.body = body;
    spBuildInput(p).forEach(function (el) {
      body.appendChild(el);
    });
    body.appendChild(spBuildControls(p));
    p.note = spEl(p, "p", "tumbler-search-note", { margin: "0", fontSize: "12px", lineHeight: "1.6" });
    p.pairs = spEl(p, "div", "tumbler-search-pairs", { display: "flex", flexDirection: "column", gap: "4px" });
    p.results = spEl(p, "div", "tumbler-search-results", { display: "flex", flexDirection: "column", gap: "6px" });
    body.appendChild(p.note);
    body.appendChild(p.pairs);
    body.appendChild(p.results);
    section.appendChild(body);
    var panel = p.parts.panel;
    panel.insertBefore(section, panel.firstChild);
  }

  // Colours that come from the viewer's theme (re-applied when the theme object changes).
  function spApplyTheme(p) {
    var pal = spPalette(p);
    p.pal = pal;
    p.light = spLight(p);
    spStyle(p.section, { color: pal.muted, fontFamily: "var(--tumbler-font-data, inherit)" });
    var bar = p.section.firstChild;
    bar.style.borderTopColor = pal.line;
    bar.style.borderBottomColor = pal.line;
    bar.style.color = pal.muted;
    spStyle(p.barTitle, { color: pal.fg, fontFamily: "var(--tumbler-font-display, Georgia, serif)" });
    p.barMark.style.color = pal.accent;
    spStyle(p.input, { color: pal.fg, background: pal.bg, border: "1px solid " + pal.line });
    spStyle(p.lit, spControlStyle(pal));
    spStyle(p.pov, spControlStyle(pal));
    [p.face, p.clear].forEach(function (b) {
      spStyle(b, spButtonStyle(pal));
    });
    [p.rerank.input, p.distances.input, p.only.input, p.k, p.cand.input, p.top.input].forEach(function (c) {
      c.style.accentColor = pal.accent;
    });
    p.note.style.color = pal.muted;
    p.listKey = null; // lists are rebuilt in the new colours
    p.sideKey = null;
    p.colours = null;
    if (p.suggested?.length) spRenderSuggestions(p);
  }

  // ----- behaviour -----

  function spToggle(p) {
    spSetOpen(p, !p.open);
    if (p.open) p.input.focus();
  }

  function spSetOpen(p, open) {
    p.open = open;
    spShow(p.body, open, "flex");
    var bar = p.section.firstChild;
    bar.setAttribute("aria-expanded", open ? "true" : "false");
    p.barMark.textContent = open ? "−" : "+";
  }

  // The lines the box holds, trimmed, empty ones dropped.
  function spLines(value) {
    return String(value || "")
      .split(/\n/)
      .map(function (s) {
        return s.trim();
      })
      .filter(Boolean);
  }

  function spTyped(p) {
    spRenderSuggestions(p);
    if (p.timer && p.win?.clearTimeout) p.win.clearTimeout(p.timer);
    p.timer = 0;
    if (typeof p.win?.setTimeout !== "function") {
      spRun(p);
      return;
    }
    p.timer = p.win.setTimeout(function () {
      p.timer = 0;
      spRun(p);
    }, SP_PAUSE_MS);
  }

  // Send the box's first four lines to the viewer (or clear when it is empty).
  function spRun(p) {
    if (p.destroyed) return;
    var lines = spLines(p.input.value);
    p.extraLines = Math.max(0, lines.length - SP_MAX_LINES);
    var send = lines.slice(0, SP_MAX_LINES);
    var key = send.join("\n");
    if (key === p.lastSent) {
      spRender(p);
      return;
    }
    p.lastSent = key;
    p.refusal = null;
    if (!send.length) {
      p.handle.clearSearches();
      spRender(p);
      return;
    }
    spWatch(p, p.handle.setSearches(send));
  }

  // A refusal from the viewer is shown in the note (superseded and destroyed are not refusals).
  function spWatch(p, promise) {
    if (typeof promise?.then !== "function") return;
    promise.then(function (res) {
      if (p.destroyed || !res || res.ok) return;
      if (res.code === "superseded" || res.code === "destroyed") return;
      p.refusal = res.message;
      p.lastSent = null; // the same text can be tried again
      spRender(p);
    });
  }

  function spSetting(p, key, value) {
    var patch = {};
    patch[key] = value;
    spWatch(p, p.handle.setSearchSettings(patch));
  }

  function spClear(p) {
    if (p.timer && p.win?.clearTimeout) p.win.clearTimeout(p.timer);
    p.timer = 0;
    p.input.value = "";
    p.lastSent = "";
    p.extraLines = 0;
    p.refusal = null;
    p.handle.clearSearches();
    spRenderSuggestions(p);
    spRender(p);
  }

  // The line the caret is on (the last line when the box cannot say).
  function spCurrentLine(box) {
    var value = String(box.value || "");
    var at = typeof box.selectionStart === "number" ? box.selectionStart : value.length;
    var start = value.lastIndexOf("\n", Math.max(0, at - 1)) + 1;
    if (at === 0) start = 0;
    var end = value.indexOf("\n", at);
    return { start: start, end: end < 0 ? value.length : end };
  }

  function spRenderSuggestions(p) {
    var box = p.suggestBox;
    box.textContent = "";
    var where = spCurrentLine(p.input);
    var typed = String(p.input.value || "").slice(where.start, where.end);
    var found = spSuggest(spEntries(p), typed);
    p.suggested = found;
    spShow(box, found.length > 0, "flex");
    if (!found.length) return;
    box.appendChild(spText(p, "span", "", "suggestions from the loaded points", { fontSize: "12px" }));
    var pal = p.pal || SP_PALETTE_DARK;
    found.forEach(function (text, i) {
      var b = spText(p, "button", "tumbler-search-suggestion", spShorten(text, SP_SUGGEST_CHARS), {
        ...spButtonStyle(pal),
        borderRadius: "0",
        padding: "4px 10px",
      });
      b.type = "button";
      b.dataset.index = String(i);
      if (text.length > SP_SUGGEST_CHARS) b.setAttribute("aria-label", text);
      box.appendChild(b);
    });
  }

  // A click on a suggestion puts its text on the current line and searches at once.
  function spSuggestClick(p, ev) {
    var n = ev.target;
    while (n && n !== p.suggestBox && n.tagName !== "BUTTON") n = n.parentNode;
    if (!n || n === p.suggestBox) return;
    var text = p.suggested[Number(n.dataset.index)];
    if (typeof text !== "string") return;
    var value = String(p.input.value || "");
    var where = spCurrentLine(p.input);
    p.input.value = value.slice(0, where.start) + text + value.slice(where.end);
    if (p.timer && p.win?.clearTimeout) p.win.clearTimeout(p.timer);
    p.timer = 0;
    spRun(p);
    spRenderSuggestions(p);
    p.input.focus();
  }

  // When the searches shown were not typed here (a host's call, a click in Focus), the box
  // shows them, so editing it searches from what is shown.
  // Text searches are synced only into an empty box, so a typed line that matched nothing
  // (and was left out) is never wiped from what the person wrote.
  function spSyncInput(p, search) {
    if (!spActive(search) || p.timer || p.doc.activeElement === p.input) return;
    var shownKey = search.searches
      .map(function (q) {
        return q.kind + ":" + q.text;
      })
      .join("\n");
    if (shownKey === p.syncKey) return; // the same searches again (waiting, a re-run)
    p.syncKey = shownKey;
    var foreign = search.searches.some(function (q) {
      return q.kind === "point" || q.kind === "vector";
    });
    if (!foreign && spLines(p.input.value).length) return;
    var lines = search.searches.map(function (q) {
      if (q.kind === "point" && q.results[0]?.id === q.point) return q.results[0].text;
      return q.text;
    });
    var key = lines.join("\n");
    p.input.value = key;
    p.lastSent = key;
  }

  // ----- rendering from info().search -----

  function spRender(p) {
    if (p.destroyed) return;
    var search = p.search;
    var text = summaryText(search);
    if (p.barSummary.textContent !== text) p.barSummary.textContent = text;
    if (p.live.textContent !== text) p.live.textContent = text;
    spRenderControls(p, search);
    spRenderNote(p, search);
    spRenderPairs(p, search);
    spRenderLists(p, search);
    spRenderSide(p, search);
    spRenderProvenance(p, search);
  }

  function spRenderControls(p, search) {
    var st = search?.settings || {};
    var active = spActive(search);
    p.face.disabled = !active || !search.faceable;
    if (st.lit && p.lit.value !== st.lit) p.lit.value = st.lit;
    spRangeValue({ input: p.k, out: p.kOut }, st.k, 0);
    p.distances.input.checked = !!st.distances;
    var offered = !!search?.reranker?.offered;
    spPlace(p.rerank.label, offered, p.distances.label);
    spPlace(p.cand.label, offered, p.distances.label);
    spPlace(p.top.label, offered, p.distances.label);
    p.rerank.input.checked = offered && !!st.rerank;
    spRangeValue(p.cand, st.candidates, 0);
    spRangeValue(p.top, st.top, st.candidates);
    // With the reranker on, Keep top decides how many results there are, not Results.
    var reranking = offered && !!st.rerank;
    p.k.disabled = reranking;
    p.k.title = reranking ? SP_K_RERANKED : "";
    p.only.input.checked = !!st.onlyResults;
    spShow(p.only.label, p.focus, "inline-flex");
    spRenderPov(p, search);
  }

  // The Reranker, Candidates and Keep top controls are in the row only when a reranker is
  // offered (absent, not hidden).
  function spPlace(label, present, before) {
    if (present && !label.parentNode && before.parentNode) before.parentNode.insertBefore(label, before);
    if (!present && label.parentNode) label.remove();
  }

  function spRenderPov(p, search) {
    var st = search?.settings || {};
    var list = spActive(search) ? search.searches : [];
    var key = list
      .map(function (q) {
        return q.letter + q.text;
      })
      .join("|");
    if (key !== p.povKey) {
      p.povKey = key;
      p.pov.textContent = "";
      p.pov.appendChild(spOption(p, "", "off"));
      list.forEach(function (q) {
        p.pov.appendChild(spOption(p, q.letter, q.letter + " · " + spShorten(q.text, 30)));
      });
    }
    p.pov.value = st.pointOfView || "";
    p.pov.disabled = !list.length;
  }

  function spRenderNote(p, search) {
    var parts = spNoteParts(search, { extraLines: p.extraLines, refusal: p.refusal, focus: p.focus });
    var text = parts.join(" ");
    if (p.note.textContent !== text) p.note.textContent = text;
  }

  function spRenderPairs(p, search) {
    p.pairs.textContent = "";
    if (!spActive(search) || !search.pairs?.length) return;
    var word = p.light ? "marked in dark ink" : "marked white";
    search.pairs.forEach(function (pair) {
      var line = spEl(p, "p", "tumbler-search-pair", { margin: "0", fontSize: "12px", lineHeight: "1.6" });
      var mark = spText(p, "span", "tumbler-search-shared-mark", "◆ ", { color: spSharedVar(p.light) });
      mark.setAttribute("aria-hidden", "true");
      line.appendChild(mark);
      line.appendChild(p.doc.createTextNode(spPairText(search, pair, word)));
      p.pairs.appendChild(line);
    });
  }

  // A key for what the lists show, so an unchanged update leaves them (and keyboard focus) alone.
  function spListKey(p, search) {
    if (!spActive(search)) return "none|" + p.focus;
    return JSON.stringify([
      p.focus,
      search.settings,
      search.stale,
      search.searches.map(function (q) {
        return [q.letter, q.text, q.reranker, q.pointOfView, q.insideCount, q.results];
      }),
    ]);
  }

  function spRenderLists(p, search) {
    var key = spListKey(p, search);
    if (key === p.listKey) return;
    p.listKey = key;
    spKeepOpen(p);
    p.results.textContent = "";
    spShow(p.results, !p.focus, "flex");
    if (!spActive(search)) return;
    var distances = !!search.settings?.distances;
    search.searches.forEach(function (q, j) {
      var box = spEl(p, "details", "tumbler-search-list", {});
      box.dataset.letter = q.letter;
      box.open = !!p.openLists[q.letter];
      var summary = spText(p, "summary", "", spListHeading(q), {
        cursor: "pointer",
        fontSize: "12px",
        letterSpacing: "0.04em",
        padding: "4px 0",
        color: spSearchVar(j, p.light),
      });
      box.appendChild(summary);
      box.appendChild(spResultList(p, q, j, distances, "grid"));
      p.results.appendChild(box);
    });
  }

  // Remember which result lists were open, from the details themselves (no listeners).
  function spKeepOpen(p) {
    for (var box of p.results.children) {
      var letter = box.dataset?.letter;
      if (letter) p.openLists[letter] = !!box.open;
    }
  }

  // One search's ordered list: rank, text, meta (and the gap bar with Distance difference on).
  function spResultList(p, q, j, distances, layout) {
    var pal = p.pal || SP_PALETTE_DARK;
    var ol = spEl(p, "ol", "tumbler-search-hits", spListStyle(layout));
    var widest = 1e-6;
    q.results.forEach(function (r) {
      widest = Math.max(widest, r.gap);
    });
    q.results.forEach(function (r) {
      ol.appendChild(spResultItem(p, q, j, r, { distances: distances, widest: widest, pal: pal, layout: layout }));
    });
    return ol;
  }

  function spListStyle(layout) {
    var base = { listStyle: "none", margin: "0", padding: "0" };
    if (layout === "grid") {
      // Up to 100 results: the list scrolls inside its own box, so the panel stays usable.
      return {
        ...base,
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))",
        gap: "6px 22px",
        maxHeight: "var(--tumbler-search-list-height, 320px)",
        overflowY: "auto",
      };
    }
    return { ...base, display: "flex", flexDirection: "column" };
  }

  function spResultItem(p, q, j, r, o) {
    var side = o.layout !== "grid";
    var li = spEl(p, "li", "tumbler-search-hit", {
      display: "grid",
      gridTemplateColumns: "26px minmax(0, 1fr)",
      gap: "2px 8px",
      alignItems: "baseline",
      minWidth: "0",
      borderBottom: "1px solid " + o.pal.line,
      padding: side ? "10px 16px" : "0 0 5px",
    });
    li.dataset.id = r.id;
    var rank = spText(p, "span", "tumbler-search-rank", (q.letter || "") + r.rank, {
      fontSize: "12px",
      color: spSearchVar(j, p.light),
      fontVariantNumeric: "tabular-nums",
    });
    li.appendChild(rank);
    li.appendChild(
      spText(p, "span", "tumbler-search-text", r.text, {
        fontFamily: side ? "var(--tumbler-font, inherit)" : "var(--tumbler-font-display, Georgia, serif)",
        fontSize: side ? "14px" : "19px",
        lineHeight: side ? "1.4" : "1.15",
        color: o.pal.fg,
        overflowWrap: "anywhere",
      })
    );
    var meta = spResultMeta(q, r, o.distances);
    if (meta.length) {
      li.appendChild(
        spText(p, "span", "tumbler-search-meta", meta.join(" · "), {
          gridColumn: "2",
          fontSize: "11px",
          fontVariantNumeric: "tabular-nums",
          color: o.pal.muted,
        })
      );
    }
    if (o.distances) li.appendChild(spGapBar(p, r.gap / o.widest, j, o.pal));
    return li;
  }

  function spGapBar(p, share, j, pal) {
    var bar = spEl(p, "span", "tumbler-search-gap", {
      gridColumn: "2",
      display: "block",
      height: "3px",
      position: "relative",
      background: pal.line,
      marginTop: "2px",
    });
    bar.setAttribute("aria-hidden", "true");
    var fill = spEl(p, "span", "", {
      position: "absolute",
      left: "0",
      top: "0",
      bottom: "0",
      width: (100 * Math.min(1, Math.max(0, share))).toFixed(1) + "%",
      background: spSearchVar(j, p.light),
    });
    bar.appendChild(fill);
    return bar;
  }

  // The Search row of the provenance list and the clause in its summary; put back after the
  // viewer re-renders the block (it does on every update of the data).
  function spRenderProvenance(p, search) {
    var active = spActive(search);
    var list = p.parts.provenanceList;
    var sum = p.parts.provenanceSummary;
    if (!p.provDt) {
      // The viewer's own rows' look (js/src/50-viewer.js, provRow).
      p.provDt = spText(p, "dt", "tumbler-provenance-term tumbler-search-provenance-term", "Search", { margin: "0" });
      p.provDd = spText(p, "dd", "tumbler-provenance-value tumbler-search-provenance-value", "", { margin: "0", minWidth: "0" });
      p.provClause = spText(p, "span", "tumbler-search-provenance-clause", "");
    }
    p.provDt.style.color = p.pal.muted;
    p.provDd.style.color = p.pal.fg;
    var used = usedText(search);
    if (p.provDd.textContent !== used) p.provDd.textContent = used;
    var clause = spProvenanceClause(search);
    if (p.provClause.textContent !== clause) p.provClause.textContent = clause;
    spAttach(list, [p.provDt, p.provDd], active);
    spAttach(sum, [p.provClause], active);
  }

  function spAttach(parent, nodes, on) {
    if (!parent) return;
    nodes.forEach(function (n) {
      if (on && n.parentNode !== parent) parent.appendChild(n);
      if (!on && n.parentNode) n.remove();
    });
  }

  // ----- Focus: the ranked lists beside the stage -----

  function spFreshSearch(p) {
    try {
      return typeof p.handle.info === "function" ? p.handle.info().search : null;
    } catch {
      // A handle whose info() throws: keep the snapshot the panel has.
      return null;
    }
  }

  function spSetFocus(p, focus) {
    if (focus === p.focus) return;
    p.focus = focus;
    // What a search reports depends on the view (whether it can be faced), so the kept
    // snapshot is read again; otherwise Face the searches keeps the other view's state.
    if (p.search) p.search = spFreshSearch(p) || p.search;
    var root = p.parts.stage.parentNode;
    if (focus) {
      if (!p.side) p.side = spBuildSide(p);
      p.rootDisplay = root.style.display;
      spStyle(root, { display: "flex", flexWrap: "wrap", alignItems: "flex-start", columnGap: "var(--tumbler-search-side-gap, 16px)" });
      spStyle(p.parts.stage, { flex: "999 1 600px", minWidth: "0" });
      p.parts.panel.style.flex = "1 1 100%";
      p.parts.stage.after(p.side);
      p.side.style.maxHeight = p.parts.stage.style.height || "";
    } else {
      p.side?.remove();
      spStyle(root, { display: p.rootDisplay || "block", flexWrap: "", alignItems: "", columnGap: "" });
      spStyle(p.parts.stage, { flex: "", minWidth: "" });
      p.parts.panel.style.flex = "";
    }
    p.listKey = null;
    p.sideKey = null;
    if (p.pal) spRender(p);
  }

  function spBuildSide(p) {
    var pal = p.pal || SP_PALETTE_DARK;
    var side = spEl(p, "aside", "tumbler-search-side", {
      flex: "1 1 340px",
      minWidth: "0",
      boxSizing: "border-box",
      overflowY: "auto",
      border: "1px solid " + pal.line,
      background: pal.bg,
      color: pal.muted,
      fontFamily: "var(--tumbler-font-data, inherit)",
    });
    side.setAttribute("aria-label", "Search results");
    return side;
  }

  function spRenderSide(p, search) {
    if (!p.focus || !p.side) return;
    var key = spListKey(p, search);
    if (key === p.sideKey) return;
    p.sideKey = key;
    var pal = p.pal || SP_PALETTE_DARK;
    var side = p.side;
    side.textContent = "";
    side.style.borderColor = pal.line;
    side.style.background = pal.bg;
    var head = spEl(p, "div", "tumbler-search-side-head", { padding: "14px 16px 10px", borderBottom: "1px solid " + pal.line });
    var active = spActive(search);
    head.appendChild(
      spText(p, "p", "tumbler-search-side-title", active ? "Nearest texts" : "No search", {
        margin: "0",
        fontFamily: "var(--tumbler-font-display, Georgia, serif)",
        fontStyle: "italic",
        fontSize: "26px",
        lineHeight: "1.1",
        color: pal.fg,
      })
    );
    head.appendChild(spText(p, "p", "tumbler-search-side-sub", spSideSub(search), { margin: "4px 0 0", fontSize: "12px" }));
    side.appendChild(head);
    if (!active) {
      side.appendChild(
        spText(
          p,
          "p",
          "tumbler-search-side-empty",
          "Nothing searched: every point is shown. Open Search below the view and type, or click a point to search from it.",
          { margin: "0", padding: "16px", fontSize: "14px" }
        )
      );
      return;
    }
    var distances = !!search.settings?.distances;
    search.searches.forEach(function (q, j) {
      side.appendChild(
        spText(p, "p", "tumbler-search-side-letter", q.letter + " · " + q.text, {
          margin: "0",
          padding: "10px 16px 4px",
          fontSize: "12px",
          letterSpacing: "0.04em",
          color: spSearchVar(j, p.light),
        })
      );
      side.appendChild(spResultList(p, q, j, distances, "column"));
    });
  }

  function spSideSub(search) {
    if (!spActive(search)) return "every point is shown";
    var q = search.searches[0];
    var parts = search.searches.map(function (s) {
      var how = s.pointOfView ? "from its point of view" : "plain distance";
      return s.letter + ": " + s.results.length + " named results, " + how + (s.reranker ? ", then the reranker (" + spKeptOf(s) + ")" : "");
    });
    return (search.searches.length === 1 ? parts[0].slice(q.letter.length + 2) : parts.join("; ")) + " · " + search.measure;
  }

  // ----- the overlay: query rings, links, labels over the stage -----

  function spLabelLayer(p) {
    if (p.labelLayer) return p.labelLayer;
    var layer = spEl(p, "div", "tumbler-search-labels", {
      position: "absolute",
      left: "0",
      top: "0",
      right: "0",
      bottom: "0",
      overflow: "hidden",
      pointerEvents: "none",
      zIndex: "1",
    });
    layer.setAttribute("aria-hidden", "true");
    var overlay = p.parts.overlay;
    if (overlay?.parentNode === p.parts.stage) overlay.after(layer);
    else p.parts.stage.appendChild(layer);
    p.labelLayer = layer;
    return layer;
  }

  function spLabelAt(p, used, str, x, y, style) {
    if (used >= SP_LABEL_POOL) return used;
    var rec = p.labels[used];
    if (!rec) {
      rec = { el: spEl(p, "span", "tumbler-search-label", { position: "absolute", left: "0", top: "0", whiteSpace: "nowrap", fontSize: "11px", fontFamily: "var(--tumbler-font-data, monospace)" }), text: null, colour: null, shown: true };
      spLabelLayer(p).appendChild(rec.el);
      p.labels.push(rec);
    }
    if (rec.text !== str) {
      rec.el.textContent = str;
      rec.text = str;
    }
    if (rec.colour !== style.colour) {
      rec.el.style.color = style.colour;
      rec.el.style.textShadow = p.outline;
      rec.colour = style.colour;
    }
    rec.el.style.transform = "translate(" + x.toFixed(1) + "px, " + y.toFixed(1) + "px) translate(" + (style.centre ? "-50%" : "0") + ", -50%)";
    rec.el.style.opacity = String(Math.round(style.alpha * 100) / 100);
    if (!rec.shown) {
      rec.el.style.display = "";
      rec.shown = true;
    }
    return used + 1;
  }

  function spHideLabels(p, from) {
    for (var i = from; i < p.labels.length; i++) {
      if (p.labels[i].shown) {
        p.labels[i].el.style.display = "none";
        p.labels[i].shown = false;
      }
    }
  }

  // A label is placed only where it overlaps none already placed (the honest, simple answer
  // to a tight cluster: the list carries everything the stage leaves out).
  function spFits(boxes, x, y, text, centre) {
    var w = text.length * SP_CHAR_W + 4;
    var left = centre ? x - w / 2 : x;
    var box = { l: left, r: left + w, t: y - SP_LABEL_H / 2, b: y + SP_LABEL_H / 2 };
    for (var o of boxes) {
      if (box.l < o.r && box.r > o.l && box.t < o.b && box.b > o.t) return false;
    }
    boxes.push(box);
    return true;
  }

  function spOutline(bg) {
    var ring = [[1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [-0.7, 0.7], [0.7, -0.7], [-0.7, -0.7]];
    return ring
      .map(function (d) {
        return (d[0] * 1.5).toFixed(2) + "px " + (d[1] * 1.5).toFixed(2) + "px 0.5px " + bg;
      })
      .join(", ");
  }

  function spPointVector(set, index) {
    var D = set.dimension;
    return set.vectors.subarray(index * D, index * D + D);
  }

  function spFinite(pt) {
    return !!pt && Number.isFinite(pt.x) && Number.isFinite(pt.y);
  }

  // Draw one search: links from its query to its results, then its ring and letter. Labels are
  // queued in `queue` so they can be placed letters first, then nearest results first.
  function spDrawSearch(p, ctx, j, qp, q, view) {
    var dpr = view.dpr;
    var colour = p.colours[j];
    var n = q.results.length;
    ctx.lineWidth = dpr;
    ctx.strokeStyle = colour;
    q.results.forEach(function (r, i) {
      if (view.hidden(r.index)) return;
      var rp = view.project(spPointVector(view.set, r.index));
      if (!spFinite(rp)) return;
      var rel = n > 1 ? 1 - i / (n - 1) : 1;
      ctx.globalAlpha = view.filter * (0.25 + 0.4 * rel);
      ctx.beginPath();
      ctx.moveTo(qp.x, qp.y);
      ctx.lineTo(rp.x, rp.y);
      ctx.stroke();
      view.queue.push({ q: q, j: j, r: r, rp: rp, qp: qp });
    });
    ctx.globalAlpha = view.filter;
    ctx.lineWidth = 1.5 * dpr;
    ctx.beginPath();
    ctx.arc(qp.x, qp.y, 10 * dpr, 0, Math.PI * 2);
    ctx.stroke();
    if (view.focus) {
      ctx.beginPath();
      ctx.moveTo(qp.x - 4 * dpr, qp.y);
      ctx.lineTo(qp.x + 4 * dpr, qp.y);
      ctx.moveTo(qp.x, qp.y - 4 * dpr);
      ctx.lineTo(qp.x, qp.y + 4 * dpr);
      ctx.stroke();
    }
  }

  // Place the labels: each query's letter, then every result's rank (Focus) or text (the
  // other views, when labels are on), then each link's distance with Distance difference on.
  function spPlaceLabels(p, view, letters) {
    var boxes = [];
    var used = 0;
    var dpr = view.dpr;
    letters.forEach(function (l) {
      var x = l.qp.x / dpr + 15;
      var y = l.qp.y / dpr + 4; // the reference's place, clear of a result label above it
      spFits(boxes, l.qp.x / dpr - 11, y, "   ", false);
      if (spFits(boxes, x, y, l.text, false)) used = spLabelAt(p, used, l.text, x, y, { colour: p.colours[l.j], alpha: view.filter });
    });
    var many = letters.length > 1;
    var order = view.queue.slice().sort(function (a, b) {
      return a.r.rank - b.r.rank || a.j - b.j;
    });
    // Stop once every label element is used: with 400 results the rest would only be tested.
    for (var it of order) {
      if (used >= SP_LABEL_POOL) break;
      used = spPlaceResult(p, view, boxes, used, it, many);
    }
    if (view.distances) {
      for (var link of order) {
        if (used >= SP_LABEL_POOL) break;
        used = spPlaceDistance(p, view, boxes, used, link);
      }
    }
    spHideLabels(p, used);
  }

  function spPlaceResult(p, view, boxes, used, it, many) {
    var text = null;
    if (view.focus) text = (many ? it.q.letter : "") + it.r.rank;
    else if (view.labels) text = spShorten(it.r.text, SP_STAGE_TEXT);
    if (!text) return used;
    var x = it.rp.x / view.dpr + 8;
    var y = it.rp.y / view.dpr - 8;
    if (!spFits(boxes, x, y, text, false)) return used;
    var colour = view.focus ? p.colours[it.j] : p.pal.fg;
    return spLabelAt(p, used, text, x, y, { colour: colour, alpha: view.filter });
  }

  function spPlaceDistance(p, view, boxes, used, it) {
    var share = view.focus ? 0.72 : 0.62;
    var x = (it.qp.x + (it.rp.x - it.qp.x) * share) / view.dpr;
    var y = (it.qp.y + (it.rp.y - it.qp.y) * share) / view.dpr + 11;
    var text = it.r.distance.toFixed(3);
    if (!spFits(boxes, x, y, text, true)) return used;
    return spLabelAt(p, used, text, x, y, { colour: p.pal.muted, alpha: view.filter * 0.9, centre: true });
  }

  // The viewer tells the panel about searches, not about data: a new or appended set (which
  // changes what is offered, such as the Reranker, and the suggestions) is noticed here.
  function spDataChanged(p, set) {
    var count = set ? set.count : -1;
    if (set === p.dataRef && count === p.dataCount) return;
    p.dataRef = set;
    p.dataCount = count;
    try {
      if (typeof p.handle.info === "function") spUpdate(p, p.handle.info().search);
    } catch {
      // A handle whose info throws: keep what is shown.
    }
  }

  // The text outline follows the stage's background (labels restyle on their next use).
  function spRefreshOutline(p) {
    if (p.outlineBg === p.pal.bg) return;
    p.outline = spOutline(p.pal.bg);
    p.outlineBg = p.pal.bg;
    p.labels.forEach(function (rec) {
      rec.colour = null;
    });
  }

  function spNever() {
    return false;
  }

  // What one frame's drawing needs, from the viewer's frame argument.
  function spView(p, f, set, project, filter) {
    return {
      set: set,
      project: project,
      dpr: Number(f.dpr) > 0 ? Number(f.dpr) : 1,
      filter: Math.min(1, filter),
      labels: f.labels !== false,
      focus: p.focus,
      distances: !!p.search.settings?.distances,
      hidden: typeof f.hidden === "function" ? f.hidden : spNever,
      queue: [],
    };
  }

  function spDrawOverlay(p, ctx, project, frame) {
    var f = frame || {};
    var set = spData(p);
    spDataChanged(p, set);
    if (f.mode) spSetFocus(p, f.mode === "focus");
    spRenderProvenance(p, p.search);
    var search = p.search;
    var filter = Number(f.filter);
    var shown = filter > 0.05; // false for NaN too
    if (!spActive(search) || !set || !Array.isArray(f.queries) || !shown) {
      spHideLabels(p, 0);
      return false;
    }
    if (!p.colours) p.colours = spCanvasColours(p, ctx);
    spRefreshOutline(p);
    var view = spView(p, f, set, project, filter);
    var letters = [];
    ctx.save?.();
    search.searches.forEach(function (q, j) {
      var vec = f.queries[j];
      if (!vec || vec.length !== set.dimension) return;
      var qp = project(vec);
      if (!spFinite(qp)) return;
      spDrawSearch(p, ctx, j, qp, q, view);
      letters.push({ qp: qp, j: j, text: view.focus ? q.letter + " query" : q.letter });
    });
    ctx.globalAlpha = 1;
    ctx.restore?.();
    spPlaceLabels(p, view, letters);
    return true;
  }

  // ----- update and mount -----

  function spUpdate(p, search) {
    if (p.destroyed) return;
    p.search = search || null;
    var theme = spTheme(p);
    if (theme !== p.themeRef) {
      p.themeRef = theme;
      spApplyTheme(p);
    }
    var mode = spMode(p);
    if (mode) spSetFocus(p, mode === "focus");
    spSyncInput(p, p.search);
    spRender(p);
  }

  function spMode(p) {
    try {
      return typeof p.handle.mode === "function" ? p.handle.mode() : null;
    } catch {
      // A handle whose mode() throws: keep the layout as it is.
      return null;
    }
  }

  function spDestroy(p) {
    if (p.destroyed) return;
    p.destroyed = true;
    if (p.timer && p.win?.clearTimeout) p.win.clearTimeout(p.timer);
    p.timer = 0;
    p.listeners.forEach(function (l) {
      l[0].removeEventListener(l[1], l[2]);
    });
    p.listeners = [];
    spSetFocus(p, false);
    p.section.remove();
    p.labelLayer?.remove();
    p.provDt?.remove();
    p.provDd?.remove();
    p.provClause?.remove();
    p.labels = [];
  }

  function mount(parts, handle, options) {
    var opts = options || {};
    var doc = opts.document || parts.panel.ownerDocument;
    spCounter += 1;
    var p = {
      n: spCounter,
      doc: doc,
      win: doc.defaultView || null,
      parts: parts,
      handle: handle,
      opts: opts,
      bodyId: "tumbler-search-body-" + spCounter,
      search: null,
      open: false,
      focus: false,
      openLists: Object.create(null),
      timer: 0,
      lastSent: "",
      refusal: null,
      extraLines: 0,
      suggested: [],
      suggestCache: { set: null, count: -1, entries: [] },
      listeners: [],
      labels: [],
      labelLayer: null,
      colours: null,
      outline: "",
      outlineBg: null,
      listKey: null,
      sideKey: null,
      povKey: null,
      themeRef: undefined,
      dataRef: undefined,
      dataCount: -2,
      destroyed: false,
    };
    spBuild(p);
    p.themeRef = spTheme(p);
    spApplyTheme(p);
    var first = null;
    try {
      first = typeof handle.info === "function" ? handle.info().search : null;
    } catch {
      // No info yet: the panel starts with nothing searched.
      first = null;
    }
    spUpdate(p, first);
    return {
      update: function (search) {
        spUpdate(p, search);
      },
      drawOverlay: function (ctx, project, frame) {
        if (p.destroyed) return false;
        return spDrawOverlay(p, ctx, project, frame);
      },
      destroy: function () {
        spDestroy(p);
      },
      setOpen: function (open) {
        spSetOpen(p, !!open);
      },
      isOpen: function () {
        return p.open;
      },
    };
  }

  ET.searchPanel = {
    mount: mount,
    summaryText: summaryText,
    usedText: usedText,
    suggest: spSuggest,
    noteText: function (search, ctx) {
      return spNoteParts(search, ctx || {}).join(" ");
    },
    pairText: spPairText,
    resultMeta: spResultMeta,
    thousands: spThousands,
    COLOURS: { dark: SP_DARK.slice(), light: SP_LIGHT.slice(), sharedDark: SP_SHARED_DARK, sharedLight: SP_SHARED_LIGHT },
  };
// ---------------------------------------------------------------------------
// 50-viewer.js: the public viewer API (task t8).
//
//   EmbeddingsTumbler.mount(el, options)  -> handle
//   EmbeddingsTumbler.update(el, data)    -> result   (also handle.update(data))
//   EmbeddingsTumbler.destroy(el)         -> boolean  (also handle.destroy())
//
// The viewer owns the DOM inside the host's element, the renderer, the clock, the
// active mode, labels, controls, the readout strip and the provenance block. It
// validates data with ET.contract, draws with ET.renderer and moves with ET.modes.
//
// Rules this module keeps (see js/api/50-viewer.md):
//   * It changes nothing outside the given element: one child element is appended
//     to it and removed again by destroy. No global style, no class on the page,
//     no global variable. Listeners on the document (visibility) and window
//     (resize, only without ResizeObserver) are removed by destroy.
//   * Every style is set through element.style from script, never through a style
//     attribute or a style element, so a strict style-src policy allows it.
//   * Text from data goes in with textContent only. Nothing parses markup.
//   * It makes no network request of any kind and builds no resource address.
//   * Bad data never throws into the host: the refusal is shown inside the element
//     and returned to the caller.
//   * No frame work runs while the document is hidden or the element is off
//     screen: the animation loop is not scheduled at all then.
// ---------------------------------------------------------------------------
ET.viewer = (function () {
  var TAU = Math.PI * 2;

  // The reference's look. Group hues are the reference's, in its region order;
  // groups take them in order of first appearance in the data.
  var GROUP_HUES = [28, 52, 96, 140, 170, 198, 226, 266, 328, 4, 298];
  var MAX_GROUP_PROPS = 24; // --tumbler-group-1 .. --tumbler-group-24
  var DARK = {
    background: "#04060b",
    sky: "#0b1430",
    foreground: "#e9eef6",
    muted: "#8a96ab",
    line: "#1b2436",
    accent: "#ffc56b",
    ungrouped: "#8cadff",
  };
  var LIGHT = {
    background: "#f6f4ee",
    sky: "#ffffff",
    foreground: "#1b2130",
    muted: "#5b6578",
    line: "#d6dae2",
    accent: "#a35f00",
    ungrouped: "#8cadff",
  };
  // The readout strip's three axis colours (horizontal, vertical, depth), 0-255. Fixed, not
  // themable. The light pair is darker so cells and legend words read on a light panel.
  var AXIS_RGB_DARK = [[255, 150, 60], [80, 220, 160], [130, 140, 255]];
  var AXIS_RGB_LIGHT = [[176, 84, 0], [0, 128, 82], [72, 82, 214]];
  var AXIS_NAMES = ["horizontal", "vertical", "depth"];
  var FONTS = {
    body: 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
    data: 'ui-monospace, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace',
    display: '"Iowan Old Style", "Palatino Linotype", Palatino, Georgia, serif',
  };
  var STAGE_HEIGHT = "clamp(300px, 62vh, 860px)";

  var DEFAULT_OPTIONS = {
    mode: "tumble",
    seed: 1,
    speed: 1,
    paused: null, // null: follow prefers-reduced-motion
    labels: true,
    trails: true,
    controls: true,
    readout: true,
    masthead: true,
    title: "",
    provenanceOpen: true,
    modeOptions: null, // { tumble: {...}, ... } passed to ET.modes.create
    maxPixelRatio: 2,
    preserveDrawingBuffer: false,
    prepareBudgetMs: 8,
    // Keep the slow spin running while a mode prepares, so the view never looks frozen
    // (owner's phone report, 2026-11-14). false: hold the picture still until ready, as 0.11.6.
    spinWhilePreparing: true,
    // Lower the drawing-buffer ratio in steps (never below 1) when the frame rate stays
    // under ADAPT_FPS while nothing prepares. false: always draw at the capped device ratio.
    adaptivePixelRatio: false, // off until the owner decides: it trades sharpness for frame rate
    refitQuietSeconds: 2,
    refitShare: 0.01,
    onError: null,
    onModeChange: null,
    onPauseChange: null,
    // Search (docs/search-interface.md, "Viewer (t8)").
    embed: null, // the host's embed(text) callback
    rerank: null, // the host's rerank(query, candidates) callback
    searchTimeoutMs: 15000,
    searchPanel: true,
    searchK: 8,
    searchCandidates: 50, // candidates handed to the reranker (3 to 100)
    searchTop: 20, // reranked candidates kept (3 to searchCandidates)
    searchLit: "even",
    onSearchChange: null,
  };

  var CROWD_REF = 600; // bright points a view shows at full brightness (see crowding)
  var CROWD_POWER = 1;
  var BRIGHT_WEIGHT = 0.7; // a point painted at this weight or more counts toward the light load
  var LABEL_SAMPLE = 300; // labelled points projected on the CPU per frame for labels
  var LABEL_POOL = 64; // label elements at most
  var STATUS_EVERY = 0.12; // seconds between status-line updates (the reference's)
  var ZOOM_MIN = 0.2;
  var ZOOM_MAX = 12;
  var SPIN = 0.06; // rad/s of yaw while running (the reference's)
  // Heavy work's budget per frame (see "Heavy work" in js/api/50-viewer.md): a share of the
  // measured frame interval, between prepareBudgetMs and BUDGET_CEILING times it; cut to half
  // of prepareBudgetMs for one frame only when the work itself overran (a unit far longer
  // than asked: cold code, a collection): more than OVERRUN_FLOOR_MS, and more than
  // OVERRUN_MS past the budget it had.
  var WORK_SHARE = 1 / 3;
  var BUDGET_CEILING = 3;
  var OVERRUN_FLOOR_MS = 16;
  var OVERRUN_MS = 8;
  var PAUSED_BUDGET_MS = 40; // a paused view has no motion to keep smooth
  var INTERVAL_GAP_MS = 250; // a longer gap between frames is a pause, not a frame interval
  // Drawing-buffer ratio steps (adaptivePixelRatio): ADAPT_SECONDS measured seconds in a row
  // under ADAPT_FPS, while running and not preparing, lower it by ADAPT_STEP (never below 1).
  var ADAPT_FPS = 25; // under a 30 fps cap (iOS Low Power Mode), never below a measured 29.x
  var ADAPT_SECONDS = 2;
  var ADAPT_STEP = 0.5;
  // The most wire light per pixel, where the wires' light lands, before the wires are
  // scaled down (the renderer's draw key wireLoad; see "Crowded wires" in js/api/50-viewer.md).
  var WIRE_LOAD = 8;
  var BUTTON_HEIGHT = "28px"; // the reference's Pause button
  var TOUCH_HEIGHT = "32px"; // the same buttons under 600 px wide
  // Spacing and sizes a host may adjust: each is set inline as var(--tumbler-<name>,
  // <default>), so a host stylesheet sets the custom property (no !important needed) and,
  // with none set, the browser uses the viewer's own value. The browser resolves var()
  // live, so these are never read into the theme. Two have a narrow value below 600 px
  // (layoutForWidth); a host's property wins at every width. Documented in js/api/50-viewer.md.
  var PANEL_PADDING = { wide: "6px 16px 16px", narrow: "6px 12px 14px" };
  var MODE_TITLE_SIZE = { wide: "24px", narrow: "20px" };
  function spaced(name, fallback) {
    return "var(--tumbler-" + name + ", " + fallback + ")";
  }
  // Names over the sky: the reference strokes each name with a 4 px line of the
  // background at 0.85 under the fill. As page text that is a ring of hard
  // shadows: 8 at 1.5 px (slightly soft) and 8 at 2 px (half strength), which
  // came closest to the reference's canvas stroke in Chromium (measured against
  // it) and needs nothing beyond text-shadow, so every browser draws it.
  var OUTLINE_RING = (function () {
    var out = [];
    for (var k = 0; k < 8; k++) {
      var th = (Math.PI * 2 * k) / 8;
      out.push([Math.cos(th), Math.sin(th)]);
    }
    return out;
  })();
  var SHADOW =
    "A projection is a shadow of the space, not the space: each view shows three " +
    "linear directions out of all of them, so points that look close may be far apart " +
    "and points that look apart may be close.";

  // Registry of live viewers, keyed by element. Nothing else is shared between viewers.
  var live = typeof WeakMap === "function" ? new WeakMap() : null;
  var liveList = []; // fallback when WeakMap is missing: [{ el, v }]

  function lookup(el) {
    if (!el || typeof el !== "object") return null;
    if (live) return live.get(el) || null;
    for (var rec of liveList) if (rec.el === el) return rec.v;
    return null;
  }
  function remember(el, v) {
    if (live) live.set(el, v);
    else liveList.push({ el: el, v: v });
  }
  function forget(el) {
    if (live) live.delete(el);
    else liveList = liveList.filter(function (r) {
      return r.el !== el;
    });
  }

  // ---------- small pure helpers ----------

  function clamp(x, lo, hi) {
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
  }

  function hsl(h, s, l) {
    function f(n) {
      var k = (n + h / 30) % 12;
      return l - s * Math.min(l, 1 - l) * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    }
    return [f(0), f(8), f(4)];
  }

  function hashUnit(i) {
    var x = Math.abs(Math.sin(i * 12.9898) * 43758.5453);
    return x - Math.floor(x);
  }

  function thousands(n) {
    var s = String(Math.round(n));
    var neg = s.startsWith("-");
    if (neg) s = s.slice(1);
    var out = "";
    while (s.length > 3) {
      out = "," + s.slice(-3) + out;
      s = s.slice(0, -3);
    }
    return (neg ? "-" : "") + s + out;
  }

  function percent(x, digits) {
    return (x * 100).toFixed(digits === undefined ? 1 : digits) + "%";
  }

  function shorten(text, max) {
    var s = String(text);
    return s.length > max ? s.slice(0, max - 1) + "…" : s;
  }

  // Parse a CSS colour into [r, g, b] (0..1). Hex, rgb()/rgba() and hsl()/hsla() in
  // comma or space syntax. Returns null for anything else.
  function parseColour(str) {
    if (typeof str !== "string") return null;
    var s = str.trim().toLowerCase();
    if (!s) return null;
    var m = /^#([0-9a-f]{3,8})$/.exec(s);
    if (m) {
      var h = m[1];
      if (h.length === 3 || h.length === 4) {
        return [0, 1, 2].map(function (i) {
          return Number.parseInt(h.charAt(i) + h.charAt(i), 16) / 255;
        });
      }
      if (h.length === 6 || h.length === 8) {
        return [0, 2, 4].map(function (i) {
          return Number.parseInt(h.slice(i, i + 2), 16) / 255;
        });
      }
      return null;
    }
    m = /^(rgba?|hsla?)\(([^)]*)\)$/.exec(s);
    if (!m) return null;
    var parts = m[2].split(/[\s,/]+/).filter(function (p) {
      return p !== "";
    });
    if (parts.length < 3) return null;
    function num(p, scale) {
      var pct = p.endsWith("%");
      var x = Number.parseFloat(p);
      if (!Number.isFinite(x)) return Number.NaN;
      return pct ? x / 100 : x / scale;
    }
    if (m[1].startsWith("r")) {
      var rgb = [num(parts[0], 255), num(parts[1], 255), num(parts[2], 255)];
      if (rgb.some(Number.isNaN)) return null;
      return rgb.map(function (c) {
        return clamp(c, 0, 1);
      });
    }
    var hue = Number.parseFloat(parts[0]);
    var sat = num(parts[1], 100);
    var lig = num(parts[2], 100);
    if (!Number.isFinite(hue) || Number.isNaN(sat) || Number.isNaN(lig)) return null;
    return hsl(((hue % 360) + 360) % 360, clamp(sat, 0, 1), clamp(lig, 0, 1));
  }

  function cssRgb(c, alpha) {
    var r = Math.round(clamp(c[0], 0, 1) * 255);
    var g = Math.round(clamp(c[1], 0, 1) * 255);
    var b = Math.round(clamp(c[2], 0, 1) * 255);
    if (alpha === undefined || alpha >= 1) return "rgb(" + r + ", " + g + ", " + b + ")";
    return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
  }

  function mix(a, b, t) {
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  }

  function luminance(c) {
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }

  // A value the host may put in a font or length property. Anything that could name
  // a resource is refused (only plain names, numbers and length functions pass).
  function safeCssValue(s) {
    if (typeof s !== "string") return "";
    var t = s.trim();
    if (!t || t.length > 300) return "";
    if (/url\s*\x28|image-set|\\|[;{}<>]/i.test(t)) return "";
    return t;
  }

  function setStyles(el, styles) {
    var st = el.style;
    for (var k in styles) {
      if (Object.hasOwn(styles, k)) st[k] = styles[k];
    }
  }

  function readOption(options, key) {
    if (options && Object.hasOwn(options, key) && options[key] !== undefined) {
      return options[key];
    }
    return DEFAULT_OPTIONS[key];
  }

  function isElement(el) {
    return (
      !!el &&
      typeof el === "object" &&
      el.nodeType === 1 &&
      typeof el.appendChild === "function" &&
      !!el.ownerDocument
    );
  }

  function call(v, fn, arg) {
    if (typeof fn !== "function") return;
    try {
      fn(arg);
    } catch (err) {
      reportHostError(v, err);
    }
  }

  // A host callback's own error is the host's: rethrow it on a later task, outside the
  // viewer's stack, so the host's error handling sees it and the viewer keeps running.
  // Without setTimeout, a microtask; without that, console.error. Never dropped.
  function reportHostError(v, err) {
    var w = v.win || {};
    var rethrow = function () {
      throw err;
    };
    if (typeof w.setTimeout === "function") w.setTimeout(rethrow, 0);
    else if (typeof w.queueMicrotask === "function") w.queueMicrotask(rethrow);
    else {
      var c = w.console || (typeof console !== "undefined" ? console : null);
      if (typeof c?.error === "function") c.error("embeddings-tumbler: a host callback threw", err);
    }
  }

  // ---------- DOM building ----------

  function make(v, tag, cls, styles) {
    var el = v.doc.createElement(tag);
    if (cls) el.className = cls;
    if (styles) setStyles(el, styles);
    return el;
  }

  function text(v, tag, cls, str, styles) {
    var el = make(v, tag, cls, styles);
    el.textContent = str;
    return el;
  }

  function pillButton(v, cls, label) {
    var b = text(v, "button", cls, label, {
      fontFamily: "inherit",
      fontSize: "12px",
      lineHeight: "1.15",
      color: "inherit",
      background: "transparent",
      border: "1px solid",
      borderRadius: "999px",
      // The reference's .ctl button: 6 px by 16 px padding, at least 76 px wide,
      // 28 px tall at 12 px type. Under 600 px wide layoutForWidth raises the
      // height to TOUCH_HEIGHT for fingers.
      padding: "6px 16px",
      minHeight: BUTTON_HEIGHT,
      minWidth: "76px",
      cursor: "pointer",
      margin: "0",
    });
    b.type = "button";
    return b;
  }

  function build(v) {
    var root = make(v, "div", "tumbler", {
      position: "relative",
      display: "block",
      width: "100%",
      boxSizing: "border-box",
      margin: "0",
      padding: "0",
      textAlign: "left",
      fontSize: "14px",
      lineHeight: "1.5",
      overflowWrap: "break-word",
    });
    root.tabIndex = 0;
    root.setAttribute("role", "group");
    root.setAttribute("aria-label", "Embedding space viewer");
    root.setAttribute("aria-roledescription", "embedding space viewer");
    v.root = root;

    var stage = make(v, "div", "tumbler-stage", {
      position: "relative",
      width: "100%",
      overflow: "hidden",
      touchAction: "pan-y",
      cursor: "grab",
      isolation: "isolate",
      userSelect: "none",
      webkitUserSelect: "none",
    });
    v.stage = stage;
    var full = { position: "absolute", left: "0", top: "0", width: "100%", height: "100%", display: "block" };
    var gl = make(v, "canvas", "tumbler-canvas", full);
    gl.setAttribute("role", "img");
    gl.setAttribute("aria-label", "Animated 3-D projection of an embedding space (no data yet)");
    v.canvas = gl;
    var overlay = make(v, "canvas", "tumbler-overlay", full);
    overlay.setAttribute("aria-hidden", "true");
    overlay.style.pointerEvents = "none";
    v.overlay = overlay;
    var labels = make(v, "div", "tumbler-labels", {
      position: "absolute",
      left: "0",
      top: "0",
      right: "0",
      bottom: "0",
      overflow: "hidden",
      pointerEvents: "none",
    });
    labels.setAttribute("aria-hidden", "true");
    v.labelLayer = labels;

    var mast = make(v, "div", "tumbler-masthead", {
      position: "absolute",
      top: spaced("masthead-top", "14px"),
      left: spaced("masthead-left", "16px"),
      right: spaced("masthead-right", "16px"),
      pointerEvents: "none",
      zIndex: "2",
    });
    v.mastTitle = text(v, "p", "tumbler-title", "", {
      margin: spaced("title-margin", "0 0 6px"),
      fontStyle: "italic",
      fontWeight: "400",
      fontSize: spaced("title-size", "clamp(28px, 6vw, 56px)"),
      lineHeight: "0.95",
    });
    v.mastLine = text(v, "p", "tumbler-subtitle", "", {
      margin: "0",
      fontSize: "12px",
      letterSpacing: "0.06em",
      textTransform: "uppercase",
    });
    mast.appendChild(v.mastTitle);
    mast.appendChild(v.mastLine);
    v.masthead = mast;

    var status = text(v, "p", "tumbler-status", "waiting for data", {
      position: "absolute",
      left: spaced("status-left", "16px"),
      right: spaced("status-right", "16px"),
      bottom: spaced("status-bottom", "10px"),
      margin: "0",
      fontSize: "12px",
      lineHeight: "1.4",
      pointerEvents: "none",
      zIndex: "2",
      whiteSpace: "normal",
      fontVariantNumeric: "tabular-nums",
    });
    status.setAttribute("aria-live", "off");
    v.status = status;

    var fatal = make(v, "div", "tumbler-message", {
      position: "absolute",
      left: "0",
      top: "0",
      right: "0",
      bottom: "0",
      display: "none",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px",
      textAlign: "center",
      zIndex: "4",
      boxSizing: "border-box",
    });
    fatal.setAttribute("role", "alert");
    v.fatalText = text(v, "p", "tumbler-message-text", "", { margin: "0", maxWidth: "52ch" });
    fatal.appendChild(v.fatalText);
    v.fatal = fatal;

    var notice = make(v, "div", "tumbler-notice", {
      position: "absolute",
      left: "12px",
      right: "12px",
      top: "12px",
      display: "none",
      alignItems: "flex-start",
      gap: "10px",
      padding: "8px 10px 8px 12px",
      fontSize: "12px",
      lineHeight: "1.45",
      border: "1px solid",
      borderRadius: "6px",
      zIndex: "3",
      boxSizing: "border-box",
    });
    notice.setAttribute("role", "alert");
    v.noticeText = text(v, "p", "tumbler-notice-text", "", { margin: "0", flex: "1 1 auto", minWidth: "0" });
    var dismiss = pillButton(v, "tumbler-notice-dismiss", "Dismiss");
    dismiss.style.flex = "0 0 auto";
    dismiss.style.minWidth = "0";
    dismiss.style.padding = "2px 10px";
    dismiss.style.minHeight = "24px";
    notice.appendChild(v.noticeText);
    notice.appendChild(dismiss);
    v.notice = notice;
    v.noticeDismiss = dismiss;

    stage.appendChild(gl);
    stage.appendChild(overlay);
    stage.appendChild(labels);
    stage.appendChild(mast);
    stage.appendChild(status);
    stage.appendChild(notice);
    stage.appendChild(fatal);
    var empty = text(v, "p", "tumbler-empty", "No data yet. Call update(data) to show a set of embeddings.", {
      position: "absolute",
      left: "16px",
      right: "16px",
      top: "50%",
      margin: "0",
      transform: "translateY(-50%)",
      textAlign: "center",
      fontSize: "13px",
      pointerEvents: "none",
      zIndex: "2",
    });
    stage.appendChild(empty);
    v.empty = empty;
    root.appendChild(stage);

    var panel = make(v, "div", "tumbler-panel", {
      display: "flex",
      flexDirection: "column",
      gap: spaced("panel-gap", "14px"),
      padding: spaced("panel-padding", PANEL_PADDING.wide),
    });
    v.panel = panel;

    // Mode switch: one button per registered mode.
    var nav = make(v, "div", "tumbler-modes", { display: "grid", gap: "0", borderTop: "1px solid" });
    nav.setAttribute("role", "group");
    nav.setAttribute("aria-label", "View");
    v.modeNav = nav;
    v.modeButtons = [];
    var defs = ET.modes.list();
    nav.style.gridTemplateColumns = "repeat(" + Math.max(1, defs.length) + ", minmax(0, 1fr))";
    defs.forEach(function (def, i) {
      var b = make(v, "button", "tumbler-mode", {
        font: "inherit",
        textAlign: "left",
        background: "transparent",
        border: "0",
        borderTop: "2px solid transparent",
        marginTop: "-1px",
        padding: spaced("mode-padding", "10px 12px 8px 0"),
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        gap: "2px",
        minWidth: "0",
        minHeight: "44px",
        color: "inherit",
      });
      b.type = "button";
      b.setAttribute("aria-pressed", "false");
      b.dataset.mode = def.id;
      b.setAttribute("aria-keyshortcuts", i < 9 ? String(i + 1) : "");
      var title = text(v, "b", "tumbler-mode-title", def.title, {
        fontWeight: "400",
        fontSize: spaced("mode-title-size", MODE_TITLE_SIZE.wide),
        lineHeight: "1.1",
      });
      var summary = text(v, "span", "tumbler-mode-summary", def.summary || "", {
        fontSize: spaced("mode-summary-size", "12.5px"),
        lineHeight: "1.35",
      });
      b.appendChild(title);
      b.appendChild(summary);
      nav.appendChild(b);
      v.modeButtons.push({ id: def.id, button: b, title: title, summary: summary });
    });
    panel.appendChild(nav);

    // Readout strip: one cell per dimension of the current frame.
    var readout = make(v, "div", "tumbler-readout", { display: "flex", flexDirection: "column", gap: "6px" });
    // The reference's strip: 22 px of cells between a 1 px line above and below
    // (24 px in all), whatever box-sizing the host page sets.
    var strip = make(v, "canvas", "tumbler-strip", {
      width: "100%",
      height: "22px",
      boxSizing: "content-box",
      display: "block",
      imageRendering: "pixelated",
      borderTop: "1px solid",
      borderBottom: "1px solid",
    });
    strip.width = 1;
    strip.height = 1;
    strip.setAttribute("aria-hidden", "true");
    v.strip = strip;
    var caption = make(v, "p", "tumbler-readout-caption", {
      display: "flex",
      justifyContent: "space-between",
      gap: "4px 12px",
      flexWrap: "wrap",
      margin: "0",
      fontSize: spaced("readout-caption-size", "11.5px"),
    });
    v.stripFirst = text(v, "span", "", "dimension 1");
    v.stripMiddle = make(v, "span", "");
    v.stripText = text(v, "span", "", "how much each dimension contributes to the view right now");
    v.stripMiddle.appendChild(v.stripText);
    v.stripMiddle.appendChild(v.doc.createTextNode(" \u00b7 colour: "));
    v.stripLegend = AXIS_NAMES.map(function (name, i) {
      var word = text(v, "b", "tumbler-axis-" + name, name, { fontWeight: "400" });
      if (i > 0) v.stripMiddle.appendChild(v.doc.createTextNode(" "));
      v.stripMiddle.appendChild(word);
      return word;
    });
    v.stripLast = text(v, "span", "", "");
    caption.appendChild(v.stripFirst);
    caption.appendChild(v.stripMiddle);
    caption.appendChild(v.stripLast);
    readout.appendChild(strip);
    readout.appendChild(caption);
    v.readout = readout;
    panel.appendChild(readout);

    // Controls.
    var ctl = make(v, "div", "tumbler-controls", {
      display: "flex",
      flexWrap: "wrap",
      alignItems: "center",
      gap: spaced("controls-gap", "10px 18px"),
      fontSize: "12px",
    });
    v.playButton = pillButton(v, "tumbler-play", "Pause");
    v.zoomResetButton = pillButton(v, "tumbler-zoom-reset", "Reset zoom");
    var speedLabel = make(v, "label", "tumbler-speed", { display: "inline-flex", alignItems: "center", gap: "8px" });
    speedLabel.appendChild(text(v, "span", "", "Speed"));
    var speed = make(v, "input", "", { width: "130px" });
    speed.type = "range";
    speed.min = "0.2";
    speed.max = "3";
    speed.step = "0.1";
    speed.value = String(v.speed);
    speed.setAttribute("aria-label", "Speed");
    speedLabel.appendChild(speed);
    v.speedInput = speed;
    function checkbox(cls, label, checked) {
      var l = make(v, "label", cls, { display: "inline-flex", alignItems: "center", gap: "6px" });
      var c = make(v, "input", "", { width: "15px", height: "15px", margin: "0" });
      c.type = "checkbox";
      c.checked = !!checked;
      l.appendChild(c);
      l.appendChild(text(v, "span", "", label));
      return { label: l, input: c };
    }
    var lab = checkbox("tumbler-labels-toggle", "Labels", v.showLabels);
    var trl = checkbox("tumbler-trails-toggle", "Trails", v.trails);
    v.labelsInput = lab.input;
    v.trailsInput = trl.input;
    var hint = text(
      v,
      "span",
      "tumbler-hint",
      "Drag to turn. Pinch, or Ctrl + wheel, to zoom; double-click or double-tap resets. Keys 1-" +
        Math.max(1, Math.min(9, defs.length)) +
        " switch views while the viewer has focus."
    );
    ctl.appendChild(v.playButton);
    ctl.appendChild(v.zoomResetButton);
    ctl.appendChild(speedLabel);
    ctl.appendChild(lab.label);
    ctl.appendChild(trl.label);
    ctl.appendChild(hint);
    v.controlsEl = ctl;
    v.hint = hint;
    panel.appendChild(ctl);

    // Provenance.
    var prov = make(v, "details", "tumbler-provenance", { borderTop: "1px solid", paddingTop: "10px", fontSize: "12px" });
    prov.open = !!v.options.provenanceOpen;
    var summ = text(v, "summary", "tumbler-provenance-summary", "About this view", { cursor: "pointer" });
    var dl = make(v, "dl", "tumbler-provenance-list", {
      display: "grid",
      gridTemplateColumns: "max-content minmax(0, 1fr)",
      gap: "4px 14px",
      margin: "8px 0 0",
    });
    var shadow = text(v, "p", "tumbler-shadow", SHADOW, { margin: "10px 0 0", fontStyle: "italic", maxWidth: "92ch" });
    prov.appendChild(summ);
    prov.appendChild(dl);
    prov.appendChild(shadow);
    v.provenance = prov;
    v.provSummary = summ;
    v.provList = dl;
    v.provShadow = shadow;
    panel.appendChild(prov);

    root.appendChild(panel);

    if (!v.options.controls) ctl.style.display = "none";
    if (!v.options.readout) readout.style.display = "none";
    if (!v.options.masthead) mast.style.display = "none";
    return root;
  }

  // ---------- theme ----------

  function readTheme(v) {
    var cs = null;
    try {
      cs = typeof v.win?.getComputedStyle === "function" ? v.win.getComputedStyle(v.root) : null;
    } catch (err) {
      // A host whose getComputedStyle throws gets the built-in theme.
      cs = null;
    }
    function raw(name) {
      if (typeof cs?.getPropertyValue !== "function") return "";
      var s = cs.getPropertyValue(name);
      return typeof s === "string" ? s.trim() : "";
    }
    function colour(name) {
      var s = raw(name);
      if (!s) return null;
      var c = parseColour(s);
      if (c) return c;
      return probeColour(v, s);
    }
    var bg = colour("--tumbler-background");
    var light = bg ? luminance(bg) > 0.5 : false;
    var base = light ? LIGHT : DARK;
    var t = {
      light: light,
      background: bg || parseColour(base.background),
      sky: colour("--tumbler-sky") || parseColour(base.sky),
      foreground: colour("--tumbler-foreground") || parseColour(base.foreground),
      muted: colour("--tumbler-muted") || parseColour(base.muted),
      line: colour("--tumbler-line") || parseColour(base.line),
      accent: colour("--tumbler-accent") || parseColour(base.accent),
      ungrouped: colour("--tumbler-ungrouped") || parseColour(base.ungrouped),
      font: safeCssValue(raw("--tumbler-font")) || FONTS.body,
      fontData: safeCssValue(raw("--tumbler-font-data")) || FONTS.data,
      fontDisplay: safeCssValue(raw("--tumbler-font-display")) || FONTS.display,
      stageHeight: safeCssValue(raw("--tumbler-stage-height")) || STAGE_HEIGHT,
      groups: [],
    };
    for (var i = 0; i < MAX_GROUP_PROPS; i++) {
      t.groups.push(colour("--tumbler-group-" + (i + 1)));
    }
    return t;
  }

  // Resolve a named or otherwise unparsed colour through the browser: set it on a
  // hidden probe inside the viewer and read the computed value.
  function probeColour(v, s) {
    if (!v.root || typeof v.win?.getComputedStyle !== "function") return null;
    var probe = null;
    try {
      probe = v.doc.createElement("span");
      probe.style.display = "none";
      probe.style.color = s;
      v.root.appendChild(probe);
      var c = parseColour(String(v.win.getComputedStyle(probe).color || ""));
      return c;
    } catch {
      // A colour the browser cannot resolve is no colour: the caller falls back to the default.
      return null;
    } finally {
      probe?.remove();
    }
  }

  function groupColour(v, index) {
    if (index < 0) return v.theme.ungrouped;
    if (index < MAX_GROUP_PROPS && v.theme.groups[index]) return v.theme.groups[index];
    if (index < GROUP_HUES.length) return hsl(GROUP_HUES[index], 0.9, 0.62);
    // Past the reference's hues: golden-angle steps, same saturation and lightness.
    return hsl((GROUP_HUES.at(-1) + 137.508 * (index - GROUP_HUES.length + 1)) % 360, 0.9, 0.62);
  }

  function applyTheme(v) {
    var t = v.theme;
    var fg = cssRgb(t.foreground);
    var muted = cssRgb(t.muted);
    var line = cssRgb(t.line);
    var accent = cssRgb(t.accent);
    var bg = cssRgb(t.background);
    setStyles(v.root, { color: fg, background: bg, fontFamily: t.font });
    var mid = mix(t.sky, t.background, 0.55);
    v.stage.style.height = t.stageHeight;
    v.stage.style.background =
      "radial-gradient(ellipse 75% 70% at 50% 46%, " +
      cssRgb(t.sky) +
      " 0%, " +
      cssRgb(mid) +
      " 48%, " +
      bg +
      " 82%)";
    // The renderer draws light on black. On a dark stage it is screened over the sky.
    // On a light stage the points are uploaded in complementary colours and the canvas
    // is inverted and multiplied: each group comes out as ink of its own hue, laid on
    // at 70% opacity (soft ink: lighter, the hues kept).
    if (t.light) {
      v.canvas.style.filter = "invert(1)";
      v.canvas.style.mixBlendMode = "multiply";
      v.canvas.style.opacity = "0.7";
    } else {
      v.canvas.style.filter = "none";
      v.canvas.style.mixBlendMode = "screen";
      v.canvas.style.opacity = "1";
    }
    v.mastTitle.style.fontFamily = t.fontDisplay;
    v.mastTitle.style.color = fg;
    v.mastTitle.style.textShadow = "0 0 28px " + cssRgb(t.background, 0.9);
    v.mastLine.style.fontFamily = t.fontData;
    v.mastLine.style.color = muted;
    v.mastLine.style.textShadow = "0 0 12px " + bg;
    setStyles(v.status, { fontFamily: t.fontData, color: accent, textShadow: "0 0 8px " + bg });
    setStyles(v.fatal, { color: fg, background: cssRgb(t.background, 0.82), fontFamily: t.font });
    setStyles(v.empty, { color: muted, fontFamily: t.fontData });
    setStyles(v.notice, { color: fg, background: cssRgb(t.background, 0.92), borderColor: accent, fontFamily: t.fontData });
    v.noticeDismiss.style.borderColor = line;
    v.noticeDismiss.style.color = fg;
    v.modeNav.style.borderTopColor = line;
    v.modeButtons.forEach(function (mb) {
      mb.title.style.fontFamily = t.fontDisplay;
      mb.summary.style.color = muted;
      mb.button.style.color = muted;
    });
    paintModeButtons(v);
    v.strip.style.borderTopColor = line;
    v.strip.style.borderBottomColor = line;
    v.readout.style.fontFamily = t.fontData;
    v.readout.lastChild.style.color = muted;
    v.readout.lastChild.style.fontFamily = t.fontData;
    setStyles(v.controlsEl, { fontFamily: t.fontData, color: muted });
    [v.playButton, v.zoomResetButton].forEach(function (b) {
      b.style.borderColor = line;
      b.style.color = fg;
      b.style.fontFamily = t.fontData;
    });
    v.speedInput.style.accentColor = accent;
    v.labelsInput.style.accentColor = accent;
    v.trailsInput.style.accentColor = accent;
    setStyles(v.provenance, { borderTopColor: line, fontFamily: t.fontData, color: muted });
    v.provSummary.style.color = fg;
    v.provShadow.style.color = fg;
    v.provShadow.style.fontFamily = t.font;
    // Label elements re-style on their next use.
    v.labelPool.forEach(function (rec) {
      rec.key = "";
    });
    v.outline = outlineShadow(t.background);
    v.stageFg = fg;
    // The reference's Wander names: the stop in white, its neighbours #c5cddb (the
    // foreground three-eighths of the way to the muted colour). On a light stage the
    // stop takes the foreground, so it stays dark ink.
    v.stopColour = t.light ? fg : "rgb(255, 255, 255)";
    v.neighbourColour = cssRgb(mix(t.foreground, t.muted, 0.375));
    v.axisRgb = t.light ? AXIS_RGB_LIGHT : AXIS_RGB_DARK;
    v.stripLegend.forEach(function (word, i) {
      word.style.color = "rgb(" + v.axisRgb[i].join(", ") + ")";
    });
  }

  // Read the host's theme and, only when it differs from the one applied, apply it
  // and clear the trails (drawn in the old colours). An update or a refreshTheme()
  // with the theme unchanged leaves the trails, label styles and colours alone.
  // Returns true when the theme changed.
  function syncTheme(v) {
    var t = readTheme(v);
    var key = JSON.stringify(t);
    if (key === v.themeKey) return false;
    v.theme = t;
    v.themeKey = key;
    applyTheme(v);
    v.needClear = true;
    return true;
  }

  // The dark outline under every name, in the stage's background colour.
  function outlineShadow(bg) {
    var strong = cssRgb(bg, 0.85);
    var half = cssRgb(bg, 0.5);
    var parts = [];
    OUTLINE_RING.forEach(function (d) {
      parts.push(px(d[0] * 1.5) + " " + px(d[1] * 1.5) + " 0.5px " + strong);
    });
    OUTLINE_RING.forEach(function (d) {
      parts.push(px(d[0] * 2) + " " + px(d[1] * 2) + " 0 " + half);
    });
    return parts.join(", ");
  }
  function px(x) {
    var r = Math.round(x * 100) / 100;
    return (r === 0 ? 0 : r) + "px";
  }

  // A group's colour for names, the ring and the spokes on a dark stage: the
  // reference draws them at 72% lightness where the points are at 62%, so the
  // lightness is raised by the same share of the way to white (hue and
  // saturation kept). Exact for the reference's hues; the same lift for a host's.
  function nameTint(c) {
    var r = c[0];
    var g = c[1];
    var b = c[2];
    var hi = Math.max(r, g, b);
    var lo = Math.min(r, g, b);
    var l = (hi + lo) / 2;
    var h = 0;
    var s = 0;
    if (hi - lo > 1e-9) {
      var d = hi - lo;
      s = d / (1 - Math.abs(2 * l - 1));
      if (hi === r) h = 60 * (((g - b) / d) % 6);
      else if (hi === g) h = 60 * ((b - r) / d + 2);
      else h = 60 * ((r - g) / d + 4);
      if (h < 0) h += 360;
    }
    var l2 = l + (1 - l) * (0.1 / 0.38);
    return hsl(h, clamp(s, 0, 1), clamp(l2, 0, 1));
  }

  function paintModeButtons(v) {
    var current = v.modeId;
    var accent = cssRgb(v.theme.accent);
    var fg = cssRgb(v.theme.foreground);
    v.modeButtons.forEach(function (mb) {
      var on = mb.id === current;
      mb.button.setAttribute("aria-pressed", on ? "true" : "false");
      mb.button.style.borderTopColor = on ? accent : "transparent";
      mb.title.style.color = on ? accent : fg;
      mb.title.style.opacity = on ? "1" : "0.6";
      mb.title.style.fontStyle = on ? "italic" : "normal";
    });
  }

  function refreshTheme(v) {
    if (v.destroyed) return;
    syncTheme(v);
    if (v.set && paintKey(v) !== v.paintKey) recolour(v);
    invalidate(v);
  }

  // What the uploaded point colours depend on; a change means a re-upload.
  function paintKey(v) {
    var t = v.theme;
    return JSON.stringify([t.light, t.ungrouped, t.groups]);
  }

  // ---------- point colours and weights ----------

  function groupIndexOf(v, group) {
    if (typeof group !== "string" || group === "") return -1;
    if (Object.hasOwn(v.groupIndex, group)) return v.groupIndex[group];
    var i = v.groupNames.length;
    v.groupIndex[group] = i;
    v.groupNames.push(group);
    return i;
  }

  // Colours and weights for points [from, to) of the set. Labelled points are full
  // weight and brightened as in the reference; unlabelled points get a small steady
  // weight from their index. When no point is labelled at all (a labels-only set
  // whose labels are its ids), every point gets a middle weight so the view is not
  // all dust.
  // Also returns `bright`: the sum of the weights of the bright points painted (weight
  // BRIGHT_WEIGHT or more), which crowding() reads as the light load.
  function paint(v, set, from, to) {
    var n = to - from;
    var colours = new Float32Array(n * 3);
    var weights = new Float32Array(n);
    var bright = 0;
    var isLabelled = ET.modes.isLabelled;
    for (var i = from; i < to; i++) {
      var p = set.points[i];
      var g = groupIndexOf(v, p.group);
      var c = groupColour(v, g);
      var labelled = isLabelled(p);
      var h = hashUnit(i);
      var w;
      if (labelled) {
        w = 1;
        c = [0.45 + 0.55 * c[0], 0.45 + 0.55 * c[1], 0.45 + 0.55 * c[2]];
      } else if (v.labelledCount === 0) w = 0.7;
      else if (g < 0) w = 0.05 + 0.2 * h * h;
      else w = 0.1 + 0.55 * h * h * h;
      if (v.theme.light) c = inkUpload(c, labelled);
      var o = (i - from) * 3;
      colours[o] = c[0];
      colours[o + 1] = c[1];
      colours[o + 2] = c[2];
      weights[i - from] = w;
      if (w >= BRIGHT_WEIGHT) bright += w;
    }
    return { colours: colours, weights: weights, bright: bright };
  }

  // Coloured ink: the hue fully saturated and darkened (labelled points a little
  // darker), uploaded as its complement; the canvas's invert(1) turns the additive
  // image back into that ink, multiplied onto the light sky.
  function inkUpload(c, labelled) {
    var lo = Math.min(c[0], c[1], c[2]);
    var hi = Math.max(c[0], c[1], c[2]);
    var span = hi - lo > 1e-6 ? hi - lo : 1;
    var k = labelled ? 0.78 : 0.88;
    var out = [0, 0, 0];
    for (var j = 0; j < 3; j++) {
      var sat = hi - lo > 1e-6 ? (c[j] - lo) / span : 0.5;
      var ink = k * (0.7 * sat + 0.3 * c[j]);
      out[j] = 1 - ink;
    }
    return out;
  }

  function countLabelled(set, from, to) {
    var n = 0;
    for (var i = from; i < to; i++) if (ET.modes.isLabelled(set.points[i])) n++;
    return n;
  }

  // Labelled points projected per frame for labels and hover (at most LABEL_SAMPLE).
  function extendLabelSample(v, set, from) {
    for (var i = from; i < set.count && v.labelSample.length < LABEL_SAMPLE; i++) {
      if (v.labelledCount === 0 || ET.modes.isLabelled(set.points[i])) v.labelSample.push(i);
    }
  }

  function recolour(v) {
    // Re-upload everything with the theme's palette (a theme change). Rare.
    var set = v.set;
    if (!set || !v.renderer || set.count === 0) return;
    var pc = paint(v, set, 0, set.count);
    var res = v.renderer.setData({ vectors: set.vectors, dimension: set.dimension, colours: pc.colours, weights: pc.weights });
    v.lightLoad = pc.bright;
    if (res?.ok === false) fatal(v, res.message);
    if (v.mode) v.mode.wiresVersion = -1;
    v.paintKey = paintKey(v);
  }

  // ---------- messages ----------

  // A message over the whole stage. kind "gpu" (no WebGL, lost for good, too many
  // points) or "data" (a refusal while the view holds no set).
  function fatal(v, message, kind) {
    v.fatalKind = kind || "gpu";
    v.fatalMessage = String(message);
    v.fatalText.textContent = v.fatalMessage;
    v.fatal.style.display = "flex";
    if (v.empty) v.empty.style.display = "none";
  }
  function clearFatal(v) {
    v.fatalKind = null;
    v.fatalMessage = null;
    if (v.empty && !v.set) v.empty.style.display = "";
    v.fatalText.textContent = "";
    v.fatal.style.display = "none";
  }
  function notify(v, message) {
    v.noticeMessage = String(message);
    v.noticeText.textContent = v.noticeMessage;
    v.notice.style.display = "flex";
  }
  function clearNotice(v) {
    v.noticeMessage = null;
    v.noticeText.textContent = "";
    v.notice.style.display = "none";
  }

  // ---------- provenance ----------

  function provRow(v, term, value) {
    var dt = text(v, "dt", "tumbler-provenance-term", term, { margin: "0", color: cssRgb(v.theme.muted) });
    var dd = make(v, "dd", "tumbler-provenance-value", { margin: "0", color: cssRgb(v.theme.foreground), minWidth: "0" });
    if (Array.isArray(value)) {
      var ul = make(v, "ul", "", { margin: "0", paddingLeft: "18px" });
      value.forEach(function (item) {
        ul.appendChild(text(v, "li", "", String(item)));
      });
      dd.appendChild(ul);
    } else {
      dd.textContent = String(value);
    }
    v.provList.appendChild(dt);
    v.provList.appendChild(dd);
    return dd;
  }

  function reductionText(r) {
    if (!r || r.kind === "none") return "none: the vectors are as the model produced them";
    if (r.kind === "rotation") {
      return "exact rotation onto the data's principal directions; nothing lost, distances unchanged";
    }
    if (r.kind === "top-k") {
      return (
        "top-k: " +
        thousands(r.directions_kept) +
        " of " +
        thousands(r.source_dimension) +
        " directions kept, " +
        percent(r.variance_dropped) +
        " of the variance dropped; this view is an approximation of the space"
      );
    }
    return String(r.kind);
  }

  function viewText(v) {
    var m = v.mode;
    if (!m) {
      var def = ET.modes.get(v.modeId);
      return (def ? def.title : v.modeId) + " (starts when data arrives)";
    }
    var d = {};
    try {
      d = m.inst.describe() || {};
    } catch (err) {
      // A mode whose describe() throws is shown as a plain linear projection.
      d = {};
    }
    var out = m.title + ": " + (d.projection || "a linear projection");
    if (typeof d.varianceShare === "number" && Number.isFinite(d.varianceShare)) {
      out +=
        "; the directions it tours through hold " +
        percent(d.varianceShare) +
        " of the variance" +
        (d.varianceShareStale ? " (measured before " + thousands(d.pointsSinceFit || 0) + " new points)" : "");
    }
    return out;
  }

  function renderProvenance(v) {
    var list = v.provList;
    list.replaceChildren();
    v.provView = null;
    var set = v.set;
    if (!set) {
      provRow(v, "Data", "none yet");
      v.provView = provRow(v, "View", viewText(v));
      provRow(v, "Seed (view)", String(v.seed));
      v.provSummary.textContent = "About this view: no data yet. " + "A projection is a shadow of the space.";
      return;
    }
    var p = set.provenance || {};
    var r = set.reduction;
    provRow(v, "Source", p.source);
    if (p.synthetic) provRow(v, "Synthetic", "yes: these vectors were generated, not produced by the named model");
    provRow(v, "Model", set.model);
    var dim = thousands(set.dimension);
    if (r?.kind === "top-k") dim += " (reduced from " + thousands(r.source_dimension) + ")";
    provRow(v, "Dimension", dim);
    provRow(v, "Items", thousands(set.count));
    provRow(v, "Seed (view)", String(v.seed));
    provRow(v, "Seed (source)", p.seed === null || p.seed === undefined ? "none" : String(p.seed));
    v.provView = provRow(v, "View", viewText(v));
    provRow(v, "Reduction", reductionText(r));
    provRow(v, "Producer", p.producer);
    if (p.endpoint) provRow(v, "Embedded through", p.endpoint);
    if (p.created) provRow(v, "Created", p.created);
    provRow(
      v,
      "Labels",
      set.text_included
        ? "may carry corpus text from the source"
        : "point ids only: this data carries no corpus text"
    );
    var lim = Array.isArray(p.limitations) ? p.limitations : [];
    var unc = Array.isArray(p.uncertain) ? p.uncertain : [];
    provRow(v, "Limitations", lim.length ? lim : "none known (the producer states none)");
    provRow(v, "Uncertain", unc.length ? unc : "nothing flagged (the producer states none)");
    v.provSummary.textContent =
      "About this view: " +
      p.source +
      " · " +
      set.model +
      " · " +
      dim +
      "-d · " +
      thousands(set.count) +
      " items · seed " +
      String(v.seed) +
      (p.synthetic ? " · synthetic" : "") +
      " · a projection is a shadow of the space";
    v.provViewText = v.provView.textContent;
  }

  function refreshViewRow(v) {
    if (!v.provView) return;
    var t = viewText(v);
    if (t !== v.provViewText) {
      v.provView.textContent = t;
      v.provViewText = t;
    }
  }

  function describeSet(v) {
    var set = v.set;
    // With no data the stage says so plainly; the provenance and readout have
    // nothing to describe and are hidden.
    v.empty.style.display = set || v.fatalMessage ? "none" : "";
    v.provenance.style.display = set ? "" : "none";
    v.readout.style.display = set && v.options.readout ? "flex" : "none";
    if (!set) {
      v.canvas.setAttribute("aria-label", "Animated 3-D projection of an embedding space (no data yet)");
      v.mastLine.textContent = "";
      v.stripLast.textContent = "";
      return;
    }
    var D = set.dimension;
    v.canvas.setAttribute(
      "aria-label",
      "Animated 3-D linear projection of a " +
        thousands(D) +
        "-dimensional embedding space: " +
        thousands(set.count) +
        " points from " +
        set.model +
        ". The provenance below says where they came from."
    );
    v.mastTitle.textContent = v.options.title ? String(v.options.title) : "";
    v.mastTitle.style.display = v.options.title ? "" : "none";
    v.mastLine.textContent =
      thousands(set.count) + " embeddings · " + thousands(D) + " dimensions · one restless 3-D window";
    v.stripLast.textContent = "dimension " + thousands(D);
    v.stripText.textContent = "how much each of the " + thousands(D) + " dimensions contributes to the view right now";
  }

  // ---------- modes ----------

  function copyState(s) {
    if (!s) return null;
    var draw = {};
    for (var k in s.draw) if (Object.hasOwn(s.draw, k)) draw[k] = s.draw[k];
    return { frame: new Float32Array(s.frame), centre: new Float32Array(s.centre), draw: draw };
  }

  // Options for a mode instance: the viewer's defaults (none today), then the host's
  // modeOptions. Tumble's refit turns onto the new tour over its own
  // refitTransition ("auto": sized to the turn); mode entry keeps the mode's 1.5 s.
  var MODE_DEFAULTS = Object.create(null);
  function modeOptionsFor(v, id) {
    var out = {};
    var k;
    var d = MODE_DEFAULTS[id];
    if (d) for (k in d) if (Object.hasOwn(d, k)) out[k] = d[k];
    var mo = v.options.modeOptions;
    var host = mo && Object.hasOwn(mo, id) ? mo[id] : null;
    if (host && typeof host === "object") {
      for (k in host) if (Object.hasOwn(host, k)) out[k] = host[k];
    }
    return out;
  }

  // Start mode `id` on the current set. Returns true, or false after showing why not.
  function errorText(err, fallback) {
    return err?.message ? String(err.message) : fallback;
  }

  // Start mode `id` on the current set. Returns true, or false after showing why not
  // (v.modeError holds the message). Every call into the mode is guarded: a mode is
  // pluggable host code and may throw. The previous instance is left only once the
  // new one has entered and prepared.
  function startMode(v, id, from) {
    var def = ET.modes.get(id);
    v.modeError = null;
    if (!def) {
      v.modeError = 'There is no view called "' + String(id) + '".';
      notify(v, v.modeError);
      return false;
    }
    if (!v.set) {
      v.modeId = id;
      paintModeButtons(v);
      return true;
    }
    var inst = null;
    var prep;
    try {
      inst = ET.modes.create(id, modeOptionsFor(v, id));
      inst.enter(v.set, { seed: v.seed, from: from || null });
      prep = inst.prepare();
      if (typeof prep?.step !== "function") throw new TypeError(def.title + ": prepare() returned no stepper");
    } catch (err) {
      v.modeError = errorText(err, "This view cannot show the data.");
      notify(v, v.modeError);
      leaveSafely(inst);
      return false;
    }
    if (v.mode) leaveSafely(v.mode.inst);
    v.mode = {
      id: id,
      title: def.title,
      inst: inst,
      jobs: [prep],
      clock: 0,
      seeked: false, // seek() was called: hold the spin until ready (spinWhilePreparing)
      wiresVersion: -1,
      refit: null,
      readyAt: null,
      lastFocusTo: -1,
      prevNeighbours: null,
      curNeighbours: null,
    };
    v.modeId = id;
    paintModeButtons(v);
    refreshViewRow(v);
    v.statusClock = STATUS_EVERY;
    return true;
  }

  function leaveSafely(inst) {
    if (!inst) return;
    try {
      inst.leave();
    } catch (err) {
      // a mode's leave() has nothing the viewer needs
    }
  }

  function readyOf(m) {
    try {
      return !!m?.inst.isReady();
    } catch (err) {
      // A mode whose isReady() throws is not ready.
      return false;
    }
  }

  // A frame threw: the loop stops and a notice says so; a replace or a mode switch
  // that succeeds starts it again.
  function recover(v) {
    if (!v.broken) return;
    v.broken = false;
    if (v.noticeMessage?.startsWith("The viewer stopped")) clearNotice(v);
    v.prev = null;
    invalidate(v);
  }

  function setMode(v, id) {
    if (v.destroyed) return false;
    if (typeof id !== "string") return false;
    if (v.mode?.id === id) return true;
    if (!v.set && ET.modes.get(id)) {
      v.modeId = id;
      paintModeButtons(v);
      refreshViewRow(v);
      call(v, v.options.onModeChange, id);
      return true;
    }
    var ok = startMode(v, id, copyState(v.last));
    if (ok) {
      if (v.search.shown.length) notifyModeSearch(v);
      recover(v);
      call(v, v.options.onModeChange, id);
      invalidate(v);
    }
    return ok;
  }

  // ---------- data ----------

  function update(v, data) {
    if (v.destroyed) return { ok: false, code: "destroyed", message: "This viewer has been destroyed." };
    var began = now(v);
    try {
      return applyUpdate(v, data);
    } finally {
      // A long update (a large upload) is the viewer's own work too: the next frame
      // counts the gap as lost time, as after a long frame.
      // Anything over about one frame (20 ms) would show as a skipped step.
      if (now(v) - began > 20) v.lostTime = true;
    }
  }

  function validateSafely(v, data) {
    try {
      return ET.contract.validate(data, v.set);
    } catch (err) {
      // The loader never throws for bad data (a hostile getter is its own
      // invalid-field refusal), so anything caught here is a fault, not the data's.
      return { ok: false, code: "internal", message: "Internal error while checking the data: " + errorText(err, String(err)) };
    }
  }

  // "append" or "replace": what the data asks for. A getter that throws means replace.
  function opOf(data) {
    try {
      return data.op === "append" ? "append" : "replace";
    } catch (err) {
      // A throwing op getter: the data is shown as a replace.
      return "replace";
    }
  }

  function applyOp(v, op, set) {
    try {
      return op === "append" ? applyAppend(v, set) : applyReplace(v, set);
    } catch (err) {
      // Nothing in the application path should throw; if it does, it is reported, the
      // loop is left to the frame guard, and the host gets a result.
      return { ok: false, code: "internal", message: "Internal error while showing the data: " + errorText(err, String(err)) };
    }
  }

  function applyUpdate(v, data) {
    var res = validateSafely(v, data);
    // Re-read the host's theme on every update (no polling); applied only if changed.
    syncTheme(v);
    if (v.set && paintKey(v) !== v.paintKey) recolour(v);
    if (!res?.ok) {
      return refuse(v, { ok: false, code: res ? res.code : "internal", message: res ? res.message : "Data refused." });
    }
    var op = opOf(data);
    clearNotice(v); // an older notice; a fallback view or a refusal sets its own
    var out = applyOp(v, op, res.set);
    if (!out.ok) return refuse(v, out);
    if (v.fatalKind === "data") clearFatal(v);
    if (v.fatalKind === "gpu" && v.rendering) clearFatal(v);
    if (op === "replace") recover(v);
    invalidate(v);
    return out;
  }

  function strip(r) {
    return { ok: false, code: r.code, message: r.message };
  }

  // A refusal: nothing changed. Shown inside the element, passed to onError, returned.
  function refuse(v, r) {
    var refusal = strip(r);
    // With a view showing (or a graphics message up), the refusal is a notice and the
    // view keeps running unchanged; with nothing to show it fills the stage.
    if (v.set || v.fatalKind === "gpu") notify(v, refusal.message);
    else fatal(v, refusal.message, "data");
    call(v, v.options.onError, refusal);
    invalidate(v);
    return refusal;
  }

  // What a failed update restores.
  function snapshot(v) {
    var gi = Object.create(null); // group names are untrusted: no inherited names
    for (var k in v.groupIndex) gi[k] = v.groupIndex[k];
    return {
      set: v.set,
      groupIndex: gi,
      groupNames: v.groupNames.slice(),
      labelledCount: v.labelledCount,
      lightLoad: v.lightLoad,
      labelSample: v.labelSample.slice(),
      last: v.last,
      spin: v.spin,
      drag: v.drag,
      sinceAppend: v.sinceAppend,
    };
  }

  function restore(v, snap) {
    v.set = snap.set;
    v.groupIndex = snap.groupIndex;
    v.groupNames = snap.groupNames;
    v.labelledCount = snap.labelledCount;
    v.lightLoad = snap.lightLoad;
    v.labelSample = snap.labelSample;
    v.last = snap.last;
    v.spin = snap.spin;
    v.drag = snap.drag;
    v.sinceAppend = snap.sinceAppend;
    restoreRenderer(v);
    sizeStrip(v);
    describeSet(v);
    renderProvenance(v);
  }

  // Put the renderer's copy back to the set the view holds (after a failed upload or
  // a refused update), rebuilding the GPU objects if a failure dropped them.
  function restoreRenderer(v) {
    var r = v.renderer;
    if (!r) return;
    try {
      var set = v.set;
      if (set) {
        var pc = paint(v, set, 0, set.count);
        r.setData({ vectors: set.vectors, dimension: set.dimension, colours: pc.colours, weights: pc.weights });
        v.lightLoad = pc.bright;
      } else {
        v.lightLoad = 0;
        var D = r.status().dimension || 1;
        r.setData({ vectors: new Float32Array(0), dimension: D });
      }
      var st = r.status();
      if (!st.ok && !st.lost && !st.disposed) {
        var rb = r.rebuild();
        if (!rb?.ok) fatal(v, rb?.message || "The graphics card could not take the data back.");
      }
      if (v.mode) v.mode.wiresVersion = -1;
      if (v.search.litUploaded) uploadLit(v); // setData cleared the lit values
      v.paintKey = paintKey(v);
      v.needClear = true;
    } catch (err) {
      fatal(v, "The graphics card could not take the data back: " + errorText(err, String(err)));
    }
  }

  function gpuThrew(err) {
    return { ok: false, code: "gpu-failed", message: "The graphics card could not take the data: " + errorText(err, String(err)) };
  }

  // Start the first registered view other than the chosen one that can show the set.
  function startOtherMode(v) {
    for (var id of ET.modes.ids()) {
      if (id !== v.modeId && startMode(v, id, null)) return true;
    }
    return false;
  }

  function applyReplace(v, set) {
    var snap = snapshot(v);
    v.groupIndex = Object.create(null);
    v.groupNames = [];
    v.labelledCount = countLabelled(set, 0, set.count);
    v.labelSample = [];
    extendLabelSample(v, set, 0);
    v.lightLoad = 0;
    if (v.renderer) {
      var gpu;
      try {
        var pc = paint(v, set, 0, set.count);
        gpu = v.renderer.setData({ vectors: set.vectors, dimension: set.dimension, colours: pc.colours, weights: pc.weights });
        v.lightLoad = pc.bright;
      } catch (err) {
        restore(v, snap);
        return gpuThrew(err);
      }
      if (gpu?.ok === false) {
        // This GPU cannot take the set (too many points, too wide, a failed build or
        // upload): the renderer may still hold the previous set, or nothing usable,
        // so the view goes back exactly to what it was, renderer copy included.
        restore(v, snap);
        return { ok: false, code: gpu.reason || "gpu-failed", message: gpu.message || "The graphics card could not take the data." };
      }
    }
    v.set = set;
    v.last = null;
    v.spin = 0;
    v.drag = { active: false, yaw: 0, pitch: 0, x: 0, y: 0 };
    v.needClear = true;
    v.sinceAppend = Infinity;
    var oldMode = v.mode;
    // startMode leaves the old instance only when the new one has started.
    var started = startMode(v, v.modeId, null);
    var firstError = v.modeError;
    // The chosen view cannot show this data (too few dimensions, or a failing
    // mode): try the others.
    if (!started) started = startOtherMode(v);
    if (!started) {
      v.mode = oldMode;
      restore(v, snap);
      return { ok: false, code: "mode-failed", message: "No view can show this data: " + (firstError || "every view refused it.") };
    }
    if (firstError) notify(v, firstError); // shown on top of the fallback view
    dropSearchesForReplace(v);
    v.paintKey = paintKey(v);
    sizeStrip(v);
    describeSet(v);
    renderProvenance(v);
    return { ok: true, op: "replace", count: set.count, added: set.count };
  }

  // The labelled count and label sample after points [from, set.count) arrive.
  function appendLabels(v, set, from) {
    var hadLabelled = v.labelledCount;
    v.labelledCount += countLabelled(set, from, set.count);
    if (hadLabelled === 0 && v.labelledCount > 0) {
      // The first labelled points arrived: rebuild the label sample from them.
      v.labelSample = [];
      extendLabelSample(v, set, 0);
    } else extendLabelSample(v, set, from);
  }

  // Upload points [from, set.count) to the renderer. Returns null on success (the light
  // load then counts them), or the refusal; the caller rolls the view back.
  function uploadAppend(v, set, from) {
    var gpu;
    var pc = null;
    try {
      pc = paint(v, set, from, set.count); // may add groups: rolled back on failure
      var D = set.dimension;
      gpu = v.renderer.appendData({
        vectors: set.vectors.subarray(from * D, set.count * D),
        colours: pc.colours,
        weights: pc.weights,
      });
    } catch (err) {
      gpu = gpuThrew(err);
      gpu.reason = "gpu-failed";
    }
    if (!gpu || gpu.ok === false) {
      return { ok: false, code: gpu?.reason || "gpu-failed", message: gpu?.message || "append failed" };
    }
    v.lightLoad += pc.bright;
    return null;
  }

  // Tell the running mode about k appended points. Returns null, or the refusal after
  // putting the old set back and starting the same view again from the frame last drawn.
  function appendToMode(v, m, set, k, snap) {
    var r;
    try {
      r = m.inst.dataChanged(set, { op: "append", added: k, t: m.clock });
    } catch (err) {
      // The mode is in an unknown state: put the old set back and start the same
      // view again from the frame last drawn.
      var msg = m.title + " failed on the new points: " + errorText(err, String(err));
      restore(v, snap);
      v.mode = null;
      leaveSafely(m.inst);
      if (!startMode(v, m.id, copyState(v.last))) startMode(v, "tumble", copyState(v.last));
      return { ok: false, code: "mode-failed", message: msg };
    }
    if (r?.restart) {
      // The mode entered again: work queued for its earlier entry (a preparation
      // or a refit still running) belongs to a state that is gone, so drop it.
      m.jobs = [];
      m.refit = null;
      m.clock = 0;
      m.readyAt = null;
    }
    if (typeof r?.work?.step === "function") m.jobs.push(r.work);
    return null;
  }

  function applyAppend(v, set) {
    var old = v.set;
    var from = old.count;
    var k = set.count - from;
    if (k <= 0) {
      v.set = set;
      renderProvenance(v);
      return { ok: true, op: "append", count: set.count, added: 0 };
    }
    var t0 = now(v);
    var snap = snapshot(v);
    appendLabels(v, set, from);
    if (v.renderer) {
      var uploadFailed = uploadAppend(v, set, from);
      if (uploadFailed) {
        restore(v, snap);
        return uploadFailed;
      }
    }
    v.set = set;
    if (v.mode) {
      var modeFailed = appendToMode(v, v.mode, set, k, snap);
      if (modeFailed) return modeFailed;
    } else if (startMode(v, v.modeId, null)) notifyModeSearch(v);
    v.sinceAppend = 0;
    describeSet(v);
    renderProvenance(v);
    searchesAfterAppend(v);
    v.timing.lastAppendMs = now(v) - t0;
    return { ok: true, op: "append", count: set.count, added: k };
  }

  // ---------- sizing ----------

  function sizeStrip(v) {
    var D = v.set ? Math.max(1, v.set.dimension) : 1;
    if (v.strip.width !== D) v.strip.width = D;
    if (v.strip.height !== 1) v.strip.height = 1;
    v.stripImage = null;
    v.stripCtx = null;
    try {
      v.stripCtx = v.strip.getContext("2d");
      if (v.stripCtx) v.stripImage = v.stripCtx.createImageData(D, 1);
    } catch {
      // No 2-D context for the strip: the readout is simply not drawn.
      v.stripCtx = null;
    }
  }

  function measure(v) {
    var w = 0;
    var h = 0;
    try {
      var r = v.stage.getBoundingClientRect();
      w = r.width;
      h = r.height;
    } catch {
      // No layout box yet: fall back to the element's client size below.
      w = 0;
    }
    w = w > 0 ? w : v.stage.clientWidth || 300;
    h = h > 0 ? h : v.stage.clientHeight || 150;
    var dpr = Math.min(Number(v.options.maxPixelRatio) || 2, v.win?.devicePixelRatio || 1);
    if (v.dprCap !== null) dpr = Math.max(1, Math.min(dpr, v.dprCap));
    v.dpr = dpr;
    v.cssW = w;
    v.cssH = h;
    var W = Math.max(2, Math.round(w * dpr));
    var H = Math.max(2, Math.round(h * dpr));
    v.W = W;
    v.H = H;
    if (v.renderer) v.renderer.resize(W, H);
    if (v.overlay.width !== W) v.overlay.width = W;
    if (v.overlay.height !== H) v.overlay.height = H;
    var rootW = 0;
    try {
      rootW = v.root.getBoundingClientRect().width;
    } catch (err) {
      // No layout box for the root: lay out for the stage's width.
      rootW = w;
    }
    layoutForWidth(v, rootW || w);
    v.needClear = true;
    invalidate(v);
  }

  // No media queries without a stylesheet, so the layout reacts to the element's width.
  // Two breakpoints, each evaluated on its own: 520 px for the provenance grid (one
  // column below it) and 600 px for the rest of the narrow layout.
  function layoutForWidth(v, width) {
    var oneColumn = width < 520;
    if (oneColumn !== v.oneColumn) {
      v.oneColumn = oneColumn;
      v.provList.style.gridTemplateColumns = oneColumn ? "minmax(0, 1fr)" : "max-content minmax(0, 1fr)";
    }
    var narrow = width < 600;
    if (narrow === v.narrow) return;
    v.narrow = narrow;
    var size = narrow ? "narrow" : "wide";
    v.modeButtons.forEach(function (mb) {
      mb.summary.style.display = narrow ? "none" : "";
      mb.title.style.fontSize = spaced("mode-title-size", MODE_TITLE_SIZE[size]);
    });
    v.panel.style.padding = spaced("panel-padding", PANEL_PADDING[size]);
    v.playButton.style.minHeight = narrow ? TOUCH_HEIGHT : BUTTON_HEIGHT;
    v.zoomResetButton.style.minHeight = narrow ? TOUCH_HEIGHT : BUTTON_HEIGHT;
  }

  // ---------- the loop ----------

  function now(v) {
    var p = v.win?.performance;
    if (typeof p?.now === "function") return p.now();
    return Date.now();
  }

  function suspended(v) {
    return !!(v.doc.hidden || !v.onScreen);
  }

  // Ask for one more frame (unless destroyed, hidden or off screen).
  function invalidate(v) {
    v.dirty = true;
    schedule(v);
  }

  function schedule(v) {
    if (v.destroyed || v.raf || suspended(v)) return;
    if (typeof v.win?.requestAnimationFrame !== "function") return;
    v.raf = v.win.requestAnimationFrame(v.tick);
  }

  function unschedule(v) {
    if (v.raf && typeof v.win?.cancelAnimationFrame === "function") v.win.cancelAnimationFrame(v.raf);
    v.raf = 0;
    v.prev = null; // the next frame after a resume starts from a fresh clock
  }

  function needsMore(v) {
    if (v.dirty) return true;
    var m = v.mode;
    if (!m || !v.set || v.set.count === 0) return false;
    if (m.jobs.length || m.refit) return true;
    if (searchBusy(v)) return true;
    // A mode that is still preparing needs frames until it is ready, even when the
    // view is paused or motion is reduced: otherwise it would wait for input forever.
    if (!readyOf(m)) return true;
    if (v.running) return true;
    if (v.drag.active || v.pinch) return true;
    // Paused: keep twinkling (the reference does) unless motion is reduced.
    return !v.reducedMotion && v.rendering;
  }

  function frame(v, t) {
    v.raf = 0;
    if (v.destroyed) return;
    if (suspended(v)) {
      v.prev = null;
      return; // no frame work while hidden or off screen; resume() reschedules
    }
    var start = now(v);
    noteInterval(v, t);
    var dt = v.prev === null ? 1 / 60 : clamp((t - v.prev) / 1000, 0.001, 0.05);
    // After a long frame of the viewer's own work (a fit), count the gap as lost time,
    // not motion, so the picture does not leap ahead by a whole clamped step.
    // The rAF timestamp of a delayed frame is the vsync time from before the delay;
    // measure the next frame from when this one actually ran, or it would leap instead.
    if (v.lastSpent > 50 || v.lostTime) {
      v.lostTime = false;
      dt = 1 / 60;
      v.prev = Math.max(t, start);
    } else v.prev = t;
    v.dirty = false;
    try {
      step(v, dt, start);
    } catch (err) {
      // The loop stops; the last picture stays with a notice over it. A replace or a
      // mode switch that succeeds starts it again (recover()).
      v.broken = true;
      notify(v, "The viewer stopped: " + errorText(err, String(err)) + ". Send new data or switch views to restart it.");
      return;
    }
    var spent = now(v) - start;
    v.lastSpent = spent;
    v.lastScript = Math.max(0, spent - v.drawSpent);
    if (spent > v.timing.longestFrameMs) v.timing.longestFrameMs = spent;
    v.frames++;
    if (v.timing.firstFrameMs === null) v.timing.firstFrameMs = now(v) - v.timing.mountAt;
    v.fpsFrames++;
    if (v.fpsAt === null) v.fpsAt = t;
    else if (t - v.fpsAt >= 1000) {
      v.fps = (v.fpsFrames * 1000) / (t - v.fpsAt);
      v.fpsAt = t;
      v.fpsFrames = 0;
      adaptPixelRatio(v);
    }
    if (!v.broken && needsMore(v)) schedule(v);
  }

  // The interval between animation frames (rAF timestamps), smoothed. It is measured only
  // between frames that ran back to back: the first frame after a pause, a resume or a
  // return from hidden starts afresh, and so does the frames-per-second window.
  function noteInterval(v, t) {
    var gap = v.rafAt === null ? Infinity : t - v.rafAt;
    v.rafAt = t;
    if (v.prev === null || gap > INTERVAL_GAP_MS) {
      v.fpsAt = null;
      v.fpsFrames = 0;
      return;
    }
    if (gap > 0) v.interval = v.interval > 0 ? v.interval * 0.75 + gap * 0.25 : gap;
  }

  // The budget for this frame's heavy work. Where the time between frames went decides it:
  // on a device whose frames are long because drawing is slow (the GPU, the compositor),
  // the work may take up to WORK_SHARE of the frame interval, so it keeps making progress
  // at any frame rate. It is cut only when the work's own script time ran well past what it
  // was given. The rest of the frame's script (the mode's state, labels, uploads) is not
  // made shorter by a smaller budget, so cutting the budget for it only starves the work:
  // measured with the CPU throttled 6x, a rule on the whole script swung the budget between
  // 24 and 4 ms every other frame. info().timing reports both (workMs, scriptMs).
  function frameBudget(v) {
    var base = Math.max(1, Number(v.options.prepareBudgetMs) || 8);
    var budget = clamp(v.interval * WORK_SHARE, base, base * BUDGET_CEILING);
    if (v.timing.workMs > Math.max(OVERRUN_FLOOR_MS, v.lastBudget + OVERRUN_MS)) budget = Math.max(1, base / 2);
    // A paused view has no motion to keep smooth, so it may spend longer per frame on
    // getting ready (it still answers input every frame).
    if (!v.running) budget = Math.max(budget, PAUSED_BUDGET_MS);
    v.lastBudget = budget;
    return budget;
  }

  // Preparation and refit work run in small units (a few milliseconds each) inside the
  // frame's budget (frameBudget), so the page keeps its frame rate while a mode prepares
  // or refits, and the work keeps going on a device that draws slowly.
  function pump(v, m, start) {
    var budget = frameBudget(v);
    v.timing.budgetMs = budget;
    pumpJobs(v, m, start, budget);
    if (m.refit && v.running && now(v) - start < budget) pumpRefit(v, m, start, budget);
    pumpSearch(v, start, budget);
    v.timing.workMs = now(v) - start;
  }

  function pumpJobs(v, m, start, budget) {
    while (m.jobs.length) {
      var job = m.jobs[0];
      var left = budget - (now(v) - start);
      if (left <= 0) break;
      if (!job.done) job.step(left);
      if (job.done) m.jobs.shift();
      else break;
    }
  }

  // One step of a running refit inside what is left of the frame's budget.
  function pumpRefit(v, m, start, budget) {
    var r0 = now(v);
    m.refit.step(Math.max(1, budget - (r0 - start)));
    var took = now(v) - r0;
    m.refitSpent += took;
    if (took > m.refitLongest) m.refitLongest = took;
    if (m.refit.done) {
      m.refit = null;
      v.timing.lastRefit = {
        atMs: now(v) - v.timing.mountAt,
        durationMs: m.refitSpent,
        longestStepMs: m.refitLongest,
      };
    }
  }

  // Tumble's refit policy after appends: once appends have been quiet for
  // refitQuietSeconds and the points added since the last fit are at least
  // refitShare of the set (and at least one), fit the directions again.
  // x > 0, false for NaN and for anything that is not a number above zero.
  function positive(x) {
    return x > 0;
  }

  function considerRefit(v, m) {
    // Never while paused (frames do not run at all while hidden or off screen): a
    // paused view must not take the refit's stall; it starts after resume.
    if (!v.running) return;
    if (m.refit || m.jobs.length || typeof m.inst.refit !== "function") return;
    if (v.sinceAppend < v.options.refitQuietSeconds) return;
    var d = m.inst.describe();
    if (!d?.varianceShareStale || !positive(d.pointsSinceFit)) return;
    if (d.pointsSinceFit < Math.max(1, Math.ceil(v.options.refitShare * v.set.count))) return;
    m.refit = m.inst.refit();
    m.refitSpent = 0;
    m.refitLongest = 0;
    v.timing.refits++;
  }

  function step(v, dt, start) {
    var m = v.mode;
    var r = v.renderer;
    v.sinceAppend += dt;
    if (!m || !v.set) {
      stepWithoutView(v, r, dt);
      return;
    }
    pump(v, m, start);
    var ready = m.inst.isReady();
    if (ready) advanceReady(v, m, dt);
    else spinWhilePreparing(v, m, dt);
    var s = m.inst.stateAt(ready ? m.clock : 0);
    if (r && s.wires && s.wires.version !== m.wiresVersion) {
      r.setWires(s.wires.pairs, s.wires.lengths);
      m.wiresVersion = s.wires.version;
    }
    if (!v.reducedMotion || v.running) v.drawTime += dt;
    easeFilter(v, dt);
    v.search.hideUnlit = hidesUnlit(v);
    var ds = drawState(v, s, dt);
    v.drawSpent = 0;
    if (r && v.rendering) {
      var d0 = now(v);
      r.draw(ds);
      v.drawSpent = now(v) - d0;
    }
    v.needClear = false;
    v.last = s;
    v.lastDraw = ds;
    drawLabels(v, s, ds);
    drawSearchOverlay(v, s, ds);
    drawStrip(v, s.frame);
    v.statusClock += dt;
    if (v.statusClock >= STATUS_EVERY) updateStatus(v, m, s, ready);
  }

  // Names, spokes and the hover ring when labels are on or the pointer is over the sky;
  // otherwise the overlay is cleared.
  function drawLabels(v, s, ds) {
    if (v.showLabels || v.hover) drawOverlay(v, s, ds);
    else clearOverlay(v);
  }

  // A frame with no data, or with data no view could show: a cleared picture.
  function stepWithoutView(v, r, dt) {
    if (r && v.rendering) r.draw({ clear: true, dt: dt });
    v.status.textContent = v.set ? "this view cannot show the data" : "";
    clearLabels(v, 0);
  }

  // A frame on which the mode is ready: note when it first became ready, move the
  // clock and the spin while running, mark the time and consider a refit.
  function advanceReady(v, m, dt) {
    if (m.readyAt === null) {
      m.readyAt = now(v);
      // Show the mode's own status on this very frame: under reduced motion the loop
      // may stop right after it, and the "finding ..." line must not be left behind.
      v.statusClock = STATUS_EVERY;
      if (v.timing.firstReadyMs === null) v.timing.firstReadyMs = m.readyAt - v.timing.mountAt;
    }
    if (v.running) {
      m.clock += dt * v.speed;
      if (!v.drag.active) v.spin += dt * v.speed * spinFactor(m);
    }
    if (typeof m.inst.mark === "function") m.inst.mark(m.clock);
    considerRefit(v, m);
  }

  // While a mode prepares, the mode clock waits for ready (frames for a given mode time do
  // not depend on how fast the preparation ran) but the slow spin keeps turning the frame
  // the mode holds, so the view never stands still. It runs on the same rule as the spin
  // after ready (running, not dragging) and stops after a seek(), which asks for an exact
  // frame: a seek before ready shows the frame at that time once the mode is ready.
  function spinWhilePreparing(v, m, dt) {
    if (!v.options.spinWhilePreparing || m.seeked || !v.running || v.drag.active) return;
    v.spin += dt * v.speed * spinFactor(m);
  }

  // A mode is preparing while it is not ready, has queued work, or refits.
  function preparingOf(m) {
    return !!(m && (!readyOf(m) || m.jobs.length || m.refit));
  }

  // Once a second (with the frames-per-second figure): after ADAPT_SECONDS measured seconds
  // in a row under ADAPT_FPS, while the view moves, draws and prepares nothing, draw at a
  // lower ratio (ADAPT_STEP less, never below 1). It is never raised again in this mount.
  function adaptPixelRatio(v) {
    if (!v.options.adaptivePixelRatio || !v.running || !v.rendering || preparingOf(v.mode) || v.fps >= ADAPT_FPS) {
      v.slowSeconds = 0;
      return;
    }
    v.slowSeconds++;
    if (v.slowSeconds < ADAPT_SECONDS || v.dpr <= 1) return;
    v.slowSeconds = 0;
    v.dprCap = Math.max(1, v.dpr - ADAPT_STEP);
    measure(v);
  }

  // A mode may ask for its own spin with a `spin` member (rad/s, finite, 0 or more; Focus
  // asks for 0.13). v.spin counts seconds at SPIN, so it advances by this factor: exactly 1
  // for a mode that does not ask, and the yaw stays continuous across a change of mode.
  function spinFactor(m) {
    var r = m?.inst?.spin;
    return typeof r === "number" && Number.isFinite(r) && r >= 0 ? r / SPIN : 1;
  }

  // The status line, the view row and aria-busy, every STATUS_EVERY seconds.
  function updateStatus(v, m, s, ready) {
    v.statusClock = 0;
    var line = s.status;
    if (v.userZoom !== 1) line += " · zoom " + v.userZoom.toFixed(1) + "×";
    if (!v.running) line += " · paused";
    if (line !== v.statusText) {
      v.status.textContent = line;
      v.statusText = line;
    }
    refreshViewRow(v);
    v.root.setAttribute("aria-busy", ready && !m.jobs.length ? "false" : "true");
  }

  function drawState(v, s, dt) {
    var out = {};
    var d = s.draw;
    for (var k in d) if (Object.hasOwn(d, k)) out[k] = d[k];
    out.frame = s.frame;
    out.centre = s.centre;
    out.zoom = (d.zoom || 1) * v.userZoom;
    out.yaw = 0.4 + v.drag.yaw + SPIN * v.spin;
    out.pitch = clamp(0.16 + v.drag.pitch, -1.3, 1.3);
    out.pointSize = 6.5 * v.dpr;
    out.time = v.drawTime;
    out.dt = dt;
    if (!v.trails) out.trails = 0;
    // Ink is dark where light piles up, so on a light stage it is drawn with less gain
    // and bloom than light on black (cores keep their hue instead of burning to black).
    if (v.theme.light) {
      out.gain = 0.55;
      out.bloom = 0.3;
    }
    // Many full-weight points pile up into a white (or, in ink, black) ball, so the
    // overall brightness comes down as their number goes up.
    var crowd = crowding(v);
    if (crowd < 1) out.gain = (out.gain === undefined ? 1 : out.gain) * crowd;
    // Many wires through the same part of the stage pile up into white: the renderer scales
    // them down past WIRE_LOAD (the key is left out when no wires are shown).
    if (out.wires > 0) out.wireLoad = WIRE_LOAD;
    if (v.reducedMotion) out.twinkle = 0;
    // Search: how much the lit values apply (the key is left out with no search, so the
    // draw state is exactly as before search).
    if (v.search.filter > 0) out.filter = v.search.filter;
    out.clear = !!v.needClear;
    return out;
  }

  // Brightness factor for crowded sets, 1 up to a light load of CROWD_REF. The light
  // load is the sum of the weights of the bright points actually uploaded (weight
  // BRIGHT_WEIGHT or more): a labelled point counts 1, a point of a set with no
  // labelled point 0.7, the dim unlabelled points of a labelled set nothing. So it
  // is the labelled count, or 0.7 times the point count when nothing is labelled;
  // points uploaded at 0.7 before the first labelled point arrived by append keep
  // counting 0.7, as they are still drawn at that weight. The built-in sample set
  // has 290, so it is unchanged.
  function crowding(v) {
    var n = v.set ? v.lightLoad : 0;
    return n > CROWD_REF ? Math.pow(CROWD_REF / n, CROWD_POWER) : 1;
  }

  // ---------- overlay: labels, spokes, hover ----------

  function project(v, i, s, ds, out) {
    var D = v.set.dimension;
    var X = v.set.vectors;
    var F = s.frame;
    var C = s.centre;
    var o = i * D;
    var a = 0;
    var b = 0;
    var c = 0;
    for (var d = 0; d < D; d++) {
      var x = X[o + d] - C[d];
      a += x * F[d];
      b += x * F[D + d];
      c += x * F[2 * D + d];
    }
    out[0] = a;
    out[1] = b;
    out[2] = c;
    return ET.renderer.place(out, ds, v.W, v.H);
  }

  // ---------- the label sample along the frame, without a pass in full dimension ----------
  //
  // Names and hover need the screen position of every point of the label sample on every
  // frame: 3 * n * D multiply-adds done directly (921,600 for 300 points in 1,024-d; on a
  // device that runs JavaScript without a compiler that alone was about 50 ms a frame).
  // But a frame moves inside the span of a few directions for seconds at a time (Tumble:
  // the tour's eight; Lattice: one new direction per swap; a mode that prepares: the frame
  // it holds). The projector keeps an orthonormal basis Q of the directions the frames
  // shown lately lay in, with each sample point's coordinate along each (P). A frame row
  // inside the span costs its coefficients in Q (k * D) and a k-term sum per point; a row
  // with a part outside it adds that part to Q (one pass over the sample, n * D). When Q is
  // full it starts again from the frame shown. A row counts as inside when less than
  // PROJECT_TOL of its length is outside, so a position is off by at most PROJECT_TOL times
  // the point's distance from the origin: under a hundredth of a pixel.

  var PROJECT_TOL2 = 1e-12; // PROJECT_TOL squared
  var PROJECT_CAP = 32; // directions kept at most

  function makeProjector(D, ids, cap) {
    var K = Math.max(4, cap || PROJECT_CAP);
    var Q = []; // orthonormal directions, Float64Array(D) each
    var P = []; // P[j][i] = (sample point i) . Q[j]
    var coef = new Float64Array(3 * K);
    var X = null;
    var n = 0;
    var self = { D: D, ids: ids, size: 0, added: 0, resets: 0, bind: bind, into: into };

    function column(q, col, from, to) {
      for (var i = from; i < to; i++) {
        var o = ids[i] * D;
        var s = 0;
        for (var d = 0; d < D; d++) s += X[o + d] * q[d];
        col[i] = s;
      }
    }

    // The vector block and how many sample points to answer for. Points beyond the ones
    // already bound (an append) get their coordinates; the earlier rows are unchanged.
    function bind(vectors, count) {
      var from = X === null ? 0 : n;
      X = vectors;
      if (count > from) {
        for (var j = 0; j < Q.length; j++) {
          if (P[j].length < count) {
            var wider = new Float64Array(Math.max(count, ids.length));
            wider.set(P[j].subarray(0, from));
            P[j] = wider;
          }
          column(Q[j], P[j], from, count);
        }
      }
      n = count;
    }

    // Row r's coefficients in Q into coef; true when the row is inside the span.
    function coefficients(F, r) {
      var o = r * D;
      var nf = 0;
      for (var d = 0; d < D; d++) nf += F[o + d] * F[o + d];
      var got = 0;
      for (var j = 0; j < Q.length; j++) {
        var q = Q[j];
        var c = 0;
        for (var d2 = 0; d2 < D; d2++) c += F[o + d2] * q[d2];
        coef[r * K + j] = c;
        got += c * c;
      }
      return nf - got <= PROJECT_TOL2 * nf; // false for NaN too
    }

    // The part of row r outside the span, as a unit vector, or null when there is none
    // to speak of (or the row is not finite).
    function outside(F, r) {
      var o = r * D;
      var q = new Float64Array(D);
      var nf = 0;
      for (var d = 0; d < D; d++) {
        q[d] = F[o + d];
        nf += q[d] * q[d];
      }
      for (var pass = 0; pass < 2; pass++) {
        for (var b of Q) {
          var dp = 0;
          for (var d2 = 0; d2 < D; d2++) dp += q[d2] * b[d2];
          for (var d3 = 0; d3 < D; d3++) q[d3] -= dp * b[d3];
        }
      }
      var nn = 0;
      for (var d4 = 0; d4 < D; d4++) nn += q[d4] * q[d4];
      var real = nn > (PROJECT_TOL2 / 4) * nf; // false for NaN too
      if (!real) return null;
      var inv = 1 / Math.sqrt(nn);
      for (var d5 = 0; d5 < D; d5++) q[d5] *= inv;
      return q;
    }

    // Make row r answerable: 0 when it is (after adding its outside part if it had
    // one), 1 when the basis was full and has been emptied (every row starts again).
    function cover(F, r) {
      if (coefficients(F, r)) return 0;
      var q = outside(F, r);
      if (!q) return 0;
      if (Q.length >= K) {
        Q = [];
        P = [];
        self.resets++;
        return 1;
      }
      var col = new Float64Array(Math.max(n, ids.length));
      column(q, col, 0, n);
      Q.push(q);
      P.push(col);
      self.added++;
      coefficients(F, r);
      return 0;
    }

    // out[3 * i + r] = (sample point i - centre) . (frame row r), for i < n.
    function into(F, C, out) {
      var r = 0;
      var restarts = 0;
      var before = self.added;
      while (r < 3) {
        if (cover(F, r) && restarts < 2) {
          restarts++;
          r = 0;
        } else r++;
      }
      // A direction added for a later row is one the earlier rows have no coefficient
      // for yet: work all three out again against the basis as it is now.
      if (self.added !== before) for (var r2 = 0; r2 < 3; r2++) coefficients(F, r2);
      self.size = Q.length;
      var f0 = 0;
      var f1 = 0;
      var f2 = 0;
      for (var d = 0; d < D; d++) {
        f0 += C[d] * F[d];
        f1 += C[d] * F[D + d];
        f2 += C[d] * F[2 * D + d];
      }
      for (var i = 0; i < n; i++) {
        out[3 * i] = -f0;
        out[3 * i + 1] = -f1;
        out[3 * i + 2] = -f2;
      }
      for (var j = 0; j < Q.length; j++) {
        var col = P[j];
        var c0 = coef[j];
        var c1 = coef[K + j];
        var c2 = coef[2 * K + j];
        for (var i2 = 0; i2 < n; i2++) {
          out[3 * i2] += c0 * col[i2];
          out[3 * i2 + 1] += c1 * col[i2];
          out[3 * i2 + 2] += c2 * col[i2];
        }
      }
      return out;
    }

    return self;
  }

  // The projector for the label sample as it is now (a new one after a replace, a
  // rebuilt sample or a rollback; an append only adds its points).
  function sampleProjector(v, n) {
    var D = v.set.dimension;
    if (v.projector?.ids !== v.labelSample || v.projector.D !== D) v.projector = makeProjector(D, v.labelSample);
    v.projector.bind(v.set.vectors, n);
    return v.projector;
  }

  // The overlay's 2-D context, looked up once (null when there is none).
  function overlayContext(v) {
    if (v.overlayCtx === undefined) v.overlayCtx = safeContext2d(v.overlay);
    return v.overlayCtx;
  }

  function clearOverlay(v) {
    if (overlayContext(v) && v.overlayDirty) {
      v.overlayCtx.clearRect(0, 0, v.W, v.H);
      v.overlayDirty = false;
    }
    clearLabels(v, 0);
  }

  function safeContext2d(canvas) {
    try {
      return canvas.getContext("2d") || null;
    } catch (err) {
      // No 2-D context: the overlay (names, spokes, hover ring) is not drawn.
      return null;
    }
  }

  // A new element for the label pool.
  function newLabel(v) {
    var el = make(v, "span", "tumbler-label", {
      position: "absolute",
      left: "0",
      top: "0",
      whiteSpace: "nowrap",
      pointerEvents: "none",
      willChange: "transform",
    });
    v.labelLayer.appendChild(el);
    var rec = { el: el, text: null, key: "", shown: true };
    v.labelPool.push(rec);
    return rec;
  }

  // Type size of a label: the Wander stop large, a hovered name a little above the rest.
  function labelFontSize(kind) {
    if (kind === "stop") return "26px";
    if (kind === "hover") return "12px";
    return "11px";
  }

  // Where a label sits against its anchor point.
  function labelShift(align) {
    if (align === "center") return "translate(-50%, -100%)";
    if (align === "right") return "translate(-100%, -50%)";
    return "translate(0, -50%)";
  }

  function styleLabel(v, rec, style) {
    var t = v.theme;
    var big = style.kind === "stop";
    setStyles(rec.el, {
      fontFamily: big ? t.fontDisplay : t.fontData,
      fontStyle: big ? "italic" : "normal",
      fontSize: labelFontSize(style.kind),
      letterSpacing: style.kind === "group" ? "0.06em" : "0",
      textTransform: style.kind === "group" ? "uppercase" : "none",
      color: style.colour,
      textShadow: v.outline,
    });
  }

  function label(v, used, str, x, y, style) {
    if (used >= LABEL_POOL) return used;
    var rec = v.labelPool[used] || newLabel(v);
    if (rec.text !== str) {
      rec.el.textContent = str;
      rec.text = str;
    }
    var key = style.kind + "|" + style.colour;
    if (rec.key !== key) {
      styleLabel(v, rec, style);
      rec.key = key;
    }
    var shift = labelShift(style.align);
    rec.el.style.transform = "translate(" + x.toFixed(1) + "px, " + y.toFixed(1) + "px) " + shift;
    rec.el.style.opacity = String(Math.round(clamp(style.alpha, 0, 1) * 100) / 100);
    if (!rec.shown) {
      rec.el.style.display = "";
      rec.shown = true;
    }
    return used + 1;
  }

  function clearLabels(v, used) {
    for (var i = used; i < v.labelPool.length; i++) {
      var rec = v.labelPool[i];
      if (rec.shown) {
        rec.el.style.display = "none";
        rec.shown = false;
      }
    }
  }

  function labelText(v, i) {
    var p = v.set.points[i];
    var s = typeof p.label === "string" && p.label.trim() !== "" ? p.label : p.id;
    return shorten(s, 40);
  }

  function drawOverlay(v, s, ds) {
    var ctx = overlayContext(v);
    if (ctx) {
      ctx.clearRect(0, 0, v.W, v.H);
      v.overlayDirty = false;
    }
    var used = 0;
    var fogMix = clamp(Number(s.draw.fog) || 0, 0, 1);
    var n = v.labelSample.length;
    if (v.sx.length < n) {
      v.sx = new Float32Array(LABEL_SAMPLE);
      v.sy = new Float32Array(LABEL_SAMPLE);
    }
    var needSample = (v.showLabels && fogMix < 0.97) || v.hover;
    if (needSample) projectSample(v, s, ds, n);
    // Group names at the middle of their labelled points, fading out as Wander's fog comes in;
    // none in Focus while a search is shown (the results are what matters there).
    var focusSearch = v.modeId === "focus" && v.search.filter > 0;
    if (v.showLabels && fogMix < 0.97 && v.groupNames.length && !focusSearch) used = drawGroupNames(v, used, fogMix, n);
    // Wander: the stop, its labelled neighbours and spokes to them.
    if (s.focus && v.mode) used = drawFocus(v, s, ds, used);
    // Hover: the nearest sampled point within 20 px.
    if (v.hover && n) used = drawHover(v, used, n);
    if (ctx) ctx.globalAlpha = 1;
    clearLabels(v, used);
  }

  // Screen positions of the first n points of the label sample, into v.sx and v.sy:
  // their coordinates along the frame from the projector, then the screen mapping with
  // the draw state merged once.
  function projectSample(v, s, ds, n) {
    if (n === 0) return;
    if (v.sampleCoords.length < 3 * n) v.sampleCoords = new Float64Array(3 * Math.max(n, LABEL_SAMPLE));
    var co = sampleProjector(v, n).into(s.frame, s.centre, v.sampleCoords);
    var put = ET.renderer.placer(ds, v.W, v.H);
    var q = v.placed;
    for (var j = 0; j < n; j++) {
      put(co[3 * j], co[3 * j + 1], co[3 * j + 2], q);
      v.sx[j] = q.x;
      v.sy[j] = q.y;
    }
  }

  function drawGroupNames(v, used, fogMix, n) {
    var dpr = v.dpr;
    var sample = v.labelSample;
    var G = v.groupNames.length;
    var cx = new Float64Array(G);
    var cy = new Float64Array(G);
    var cn = new Float64Array(G);
    for (var k = 0; k < n; k++) {
      var g = v.groupIndex[v.set.points[sample[k]].group];
      if (g === undefined || hiddenPoint(v, sample[k])) continue;
      cx[g] += v.sx[k];
      cy[g] += v.sy[k];
      cn[g]++;
    }
    for (var gi = 0; gi < G; gi++) {
      if (!cn[gi]) continue;
      // Lighter than the points on a dark host (the reference's 72% lightness),
      // darker on a light one so the names stay readable.
      var col = cssRgb(v.theme.light ? mix(groupColour(v, gi), [0, 0, 0], 0.45) : nameTint(groupColour(v, gi)));
      used = label(v, used, shorten(v.groupNames[gi], 32), cx[gi] / cn[gi] / dpr, cy[gi] / cn[gi] / dpr - 14, {
        kind: "group",
        colour: col,
        alpha: (1 - fogMix) * 0.8,
        align: "center",
      });
    }
    return used;
  }

  function drawFocus(v, s, ds, used) {
    var f = s.focus;
    var m = v.mode;
    if (f.to !== m.lastFocusTo) {
      m.prevNeighbours = m.curNeighbours;
      m.lastFocusTo = f.to;
    }
    m.curNeighbours = f.neighbours ? Array.prototype.slice.call(f.neighbours) : [];
    if (f.phase === "dwell") return spokes(v, f.to, m.curNeighbours, 1, s, ds, used);
    var e = clamp(Number(f.e) || 0, 0, 1);
    used = spokes(v, f.from, m.prevNeighbours || [], 1 - e * 1.6, s, ds, used);
    return spokes(v, f.to, m.curNeighbours, e * e, s, ds, used);
  }

  // The index into the label sample of the point nearest the pointer within 20 px, or -1.
  function nearestSampled(v, n) {
    var dpr = v.dpr;
    var best = -1;
    var bd = 20 * dpr * (20 * dpr);
    for (var h = 0; h < n; h++) {
      if (hiddenPoint(v, v.labelSample[h])) continue;
      var dx = v.sx[h] - v.hover.x * dpr;
      var dy = v.sy[h] - v.hover.y * dpr;
      var d2 = dx * dx + dy * dy;
      if (d2 < bd) {
        bd = d2;
        best = h;
      }
    }
    return best;
  }

  function drawHover(v, used, n) {
    var best = nearestSampled(v, n);
    if (best < 0) return used;
    var ctx = v.overlayCtx;
    var dpr = v.dpr;
    var bi = v.labelSample[best];
    if (ctx) {
      ctx.globalAlpha = 1;
      ctx.lineWidth = 1.5 * dpr;
      ctx.strokeStyle = v.stopColour;
      ctx.beginPath();
      ctx.arc(v.sx[best], v.sy[best], 8 * dpr, 0, TAU);
      ctx.stroke();
      v.overlayDirty = true;
    }
    var right = v.sx[best] > v.W * 0.7;
    var grp = v.set.points[bi].group;
    var str = labelText(v, bi) + (grp ? " · " + shorten(grp, 24) : "");
    return label(v, used, str, v.sx[best] / dpr + (right ? -14 : 14), v.sy[best] / dpr, {
      kind: "hover",
      colour: v.stopColour,
      alpha: 1,
      align: right ? "right" : "left",
    });
  }

  // i is a point index of the current set: 0 <= i < count (false for NaN or a non-number).
  function isPointIndex(v, i) {
    return i >= 0 && i < v.set.count;
  }

  // Spokes from point i to its neighbours, a ring round it and the names, at alpha.
  // Drawn on the overlay's 2-D context when there is one.
  function spokes(v, i, neighbours, alpha, s, ds, used) {
    if (!isPointIndex(v, i) || alpha <= 0.02) return used;
    var ctx = v.overlayCtx;
    var dpr = v.dpr;
    var p = project(v, i, s, ds, v.tmp3);
    var px = p.x;
    var py = p.y;
    var gc = groupColour(v, groupIndexOf(v, v.set.points[i].group));
    var col = cssRgb(v.theme.light ? gc : nameTint(gc));
    for (var j of neighbours) {
      if (!isPointIndex(v, j)) continue;
      var q = project(v, j, s, ds, v.tmp3);
      if (ctx) {
        ctx.globalAlpha = alpha * 0.5;
        ctx.lineWidth = dpr;
        ctx.strokeStyle = col;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(q.x, q.y);
        ctx.stroke();
        v.overlayDirty = true;
      }
      if (v.showLabels) {
        used = label(v, used, labelText(v, j), q.x / dpr + 8, q.y / dpr + 4, {
          kind: "neighbour",
          colour: v.neighbourColour,
          alpha: alpha * 0.85,
          align: "left",
        });
      }
    }
    if (ctx) {
      ctx.globalAlpha = alpha;
      ctx.lineWidth = 1.5 * dpr;
      ctx.strokeStyle = col;
      ctx.beginPath();
      ctx.arc(px, py, 11 * dpr, 0, TAU);
      ctx.stroke();
      v.overlayDirty = true;
    }
    if (v.showLabels) {
      used = label(v, used, labelText(v, i), px / dpr + 18, py / dpr - 12, {
        kind: "stop",
        colour: v.stopColour,
        alpha: alpha,
        align: "left",
      });
    }
    return used;
  }

  // ---------- readout strip ----------

  // One cell per dimension. Its opacity is how much that dimension contributes to the three
  // axes on screen, relative to an even share (the reference's (f0^2 + f1^2 + f2^2) * D / 3).
  // Its colour mixes the three axis colours by the dimension's squared component on each
  // axis, divided by their sum: a dimension that feeds one axis shows that axis's colour.
  function drawStrip(v, F) {
    if (!v.stripCtx || !v.stripImage || !v.set) return;
    var D = v.set.dimension;
    var px = v.stripImage.data;
    var c = v.axisRgb;
    for (var d = 0; d < D; d++) {
      var ax = F[d] * F[d];
      var ay = F[D + d] * F[D + d];
      var az = F[2 * D + d] * F[2 * D + d];
      var sum = ax + ay + az;
      var norm = sum > 0 ? sum : 1;
      var o = d * 4;
      px[o] = (c[0][0] * ax + c[1][0] * ay + c[2][0] * az) / norm;
      px[o + 1] = (c[0][1] * ax + c[1][1] * ay + c[2][1] * az) / norm;
      px[o + 2] = (c[0][2] * ax + c[1][2] * ay + c[2][2] * az) / norm;
      px[o + 3] = Math.min(255, ((sum * D) / 3) * 80);
    }
    v.stripCtx.putImageData(v.stripImage, 0, 0);
  }

  // ---------- input ----------

  function listen(v, target, type, fn, opts) {
    target.addEventListener(type, fn, opts);
    v.listeners.push([target, type, fn, opts]);
  }

  function setZoom(v, z) {
    var next = clamp(z, ZOOM_MIN, ZOOM_MAX);
    if (Math.abs(next - 1) < 0.02) next = 1;
    v.userZoom = next;
    v.statusClock = STATUS_EVERY;
    invalidate(v);
    return v.userZoom;
  }

  function hasFocus(v) {
    var a = v.doc.activeElement;
    return !!a && (a === v.root || (typeof v.root.contains === "function" && v.root.contains(a)));
  }

  function setRunning(v, run) {
    run = !!run;
    if (run === v.running) return;
    v.running = run;
    v.playButton.textContent = run ? "Pause" : "Play";
    v.playButton.setAttribute("aria-pressed", run ? "false" : "true");
    v.statusClock = STATUS_EVERY;
    call(v, v.options.onPauseChange, !run);
    invalidate(v);
  }

  // A key pressed while the viewer has focus (no modifier, not in a form field).
  // Returns true when the key did something, so its default action is prevented.
  function handleKey(v, k, target) {
    if (k === "Escape" || k === "Esc") {
      if (v.noticeMessage === null) return false;
      clearNotice(v);
      return true;
    }
    if (/^[1-9]$/.test(k)) return switchByKey(v, Number(k) - 1);
    if ((k === " " || k === "Spacebar") && target === v.root) {
      setRunning(v, !v.running);
      return true;
    }
    if (k === "+" || k === "=") {
      setZoom(v, v.userZoom * 1.25);
      return true;
    }
    if (k === "-" || k === "_") {
      setZoom(v, v.userZoom / 1.25);
      return true;
    }
    if (k === "0") {
      setZoom(v, 1);
      return true;
    }
    return false;
  }

  // Keys 1-9: the view of that mode button, if there is one.
  function switchByKey(v, idx) {
    if (idx >= v.modeButtons.length) return false;
    setMode(v, v.modeButtons[idx].id);
    return true;
  }

  function wire(v) {
    var stage = v.stage;
    var pointers = {};
    var count = 0;
    var lastTap = null;

    function pos(e) {
      var r = { left: 0, top: 0 };
      try {
        r = stage.getBoundingClientRect();
      } catch (err) {
        // No layout box: measure from the page origin.
        r = { left: 0, top: 0 };
      }
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }
    function pinchDistance() {
      var ids = Object.keys(pointers);
      if (ids.length < 2) return 0;
      var a = pointers[ids[0]];
      var b = pointers[ids[1]];
      return Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
    }

    // Only a press on the sky itself turns the cloud. A press on a control inside the
    // stage (the notice's Dismiss button, a message) is left alone: no pointer
    // capture, no drag, no focus change, so the control gets its own click.
    function onSky(e) {
      var t = e.target;
      return t === stage || t === v.canvas || t === v.overlay || t === v.labelLayer;
    }

    listen(v, stage, "pointerdown", function (e) {
      if (e.button !== undefined && e.button > 0) return;
      if (!onSky(e)) return;
      pointers[e.pointerId] = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: now(v) };
      count = Object.keys(pointers).length;
      try {
        if (stage.setPointerCapture) stage.setPointerCapture(e.pointerId);
      } catch (err) {
        // capture is optional
      }
      if (!hasFocus(v)) {
        try {
          v.root.focus({ preventScroll: true });
        } catch (err) {
          // focus is a convenience
        }
      }
      if (count >= 2) {
        v.drag.active = false;
        v.pinch = { d0: pinchDistance() || 1, z0: v.userZoom };
      } else {
        v.drag.active = true;
        v.drag.x = e.clientX;
        v.drag.y = e.clientY;
        stage.style.cursor = "grabbing";
      }
      invalidate(v);
    });
    listen(v, stage, "pointermove", function (e) {
      var pt = pointers[e.pointerId];
      if (pt) {
        pt.x = e.clientX;
        pt.y = e.clientY;
      }
      if (v.pinch && count >= 2) {
        setZoom(v, v.pinch.z0 * (pinchDistance() / v.pinch.d0));
        return;
      }
      if (v.drag.active && pt) {
        v.drag.yaw += (e.clientX - v.drag.x) * 0.007;
        v.drag.pitch = clamp(v.drag.pitch + (e.clientY - v.drag.y) * 0.007, -1.46, 1.14);
        v.drag.x = e.clientX;
        v.drag.y = e.clientY;
        v.hover = null;
        invalidate(v);
        return;
      }
      if (e.pointerType === "mouse" || e.pointerType === undefined) {
        v.hover = pos(e);
        invalidate(v);
      }
    });
    function end(e) {
      var pt = pointers[e.pointerId];
      delete pointers[e.pointerId];
      count = Object.keys(pointers).length;
      if (count < 2) v.pinch = null;
      if (count === 0) {
        v.drag.active = false;
        stage.style.cursor = "grab";
      }
      if (e.type === "pointerup" && pt) focusClick(v, e, pt, pos(e));
      // Double tap (touch or pen) resets the zoom; a mouse uses dblclick.
      if (e.type === "pointerup" && pt && e.pointerType && e.pointerType !== "mouse") {
        var moved = Math.abs(e.clientX - pt.sx) + Math.abs(e.clientY - pt.sy);
        var t = now(v);
        if (moved < 12 && t - pt.t < 300) {
          if (lastTap && t - lastTap.t < 350 && Math.abs(e.clientX - lastTap.x) + Math.abs(e.clientY - lastTap.y) < 32) {
            setZoom(v, 1);
            lastTap = null;
          } else lastTap = { t: t, x: e.clientX, y: e.clientY };
        }
      }
      invalidate(v);
    }
    listen(v, stage, "pointerup", end);
    listen(v, stage, "pointercancel", end);
    listen(v, stage, "pointerleave", function () {
      v.hover = null;
      invalidate(v);
    });
    listen(v, stage, "dblclick", function (e) {
      if (!onSky(e)) return;
      if (e.preventDefault) e.preventDefault();
      setZoom(v, 1);
    });
    // Wheel zooms only over the stage and only with Ctrl or Cmd held (a trackpad pinch
    // arrives that way) or while the viewer has focus; otherwise the page scrolls.
    listen(
      v,
      stage,
      "wheel",
      function (e) {
        var mod = !!(e.ctrlKey || e.metaKey);
        if (!mod && !hasFocus(v)) return;
        if (e.preventDefault) e.preventDefault();
        var dy = Number(e.deltaY) || 0;
        if (e.deltaMode === 1) dy *= 16;
        else if (e.deltaMode === 2) dy *= 400;
        setZoom(v, v.userZoom * Math.exp(-dy * (mod ? 0.01 : 0.0015)));
      },
      { passive: false }
    );

    listen(v, v.root, "keydown", function (e) {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      var target = e.target;
      var tag = target?.tagName ? String(target.tagName).toUpperCase() : "";
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (handleKey(v, e.key, target) && e.preventDefault) e.preventDefault();
    });

    v.modeButtons.forEach(function (mb) {
      listen(v, mb.button, "click", function () {
        setMode(v, mb.id);
      });
    });
    listen(v, v.playButton, "click", function () {
      setRunning(v, !v.running);
    });
    listen(v, v.zoomResetButton, "click", function () {
      setZoom(v, 1);
    });
    listen(v, v.noticeDismiss, "click", function () {
      clearNotice(v);
    });
    listen(v, v.speedInput, "input", function () {
      var s = Number(v.speedInput.value);
      v.speed = Number.isFinite(s) && s > 0 ? s : 1;
    });
    listen(v, v.labelsInput, "change", function () {
      v.showLabels = !!v.labelsInput.checked;
      invalidate(v);
    });
    listen(v, v.trailsInput, "change", function () {
      v.trails = !!v.trailsInput.checked;
      v.needClear = true;
      invalidate(v);
    });

    // Pause while the document is hidden or the element is off screen.
    listen(v, v.doc, "visibilitychange", function () {
      if (suspended(v)) unschedule(v);
      else invalidate(v);
    });
    var IO = v.win?.IntersectionObserver;
    if (typeof IO === "function") {
      v.io = new IO(function (entries) {
        var last = entries?.length ? entries.at(-1) : null;
        if (!last) return;
        v.onScreen = !!last.isIntersecting;
        if (suspended(v)) unschedule(v);
        else invalidate(v);
      });
      v.io.observe(v.root);
    }
    var RO = v.win?.ResizeObserver;
    if (typeof RO === "function") {
      v.ro = new RO(function () {
        measure(v);
      });
      v.ro.observe(v.stage);
      v.ro.observe(v.root);
    } else if (typeof v.win?.addEventListener === "function") {
      listen(v, v.win, "resize", function () {
        measure(v);
      });
    }
  }

  // ---------- renderer ----------

  function makeRenderer(v) {
    var made = ET.renderer.create(v.canvas, {
      releaseContext: true, // the canvas is thrown away by destroy
      preserveDrawingBuffer: !!v.options.preserveDrawingBuffer,
      onContextChange: function (ev) {
        if (v.destroyed) return;
        if (ev.type === "lost") {
          v.rendering = false;
          notify(v, "The graphics context was lost; waiting for the browser to restore it.");
        } else if (ev.type === "restored") {
          v.rendering = true;
          if (v.mode) v.mode.wiresVersion = -1;
          clearNotice(v);
          v.needClear = true;
          invalidate(v);
        } else {
          v.rendering = false;
          fatal(v, ev.message || "The graphics context could not be restored.");
          retryRebuild(v);
        }
      },
    });
    if (!made.ok) {
      v.renderer = null;
      v.rendering = false;
      fatal(v, made.message);
      return;
    }
    v.renderer = made.renderer;
    v.rendering = true;
  }

  // One retry a second after a failed restore; further retries happen on update.
  function retryRebuild(v) {
    if (v.retryTimer || typeof v.win?.setTimeout !== "function") return;
    v.retryTimer = v.win.setTimeout(function () {
      v.retryTimer = 0;
      if (v.destroyed || !v.renderer) return;
      var r = v.renderer.rebuild();
      if (r?.ok) {
        v.rendering = true;
        clearFatal(v);
        if (v.mode) v.mode.wiresVersion = -1;
        invalidate(v);
      }
    }, 1000);
  }

  // ---------- search ----------
  //
  // docs/search-interface.md, "Viewer (t8)". The viewer holds the searches shown, runs the
  // host's embed and rerank callbacks (it never fetches anything itself), pumps the ranking,
  // word-matching and facing-frame steppers inside the frame budget, hands the lit values to
  // the renderer and the facing frame to the mode. One run (a setSearches call, a settings
  // change or a re-run after an append) is in progress at a time; a newer run supersedes it,
  // and every late callback answer or stepper result of a superseded run is dropped.

  var SEARCH_MESSAGES = {
    "no-embedder":
      "Cannot embed the query: the host supplied no embed callback. Search among the loaded points still works.",
    "embed-failed": "The embedder failed to answer. The earlier results are kept.",
    "embed-timeout": "The embedder did not answer within {seconds} seconds. The earlier results are kept.",
    "embed-malformed": "The embedder's answer was not a vector with a model id. The earlier results are kept.",
    "rerank-failed": "The reranker failed to answer; the results stay in embedding order.",
    "rerank-timeout": "The reranker did not answer within {seconds} seconds; the results stay in embedding order.",
    "rerank-no-text": "A vector search with no label has no text to send to the reranker; it stays in embedding order.",
    "too-many-searches": "At most 4 searches at once; {found} were given.",
    "bad-search": "A search must be text, { text }, { vector, model } or { point }, given in an array.",
    superseded: "A newer search replaced this one.",
    destroyed: "This viewer has been destroyed.",
  };
  var FILTER_TIME = 0.35; // seconds: the reference's filterMix time constant
  var CLICK_SLOP = 5; // px a Focus click may move between press and release
  var CLICK_REACH = 16; // px from a point a Focus click may land

  function searchRefusal(code, values) {
    var tpl = Object.hasOwn(SEARCH_MESSAGES, code) ? SEARCH_MESSAGES[code] : null;
    var message = tpl
      ? tpl.replaceAll(/\{(\w+)\}/g, function (all, name) {
          return values && Object.hasOwn(values, name) ? String(values[name]) : all;
        })
      : ET.search.format(code, values);
    return { ok: false, code: code, message: message };
  }

  function plainRefusal(r) {
    return { ok: false, code: r.code, message: r.message };
  }

  function isObj(x) {
    return !!x && typeof x === "object";
  }

  function newSearchState(opts) {
    var ms = Number(opts.searchTimeoutMs);
    return {
      embed: typeof opts.embed === "function" ? opts.embed : null,
      rerank: typeof opts.rerank === "function" ? opts.rerank : null,
      timeoutMs: ms > 0 ? ms : 15000,
      settings: {
        k: ET.search.clampK(opts.searchK),
        candidates: ET.search.clampCandidates(opts.searchCandidates),
        top: ET.search.clampTop(opts.searchTop, opts.searchCandidates),
        lit: ET.searchSets.litSetting(opts.searchLit),
        distances: false,
        rerank: false,
        pointOfView: null,
        onlyResults: false,
      },
      run: null, // the run in progress
      work: [], // steppers of the run in progress: { run, job, after }
      shown: [], // the searches shown, in letter order
      shownSet: null, // the set they were worked out on
      shownUsed: null, // the settings they were worked out with: { k, candidates, top, pointOfView, rerank }
      lit: null, // ET.searchSets.litValues of the searches shown
      pairs: [],
      unmatched: [],
      code: null,
      message: null,
      facingJob: null, // { job, swing }
      facingTarget: null, // the facing frame of the searches shown, once worked out
      filter: 0, // eased toward 1 while a search is shown, toward 0 when none is
      litUploaded: false,
      hideUnlit: false, // Focus's Only results hides unlit points this frame
      panel: null,
    };
  }

  function isCurrent(v, run) {
    return !v.destroyed && v.search.run === run;
  }

  // ----- timers and guarded callbacks -----

  function clearRunTimers(v, run) {
    var w = v.win;
    for (var id of run.timers) if (typeof w?.clearTimeout === "function") w.clearTimeout(id);
    run.timers = [];
  }

  // Call a host callback with exactly `args`. `done` gets { ok: true, value } or a refusal
  // (<prefix>-failed, <prefix>-timeout), once, and only while the run is current: a late
  // answer of a superseded run, or any answer after destroy, touches nothing.
  function callHost(v, run, fn, args, prefix, done) {
    var settled = false;
    var timer = 0;
    function finish(outcome) {
      if (settled) return;
      settled = true;
      if (!isCurrent(v, run)) return;
      if (timer) {
        run.timers = run.timers.filter(function (t) {
          return t !== timer;
        });
        v.win.clearTimeout(timer);
      }
      done(outcome);
    }
    var w = v.win;
    if (typeof w?.setTimeout === "function" && typeof w.clearTimeout === "function") {
      timer = w.setTimeout(function () {
        finish(searchRefusal(prefix + "-timeout", { seconds: v.search.timeoutMs / 1000 }));
      }, v.search.timeoutMs);
      run.timers.push(timer);
    }
    var answer;
    try {
      answer = Promise.resolve(fn(...args));
    } catch (err) {
      // The host's error is the host's own: it may carry an address or a key, so it is
      // not shown; the refusal says only that the callback failed.
      finish(searchRefusal(prefix + "-failed"));
      return;
    }
    answer.then(
      function (value) {
        finish({ ok: true, value: value });
      },
      function () {
        finish(searchRefusal(prefix + "-failed"));
      }
    );
  }

  // ----- entries -----

  // One entry of setSearches as a source: { ok: true, src } or a refusal. A text source
  // says whether it is embedded or matched among the loaded points; a vector or point
  // source is checked here (they need no callback).
  function parseEntry(v, entry) {
    if (typeof entry === "string") return textSource(v, entry, "auto");
    if (!isObj(entry)) return searchRefusal("bad-search");
    try {
      if (typeof entry.text === "string") return textSource(v, entry.text, entry.via);
      if (entry.vector !== undefined) return vectorSource(v, entry);
      if (entry.point !== undefined) return pointSource(v, entry.point);
    } catch {
      // A getter on the host's entry threw: the entry is not one of the forms.
      return searchRefusal("bad-search");
    }
    return searchRefusal("bad-search");
  }

  function textSource(v, text, via) {
    if (ET.search.tokens(text).length === 0) return searchRefusal("empty-query");
    var s = v.search;
    var same = ET.search.checkSameSpace(v.set);
    if (via === "words") return { ok: true, src: { kind: "words", text: text, note: null } };
    if (via === "embed") {
      if (!s.embed) return searchRefusal("no-embedder");
      if (!same.ok) return plainRefusal(same);
      return { ok: true, src: { kind: "embedded", text: text, note: null } };
    }
    if (s.embed && same.ok) return { ok: true, src: { kind: "embedded", text: text, note: null } };
    var note = s.embed && same.code === "reduction-not-searchable" ? same.message : null;
    return { ok: true, src: { kind: "words", text: text, note: note } };
  }

  function vectorSource(v, entry) {
    var c = ET.search.checkQuery(v.set, { vector: entry.vector, model: entry.model });
    if (!c.ok) return plainRefusal(c);
    var label = typeof entry.label === "string" && entry.label !== "" ? entry.label : null;
    return {
      ok: true,
      src: prepared("vector", label || "vector", entry.model, c.vector, { rerankText: label }),
    };
  }

  function pointSource(v, id) {
    var c = ET.search.pointQuery(v.set, id);
    if (!c.ok) return plainRefusal(c);
    return {
      ok: true,
      src: prepared("point", String(c.id), v.set.model, c.vector, {
        point: c.id,
        rerankText: ET.search.pointText(v.set, c.index),
      }),
    };
  }

  // A search whose query vector is known.
  function prepared(kind, text, model, query, extra) {
    var q = {
      kind: kind,
      text: text,
      model: model,
      queryForm: null,
      sentTo: "nowhere",
      words: null,
      point: null,
      baseNote: null,
      query: query,
      rerankText: null,
      ready: true,
    };
    if (extra) for (var k in extra) if (Object.hasOwn(extra, k)) q[k] = extra[k];
    return q;
  }

  // ----- runs -----

  function newRun(v, kind, resolve, swing) {
    return {
      kind: kind, // "set" | "settings" | "rerun"
      resolve: resolve,
      swing: swing,
      timers: [],
      searches: [], // one slot per entry; null when left out
      left: 0,
      unmatched: [],
      set: v.set,
      used: null,
      pendingEmbed: 0,
      pendingRerank: 0,
      pairs: null,
    };
  }

  // End the run in progress (if any) with `result` for its caller.
  function endRun(v, result) {
    var s = v.search;
    var run = s.run;
    if (!run) return;
    s.run = null;
    s.work = [];
    clearRunTimers(v, run);
    if (run.resolve) run.resolve(result);
  }

  function beginRun(v, run) {
    endRun(v, searchRefusal("superseded"));
    v.search.run = run;
  }

  function refuseRun(v, run, refusal) {
    if (!isCurrent(v, run)) return;
    var s = v.search;
    endRun(v, refusal);
    s.code = refusal.code;
    s.message = refusal.message;
    call(v, v.options.onError, plainRefusal(refusal));
    searchChanged(v);
    // A refused new search leaves the earlier ones; if they were waiting to be worked out
    // again (an append, a settings change), that starts now. A refused re-run is not retried.
    if (run.kind === "set" && needsRerun(v)) rerun(v, "rerun", null);
  }

  function setSearches(v, list) {
    if (v.destroyed) return Promise.resolve(searchRefusal("destroyed"));
    if (!Array.isArray(list)) return Promise.resolve(searchRefusal("bad-search"));
    if (list.length > ET.searchSets.MAX_SEARCHES) {
      return Promise.resolve(searchRefusal("too-many-searches", { found: list.length }));
    }
    if (list.length === 0) {
      clearSearches(v);
      return Promise.resolve({ ok: true, search: searchInfo(v) });
    }
    return new Promise(function (resolve) {
      var run = newRun(v, "set", resolve, true);
      beginRun(v, run);
      startSources(v, run, list);
    });
  }

  function startSources(v, run, list) {
    if (!v.set || v.set.count === 0) {
      refuseRun(v, run, searchRefusal("no-data"));
      return;
    }
    var sources = [];
    for (var entry of list) {
      var p = parseEntry(v, entry);
      if (!p.ok) {
        refuseRun(v, run, p);
        return;
      }
      sources.push(p.src);
    }
    resolveSources(v, run, sources);
    searchChanged(v); // waiting
    invalidate(v);
  }

  // Turn every source into a prepared search: embed through the host, or match words in
  // the frame budget; the others are ready already.
  function resolveSources(v, run, sources) {
    run.searches = new Array(sources.length).fill(null);
    run.left = sources.length;
    sources.forEach(function (src, i) {
      if (src.ready) settleSource(v, run, i, { ok: true, search: src });
      else if (src.kind === "embedded") embedSource(v, run, i, src);
      else matchWords(v, run, i, src);
    });
  }

  function settleSource(v, run, i, outcome) {
    if (!isCurrent(v, run)) return;
    if (!outcome.ok) {
      refuseRun(v, run, outcome);
      return;
    }
    run.searches[i] = outcome.search; // null: a words entry that matched nothing
    run.left--;
    if (run.left === 0) startRanking(v, run);
  }

  function embedSource(v, run, i, src) {
    run.pendingEmbed++;
    callHost(v, run, v.search.embed, [src.text], "embed", function (outcome) {
      run.pendingEmbed--;
      settleSource(v, run, i, outcome.ok ? checkEmbedded(v, src, outcome.value) : outcome);
    });
  }

  // The embed callback's answer, checked before anything reaches the renderer.
  function checkEmbedded(v, src, answer) {
    var vector;
    var model;
    var form;
    try {
      if (!isObj(answer) || answer.vector === undefined) return searchRefusal("embed-malformed");
      vector = answer.vector;
      model = answer.model;
      form = answer.queryForm;
    } catch {
      // A getter on the answer threw: not a vector with a model id.
      return searchRefusal("embed-malformed");
    }
    var c = ET.search.checkQuery(v.set, { vector: vector, model: model });
    if (!c.ok) return plainRefusal(c);
    return {
      ok: true,
      search: prepared("embedded", src.text, model, c.vector, {
        queryForm: typeof form === "string" ? form : null,
        sentTo: "embedder",
        rerankText: src.text,
      }),
    };
  }

  function matchWords(v, run, i, src) {
    queueWork(v, run, ET.search.makeWordQuery(v.set, src.text), function (r) {
      settleSource(v, run, i, wordOutcome(v, run, src, r));
    });
  }

  function wordOutcome(v, run, src, r) {
    for (var w of r.unmatched || []) if (!run.unmatched.includes(w)) run.unmatched.push(w);
    if (!r.ok) return r.code === "words-none" ? { ok: true, search: null } : plainRefusal(r);
    return {
      ok: true,
      search: prepared("words", src.text, v.set.model, r.vector, {
        words: { used: r.used.map(copyUsed), unmatched: r.unmatched.slice() },
        baseNote: src.note,
        rerankText: src.text,
      }),
    };
  }

  function copyUsed(u) {
    return { word: u.word, how: u.how, count: u.count };
  }

  function queueWork(v, run, job, after) {
    v.search.work.push({ run: run, job: job, after: after });
    invalidate(v);
  }

  // ----- ranking and reranking -----

  function startRanking(v, run) {
    var kept = run.searches.filter(Boolean);
    if (kept.length === 0) {
      refuseRun(v, run, searchRefusal("words-none", { words: run.unmatched.join(", ") }));
      return;
    }
    var st = v.search.settings;
    var pov = ET.searchSets.LETTERS.indexOf(st.pointOfView);
    run.searches = kept;
    run.set = v.set;
    run.used = {
      k: st.k,
      candidates: st.candidates,
      top: st.top,
      pointOfView: pov >= 0 && pov < kept.length ? st.pointOfView : null,
      rerank: st.rerank,
    };
    var counts = { k: st.k, candidates: st.candidates, top: st.top };
    run.left = kept.length;
    kept.forEach(function (q, j) {
      q.letter = ET.searchSets.letter(j);
      q.scale = run.used.pointOfView === q.letter ? ET.searchSets.scaleFor(q.query) : null;
      q.reranker = null;
      q.sent = 0;
      q.note = q.baseNote;
      queueWork(v, run, ET.search.makeRank(run.set, q.query, { ...counts, scale: q.scale }), function (ranking) {
        q.ranking = ranking;
        q.view = ranking;
        run.left--;
        if (run.left === 0) startRerank(v, run);
      });
    });
  }

  function rerankOn(v, run) {
    return !!(run.used.rerank && v.search.rerank && run.set.text_included);
  }

  function startRerank(v, run) {
    if (!rerankOn(v, run)) {
      startPairs(v, run);
      return;
    }
    run.left = run.searches.length;
    run.searches.forEach(function (q) {
      if (q.rerankText === null) {
        q.note = searchRefusal("rerank-no-text").message;
        rerankDone(v, run);
        return;
      }
      var candidates = q.ranking.pool.map(function (hit) {
        return ET.search.pointText(run.set, hit.index);
      });
      q.sent = candidates.length; // never more than the candidates stated
      run.pendingRerank++;
      callHost(v, run, v.search.rerank, [q.rerankText, candidates], "rerank", function (outcome) {
        run.pendingRerank--;
        applyRerank(q, outcome);
        rerankDone(v, run);
      });
    });
  }

  function rerankDone(v, run) {
    run.left--;
    if (run.left === 0) startPairs(v, run);
  }

  // The pair reports, in the frame budget (with 100 results a search they cost far more than a
  // frame), then the run is shown.
  function startPairs(v, run) {
    if (!isCurrent(v, run)) return;
    var job;
    try {
      job = ET.searchSets.makePairReports(
        run.set,
        run.searches.map(function (q) {
          return q.view;
        })
      );
    } catch (err) {
      // Rankings always index the set they were made on; nothing to pair otherwise.
      job = null;
    }
    if (!job) {
      run.pairs = [];
      commitRun(v, run);
      return;
    }
    queueWork(v, run, job, function (pairs) {
      run.pairs = pairs;
      commitRun(v, run);
    });
  }

  // A reranker's answer: the new order, or a note and the embedding order kept.
  function applyRerank(q, outcome) {
    if (!outcome.ok) {
      q.note = outcome.message;
      return;
    }
    var scores;
    var model;
    try {
      scores = isObj(outcome.value) ? outcome.value.scores : undefined;
      model = isObj(outcome.value) ? outcome.value.model : undefined;
    } catch {
      // A getter on the answer threw: treated as a malformed answer below.
      scores = undefined;
    }
    var r = typeof model === "string" && model !== "" ? ET.search.rerankOrder(q.ranking, scores) : null;
    if (!r?.ok) {
      q.note = r ? r.message : ET.search.format("rerank-malformed");
      return;
    }
    q.view = { ...q.ranking, hits: r.hits, near: r.near, radius: r.radius };
    q.reranker = model;
  }

  // ----- what is shown -----

  function views(s) {
    return s.shown.map(function (q) {
      return q.view;
    });
  }

  function commitRun(v, run) {
    if (!isCurrent(v, run)) return;
    var s = v.search;
    s.run = null;
    s.work = [];
    clearRunTimers(v, run);
    s.shown = run.searches;
    s.shownSet = run.set;
    s.shownUsed = run.used;
    if (run.kind === "set") s.unmatched = run.unmatched.slice();
    s.code = null;
    s.message = null;
    if (run.kind === "set" && run.used.pointOfView === null) s.settings.pointOfView = null;
    relight(v);
    s.pairs = run.pairs || [];
    startFacing(v, run.swing);
    notifyModeSearch(v);
    if (run.resolve) run.resolve({ ok: true, search: searchInfo(v) });
    searchChanged(v);
    if (needsRerun(v)) rerun(v, "rerun", null);
    invalidate(v);
  }

  // The searches shown are from before an append, or were worked out with settings that
  // have changed since: they need working out again (with no swing).
  function needsRerun(v) {
    var s = v.search;
    if (!s.shown.length || !v.set) return false;
    var u = s.shownUsed;
    var st = s.settings;
    return s.shownSet !== v.set || countsChanged(u, st) || u.pointOfView !== st.pointOfView || u.rerank !== st.rerank;
  }

  function countsChanged(a, b) {
    return a.k !== b.k || a.candidates !== b.candidates || a.top !== b.top;
  }

  // Work the searches shown out again from the query vectors held (word searches match
  // their words again over the set now shown). No embed call, no swing.
  function rerun(v, kind, resolve) {
    var s = v.search;
    var run = newRun(v, kind, resolve, false);
    var sources = s.shown.map(function (q) {
      if (q.kind === "words") return { kind: "words", text: q.text, note: q.baseNote };
      return prepared(q.kind, q.text, q.model, q.query, {
        queryForm: q.queryForm,
        sentTo: q.sentTo,
        point: q.point,
        baseNote: q.baseNote,
        rerankText: q.rerankText,
      });
    });
    beginRun(v, run);
    resolveSources(v, run, sources);
    searchChanged(v);
    invalidate(v);
  }

  // Lit values for the searches shown, and their upload to the renderer.
  function relight(v) {
    var s = v.search;
    s.lit = s.shown.length ? ET.searchSets.litValues(views(s), v.set.count, s.settings.lit) : null;
    uploadLit(v);
  }

  function uploadLit(v) {
    var s = v.search;
    var r = v.renderer;
    if (!r || !s.lit) return;
    var n = r.status().count;
    var lit = new Float32Array(n);
    var shared = new Uint8Array(n);
    lit.set(s.lit.lit.subarray(0, Math.min(n, s.lit.lit.length)));
    shared.set(s.lit.shared.subarray(0, Math.min(n, s.lit.shared.length)));
    try {
      r.setLit(lit, shared);
      s.litUploaded = true;
    } catch {
      // The renderer holds no data yet: the lit values go up with the next commit.
      s.litUploaded = false;
    }
  }

  function dropLit(v) {
    var s = v.search;
    if (!s.litUploaded) return;
    s.litUploaded = false;
    try {
      v.renderer?.setLit(null);
    } catch (err) {
      // A disposed renderer has nothing left to clear.
    }
  }

  // Ease the filter toward 1 while a search is shown and toward 0 when none is; the lit
  // values are cleared from the renderer once it reaches 0.
  function easeFilter(v, dt) {
    var s = v.search;
    var target = s.shown.length ? 1 : 0;
    if (s.filter === target) return;
    s.filter += (target - s.filter) * (1 - Math.exp(-dt / FILTER_TIME));
    if (Math.abs(target - s.filter) < 1e-3) s.filter = target;
    if (s.filter === 0) dropLit(v);
  }

  function searchBusy(v) {
    var s = v.search;
    return s.work.length > 0 || !!s.facingJob || s.filter !== (s.shown.length ? 1 : 0);
  }

  // The search steppers, after the mode's own preparation, in what is left of the budget.
  function pumpSearch(v, start, budget) {
    var s = v.search;
    while (s.work.length) {
      var left = budget - (now(v) - start);
      if (left <= 0) return;
      var item = s.work[0];
      if (!stepWork(v, item, left)) return;
    }
    if (s.facingJob && budget - (now(v) - start) > 0) pumpFacing(v, budget - (now(v) - start));
  }

  // One step of the first queued stepper; true when it finished (and was handed on).
  function stepWork(v, item, left) {
    try {
      item.job.step(left);
    } catch (err) {
      refuseRun(v, item.run, { ok: false, code: "internal", message: "Internal error while searching: " + errorText(err, String(err)) });
      return false;
    }
    if (!item.job.done) return false;
    v.search.work.shift();
    item.after(item.job.result);
    return true;
  }

  // ----- the facing frame and the modes -----

  function startFacing(v, swing) {
    var s = v.search;
    s.facingJob = null;
    s.facingTarget = null;
    var pov = s.shown.find(function (q) {
      return q.scale;
    });
    var cur = v.last?.frame;
    try {
      var job = ET.searchSets.makeFacingFrame(
        v.set,
        s.shown.map(function (q) {
          return { query: q.query, hits: q.view.hits };
        }),
        {
          seed: v.seed,
          current: cur?.length === 3 * v.set.dimension ? new Float32Array(cur) : null,
          scale: pov ? pov.scale : null,
        }
      );
      s.facingJob = { job: job, swing: swing };
    } catch {
      // Fewer than three dimensions: there is no facing frame to swing to.
      s.facingJob = null;
    }
  }

  function pumpFacing(v, left) {
    var s = v.search;
    var f = s.facingJob;
    try {
      f.job.step(left);
    } catch (err) {
      // A facing frame that cannot be worked out leaves the view as it is.
      s.facingJob = null;
      return;
    }
    if (!f.job.done) return;
    s.facingJob = null;
    s.facingTarget = f.job.result;
    if (f.swing) faceNow(v);
  }

  // Ask the current mode to swing toward the facing frame. False when it has no face
  // member, refuses, or throws.
  function faceNow(v) {
    var s = v.search;
    var m = v.mode;
    if (!m || !s.facingTarget || typeof m.inst.face !== "function") return false;
    var took = false;
    try {
      took = m.inst.face(s.facingTarget, m.clock, { searches: s.shown.length }) === true;
    } catch (err) {
      // A host mode whose face throws keeps its own motion.
      took = false;
    }
    if (took) {
      searchChanged(v);
      invalidate(v);
    }
    return took;
  }

  function endSwing(v) {
    var m = v.mode;
    if (!m || typeof m.inst.face !== "function") return;
    try {
      m.inst.face(null, m.clock);
    } catch (err) {
      // nothing to end
    }
  }

  // What Focus is told about the searches (inst.searchChanged), or null.
  function modeSearch(v) {
    var s = v.search;
    if (!s.shown.length) return null;
    var pov = s.shown.find(function (q) {
      return q.scale;
    });
    return {
      searches: s.shown.map(function (q) {
        return {
          letter: q.letter,
          query: q.query,
          indices: Int32Array.from(q.view.hits, function (hit) {
            return hit.index;
          }),
        };
      }),
      scale: pov ? pov.scale : null,
      onlyResults: !!s.settings.onlyResults,
    };
  }

  // Tell a mode with a searchChanged member (Focus) about the searches. If it hands back a
  // stepper (or { work: stepper }), it is pumped with the mode's own preparation.
  function notifyModeSearch(v) {
    var m = v.mode;
    if (!m || typeof m.inst.searchChanged !== "function") return;
    var r;
    try {
      r = m.inst.searchChanged(modeSearch(v), m.clock);
    } catch (err) {
      // A host mode whose searchChanged throws keeps its current view.
      return;
    }
    var work = typeof r?.step === "function" ? r : r?.work;
    if (typeof work?.step === "function") m.jobs.push(work);
    invalidate(v);
  }

  function swinging(v) {
    var m = v.mode;
    if (!m || !v.search.shown.length || typeof m.inst.face !== "function") return false;
    try {
      var f = m.inst.describe()?.facing;
      return !!f && m.clock < f.until;
    } catch {
      // A mode whose describe throws reports no swing.
      return false;
    }
  }

  // ----- clearing, settings, callbacks -----

  function clearSearches(v) {
    if (v.destroyed) return false;
    var s = v.search;
    var had = s.shown.length > 0 || !!s.run;
    endRun(v, searchRefusal("superseded"));
    var wasShown = s.shown.length > 0;
    s.shown = [];
    s.shownSet = null;
    s.lit = null;
    s.pairs = [];
    s.unmatched = [];
    s.code = null;
    s.message = null;
    s.facingJob = null;
    s.facingTarget = null;
    if (wasShown) {
      endSwing(v);
      notifyModeSearch(v);
    }
    if (had) searchChanged(v);
    invalidate(v);
    return had;
  }

  // A replace starts with no search (the renderer's setData already cleared its lit values).
  function dropSearchesForReplace(v) {
    var s = v.search;
    var had = s.shown.length > 0 || !!s.run;
    endRun(v, searchRefusal("superseded"));
    s.shown = [];
    s.shownSet = null;
    s.lit = null;
    s.pairs = [];
    s.unmatched = [];
    s.facingJob = null;
    s.facingTarget = null;
    s.filter = 0;
    s.litUploaded = false;
    if (had) searchChanged(v);
  }

  // After an append: the results are stale until worked out again, which starts now
  // (unless a run is already working; its commit sees the new set and re-runs).
  function searchesAfterAppend(v) {
    var s = v.search;
    if (!s.shown.length) return;
    if (!s.run) rerun(v, "rerun", null);
    else searchChanged(v);
  }

  // Apply a settings patch; returns which kinds of work it needs.
  function applySettings(v, patch) {
    var s = v.search;
    var st = s.settings;
    var before = { ...st };
    applyCounts(st, patch);
    if (ET.searchSets.LIT_SETTINGS.includes(patch.lit)) st.lit = patch.lit;
    if (typeof patch.distances === "boolean") st.distances = patch.distances;
    if (typeof patch.onlyResults === "boolean") st.onlyResults = patch.onlyResults;
    if (typeof patch.rerank === "boolean") st.rerank = patch.rerank && rerankOffered(v);
    if (Object.hasOwn(patch, "pointOfView") && validPointOfView(v, patch.pointOfView)) st.pointOfView = patch.pointOfView;
    return {
      rank: countsChanged(st, before) || st.pointOfView !== before.pointOfView || st.rerank !== before.rerank,
      lit: st.lit !== before.lit,
      only: st.onlyResults !== before.onlyResults,
    };
  }

  // A count in a patch (a number, or a string holding one, as a range input gives), or null
  // when absent or not a number: null, booleans and empty strings are ignored, not read as 0.
  function patchCount(patch, key) {
    var raw = Object.hasOwn(patch, key) ? patch[key] : null;
    var text = typeof raw === "string" && raw.trim() !== "";
    if (typeof raw !== "number" && !text) return null;
    var n = Number(raw);
    return Number.isFinite(n) ? n : null;
  }

  // k, candidates and top from a patch; candidates first, so top is cut to the new candidates.
  function applyCounts(st, patch) {
    var k = patchCount(patch, "k");
    var candidates = patchCount(patch, "candidates");
    var top = patchCount(patch, "top");
    if (k !== null) st.k = ET.search.clampK(k);
    if (candidates !== null) st.candidates = ET.search.clampCandidates(candidates);
    st.top = ET.search.clampTop(top === null ? st.top : top, st.candidates);
  }

  function validPointOfView(v, value) {
    if (value === null) return true;
    var j = ET.searchSets.LETTERS.indexOf(value);
    return j >= 0 && j < v.search.shown.length;
  }

  function rerankOffered(v) {
    return !!v.search.rerank && (!v.set || v.set.text_included === true);
  }

  function setSearchSettings(v, patch) {
    if (v.destroyed) return Promise.resolve(searchRefusal("destroyed"));
    var s = v.search;
    var need = applySettings(v, isObj(patch) ? patch : {});
    var running = s.run?.kind === "set";
    if (need.rank && s.shown.length && !running) {
      return new Promise(function (resolve) {
        rerun(v, "settings", resolve);
      });
    }
    if (need.lit && s.shown.length) relight(v);
    if (need.only && s.shown.length) notifyModeSearch(v);
    searchChanged(v);
    invalidate(v);
    return Promise.resolve({ ok: true, search: searchInfo(v) });
  }

  function setSearchCallbacks(v, cbs) {
    var s = v.search;
    if (!v.destroyed && isObj(cbs)) {
      var removedEmbed = takeCallback(s, cbs, "embed");
      var removedRerank = takeCallback(s, cbs, "rerank");
      if (!s.rerank) s.settings.rerank = false;
      var run = s.run;
      if (run && ((removedEmbed && run.pendingEmbed > 0) || (removedRerank && run.pendingRerank > 0))) {
        endRun(v, searchRefusal("superseded"));
      }
      searchChanged(v);
      if (!s.run && needsRerun(v)) rerun(v, "rerun", null);
    }
    return { embedder: !!s.embed && !v.destroyed, reranker: !!s.rerank && !v.destroyed };
  }

  // Set s[key] from cbs[key] (a function, or null to remove; anything else is ignored).
  // Returns true when a callback was removed or replaced.
  function takeCallback(s, cbs, key) {
    if (!Object.hasOwn(cbs, key)) return false;
    var value = cbs[key];
    if (value !== null && typeof value !== "function") return false;
    var replaced = !!s[key] && s[key] !== value;
    s[key] = value;
    return replaced;
  }

  function faceSearches(v) {
    if (v.destroyed || !v.search.shown.length) return false;
    return faceNow(v);
  }

  // ----- info().search -----

  function searchInfo(v) {
    var s = v.search;
    var set = v.set;
    var same = ET.search.checkSameSpace(set);
    var stale = !!(s.shownSet && set && s.shownSet !== set);
    return {
      active: s.shown.length > 0,
      waiting: !!s.run,
      stale: stale,
      staleBy: stale ? set.count - s.shownSet.count : 0,
      code: s.code,
      message: s.message,
      measure: ET.search.MEASURE_TEXT,
      settings: { ...s.settings },
      embedder: { available: !!s.embed },
      reranker: { available: !!s.rerank, offered: !!s.rerank && !!set && set.text_included === true },
      sameSpace: { ok: same.ok, kind: sameSpaceKind(set, same) },
      litCount: s.lit ? s.lit.litCount : 0,
      sharedCount: s.lit ? s.lit.sharedCount : 0,
      unmatched: s.unmatched.slice(),
      facing: swinging(v),
      faceable: typeof v.mode?.inst.face === "function",
      searches: s.shown.map(function (q, j) {
        return searchEntryInfo(v, q, j);
      }),
      pairs: s.pairs.map(function (p) {
        return pairInfo(v, p);
      }),
    };
  }

  function sameSpaceKind(set, same) {
    if (!same.ok) return same.kind || null;
    return set.reduction ? set.reduction.kind : "none";
  }

  function searchEntryInfo(v, q, j) {
    var s = v.search;
    var view = q.view;
    return {
      letter: q.letter,
      kind: q.kind,
      text: q.text,
      model: q.model,
      queryForm: q.queryForm,
      sentTo: q.sentTo,
      reranker: q.reranker,
      words: q.words ? { used: q.words.used.map(copyUsed), unmatched: q.words.unmatched.slice() } : null,
      point: q.kind === "point" ? q.point : null,
      pointOfView: !!q.scale,
      k: view.k,
      candidates: view.candidates,
      top: view.top,
      available: availableOf(view),
      sent: q.sent || 0,
      counts: countsNote(q, view),
      note: q.note,
      radius: view.radius,
      insideCount: s.lit ? s.lit.insideCounts[j] : 0,
      results: view.hits.map(function (hit) {
        return resultInfo(v, hit);
      }),
    };
  }

  // How many points could be results of a ranking: the named ones, or all when none is named.
  function availableOf(ranking) {
    return ranking.named > 0 ? ranking.named : ranking.count;
  }

  // Says so when a number asked for is more than there is to give, or null.
  function countsNote(q, view) {
    var available = availableOf(view);
    var what = available + (view.named > 0 ? " named points" : " points");
    if (q.reranker) {
      if (view.candidates <= available) return null;
      return "Only " + what + " can be results, so the reranker was given " + available + " candidates, not " + view.candidates + ".";
    }
    if (view.k <= available) return null;
    return "Only " + what + " can be results, so " + available + " are shown, not " + view.k + ".";
  }

  function resultInfo(v, hit) {
    var set = v.set || v.search.shownSet;
    return {
      id: hit.id,
      index: hit.index,
      rank: hit.rank,
      embeddingRank: hit.embeddingRank,
      plainRank: hit.plainRank,
      distance: hit.distance,
      plainDistance: hit.plainDistance,
      gap: hit.gap,
      moved: hit.moved,
      score: hit.score,
      text: ET.search.pointText(set, hit.index),
    };
  }

  function pairInfo(v, p) {
    var ids = (v.set || v.search.shownSet).ids;
    var L = ET.searchSets.letter;
    return {
      a: L(p.a),
      b: L(p.b),
      shared: p.shared,
      common: p.common,
      commonIds: Array.from(p.commonIndices, function (i) {
        return ids[i];
      }),
      closest: p.closest ? { a: ids[p.closest.a], b: ids[p.closest.b], distance: p.closest.distance } : null,
    };
  }

  // The searches changed: tell the panel and the host.
  function searchChanged(v) {
    if (v.destroyed) return;
    var s = v.search;
    var snapshot = null;
    if (s.panel && typeof s.panel.update === "function") {
      snapshot = searchInfo(v);
      try {
        s.panel.update(snapshot);
      } catch (err) {
        reportHostError(v, err);
      }
    }
    if (typeof v.options.onSearchChange === "function") call(v, v.options.onSearchChange, snapshot || searchInfo(v));
  }

  function destroySearch(v) {
    var s = v.search;
    var panel = s.panel;
    s.panel = null;
    if (typeof panel?.destroy === "function") {
      try {
        panel.destroy();
      } catch (err) {
        reportHostError(v, err);
      }
    }
    s.work = [];
    s.facingJob = null;
    s.facingTarget = null;
    s.shown = [];
    s.shownSet = null;
    s.lit = null;
    s.pairs = [];
    s.litUploaded = false;
    s.filter = 0;
  }

  // ----- hidden points (Focus's Only results) -----

  // Whether unlit points are hidden this frame: Focus with Only results on (its
  // describe().onlyResults), lit values set and the filter on. Worked out once per frame.
  function hidesUnlit(v) {
    var m = v.mode;
    if (v.modeId !== "focus" || !m || !v.search.lit || v.search.filter <= 0) return false;
    try {
      return m.inst.describe()?.onlyResults === true;
    } catch (err) {
      // A mode whose describe throws hides nothing.
      return false;
    }
  }

  // True when point i is hidden this frame (its lit value is 0 while unlit points are
  // hidden). Hidden points are skipped when hit-testing and labelling.
  function hiddenPoint(v, i) {
    var lit = v.search.lit;
    if (!v.search.hideUnlit || !lit) return false;
    return lit.lit[i] <= 0; // lit values are finite, in [0, 1]
  }

  // ----- the panel hook (the panel itself is js/src/45-search-panel.js, task t9) -----

  // Mount the search panel when the module is in the core file and the host did not turn it
  // off. With no ET.searchPanel this does nothing.
  function mountSearchPanel(v) {
    if (!v.options.searchPanel || typeof ET.searchPanel?.mount !== "function") return;
    var parts = {
      panel: v.panel,
      stage: v.stage,
      overlay: v.overlay,
      provenanceList: v.provList,
      provenanceSummary: v.provSummary,
    };
    try {
      v.search.panel =
        ET.searchPanel.mount(parts, v.handle, {
          document: v.doc,
          light: !!v.theme?.light,
          // The panel reads the theme it styles itself with, and the set for its suggestions
          // and for where results sit on the stage (docs/search-interface.md, "Panel (t9)").
          theme: function () {
            return v.theme || null;
          },
          data: function () {
            return v.set;
          },
        }) || null;
    } catch (err) {
      v.search.panel = null;
      reportHostError(v, err);
    }
  }

  // The panel's markers, links and result labels on the overlay, once per frame.
  function drawSearchOverlay(v, s, ds) {
    var panel = v.search.panel;
    if (typeof panel?.drawOverlay !== "function") return;
    var ctx = overlayContext(v);
    if (!ctx) return;
    try {
      var drew = panel.drawOverlay(
        ctx,
        function (vector) {
          return projectVector(v, vector, s, ds);
        },
        searchFrame(v)
      );
      if (drew !== false) v.overlayDirty = true;
    } catch (err) {
      reportHostError(v, err);
    }
  }

  // What the panel needs to draw this frame beyond the projection: each shown search's raw
  // query vector (in letter order), the filter, the pixel ratio, whether labels are on, the
  // mode, and which points are hidden (Focus's Only results).
  function searchFrame(v) {
    return {
      queries: v.search.shown.map(function (q) {
        return q.query;
      }),
      filter: v.search.filter,
      dpr: v.dpr,
      light: !!v.theme?.light,
      labels: v.showLabels,
      mode: v.modeId,
      hidden: function (i) {
        return hiddenPoint(v, i);
      },
    };
  }

  // A vector of the data's dimension through the frame shown, in overlay pixels.
  function projectVector(v, vector, s, ds) {
    var D = v.set.dimension;
    var F = s.frame;
    var C = s.centre;
    var a = 0;
    var b = 0;
    var c = 0;
    for (var d = 0; d < D; d++) {
      var x = vector[d] - C[d];
      a += x * F[d];
      b += x * F[D + d];
      c += x * F[2 * D + d];
    }
    return ET.renderer.place([a, b, c], ds, v.W, v.H);
  }

  // ----- Focus: a click on a point searches from it -----

  function focusClick(v, e, pt, at) {
    if (v.modeId !== "focus" || !v.last || !v.lastDraw || !v.set) return;
    if (Math.hypot(e.clientX - pt.sx, e.clientY - pt.sy) > CLICK_SLOP) return;
    var i = nearestPoint(v, at.x * v.dpr, at.y * v.dpr, CLICK_REACH * v.dpr);
    if (i >= 0) void setSearches(v, [{ point: v.set.ids[i] }]); // its answer is the view itself
  }

  // The index of the shown point nearest (x, y) in device pixels within reach, or -1.
  function nearestPoint(v, x, y, reach) {
    var best = -1;
    var bd = reach * reach;
    for (var i = 0; i < v.set.count; i++) {
      if (hiddenPoint(v, i)) continue;
      var p = project(v, i, v.last, v.lastDraw, v.tmp3);
      var d2 = (p.x - x) * (p.x - x) + (p.y - y) * (p.y - y);
      if (d2 < bd) {
        bd = d2;
        best = i;
      }
    }
    return best;
  }

  // ---------- lifecycle ----------

  // Every option: the host's value where it gave one, the default otherwise.
  function readOptions(options) {
    var opts = {};
    for (var key in DEFAULT_OPTIONS) {
      if (Object.hasOwn(DEFAULT_OPTIONS, key)) opts[key] = readOption(options, key);
    }
    return opts;
  }

  function prefersReducedMotion(win) {
    try {
      return !!win?.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    } catch (err) {
      // A host whose matchMedia throws is treated as not asking for reduced motion.
      return false;
    }
  }

  // A usable view seed is a finite number or a non-empty string. It is kept exactly as
  // given (7 and "7" are different seeds, and seed() hands it back unchanged).
  function isSeed(seed) {
    if (typeof seed === "number") return Number.isFinite(seed);
    return typeof seed === "string" && seed !== "";
  }

  function mount(el, options) {
    if (!isElement(el)) throw new TypeError("EmbeddingsTumbler.mount needs a DOM element");
    var existing = lookup(el);
    if (existing) return existing.handle;
    var doc = el.ownerDocument;
    var win = doc.defaultView || null;
    var opts = readOptions(options);
    var reduced = prefersReducedMotion(win);
    var seed = isSeed(opts.seed) ? opts.seed : 1;
    var v = {
      el: el,
      doc: doc,
      win: win,
      options: opts,
      seed: seed,
      speed: Number(opts.speed) > 0 ? Number(opts.speed) : 1,
      reducedMotion: reduced,
      running: opts.paused === null ? !reduced : !opts.paused,
      showLabels: !!opts.labels,
      trails: !!opts.trails,
      modeId: ET.modes.get(opts.mode) ? opts.mode : "tumble",
      set: null,
      mode: null,
      last: null,
      lastDraw: null,
      renderer: null,
      rendering: false,
      destroyed: false,
      broken: false,
      raf: 0,
      prev: null,
      dirty: true,
      onScreen: true,
      spin: 0,
      drawTime: 0,
      userZoom: 1,
      drag: { active: false, yaw: 0, pitch: 0, x: 0, y: 0 },
      pinch: null,
      hover: null,
      needClear: true,
      statusClock: STATUS_EVERY,
      statusText: "",
      sinceAppend: Infinity,
      groupIndex: Object.create(null), // group name -> index; names are untrusted
      groupNames: [],
      labelledCount: 0,
      lightLoad: 0, // see crowding()
      labelSample: [],
      labelPool: [],
      sx: new Float32Array(LABEL_SAMPLE),
      sy: new Float32Array(LABEL_SAMPLE),
      tmp3: [0, 0, 0],
      projector: null, // the label sample's projector (makeProjector), made when first needed
      sampleCoords: new Float64Array(3 * LABEL_SAMPLE),
      placed: { x: 0, y: 0 },
      overlayDirty: false,
      listeners: [],
      io: null,
      ro: null,
      retryTimer: 0,
      frames: 0,
      fps: 0,
      fpsAt: null,
      fpsFrames: 0,
      narrow: null,
      oneColumn: null,
      dpr: 1,
      W: 2,
      H: 2,
      fatalMessage: null,
      fatalKind: null,
      noticeMessage: null,
      timing: {
        mountAt: 0,
        firstFrameMs: null,
        firstReadyMs: null,
        longestFrameMs: 0,
        lastAppendMs: null,
        refits: 0,
        lastRefit: null,
        budgetMs: null,
        workMs: 0,
      },
      lastSpent: 0,
      lastScript: 0, // the last frame's script time, drawing excluded (ms)
      lastBudget: 0,
      drawSpent: 0,
      interval: 0, // smoothed time between animation frames (ms)
      rafAt: null,
      dprCap: null, // the lowered drawing-buffer ratio (adaptivePixelRatio), or null
      slowSeconds: 0,
      lostTime: false,
      paintKey: null,
      themeKey: null,
      search: newSearchState(opts),
    };
    v.timing.mountAt = now(v);
    v.tick = function (t) {
      frame(v, t);
    };
    build(v);
    el.appendChild(v.root);
    syncTheme(v); // read once the root inherits the host's properties
    v.playButton.textContent = v.running ? "Pause" : "Play";
    v.playButton.setAttribute("aria-pressed", v.running ? "false" : "true");
    paintModeButtons(v);
    v.mastTitle.textContent = opts.title ? String(opts.title) : "";
    v.mastTitle.style.display = opts.title ? "" : "none";
    makeRenderer(v);
    sizeStrip(v);
    renderProvenance(v);
    describeSet(v);
    wire(v);
    measure(v);
    v.handle = makeHandle(v);
    mountSearchPanel(v);
    remember(el, v);
    invalidate(v);
    return v.handle;
  }

  function destroy(v) {
    if (v.destroyed) return false;
    endRun(v, searchRefusal("destroyed")); // waiting promises resolve with destroyed
    v.destroyed = true;
    destroySearch(v);
    unschedule(v);
    if (v.retryTimer && typeof v.win?.clearTimeout === "function") v.win.clearTimeout(v.retryTimer);
    v.retryTimer = 0;
    if (v.io) v.io.disconnect();
    if (v.ro) v.ro.disconnect();
    v.io = null;
    v.ro = null;
    v.listeners.forEach(function (l) {
      l[0].removeEventListener(l[1], l[2], l[3]);
    });
    v.listeners = [];
    if (v.mode) leaveSafely(v.mode.inst);
    v.mode = null;
    if (v.renderer) {
      try {
        v.renderer.dispose();
      } catch (err) {
        // the element goes away regardless
      }
    }
    v.renderer = null;
    v.rendering = false;
    v.root?.remove();
    forget(v.el);
    v.set = null;
    v.last = null;
    v.lastDraw = null;
    v.labelPool = [];
    return true;
  }

  function info(v) {
    var m = v.mode;
    return {
      mode: v.modeId,
      paused: !v.running,
      suspended: !v.destroyed && suspended(v),
      hidden: !!v.doc.hidden,
      onScreen: v.onScreen,
      destroyed: v.destroyed,
      reducedMotion: v.reducedMotion,
      time: m ? m.clock : 0,
      seed: v.seed,
      speed: v.speed,
      zoom: v.userZoom,
      ready: readyOf(m),
      preparing: preparingOf(m),
      broken: v.broken,
      count: v.set ? v.set.count : 0,
      dimension: v.set ? v.set.dimension : 0,
      model: v.set ? v.set.model : null,
      rendering: v.rendering,
      animating: !!v.raf,
      frames: v.frames,
      fps: v.fps,
      pixelRatio: v.dpr,
      pixelRatioLowered: v.dprCap !== null,
      status: v.statusText,
      message: v.fatalMessage || v.noticeMessage || null,
      timing: {
        firstFrameMs: v.timing.firstFrameMs,
        firstReadyMs: v.timing.firstReadyMs,
        longestFrameMs: v.timing.longestFrameMs,
        lastAppendMs: v.timing.lastAppendMs,
        refits: v.timing.refits,
        lastRefit: v.timing.lastRefit ? { ...v.timing.lastRefit } : null,
        budgetMs: v.timing.budgetMs,
        workMs: v.timing.workMs,
        scriptMs: v.lastScript,
        drawMs: v.drawSpent,
        intervalMs: v.interval,
      },
      search: searchInfo(v),
    };
  }

  function makeHandle(v) {
    var h = {
      element: v.el,
      update: function (data) {
        return update(v, data);
      },
      destroy: function () {
        return destroy(v);
      },
      pause: function () {
        if (!v.destroyed) setRunning(v, false);
      },
      resume: function () {
        if (!v.destroyed) setRunning(v, true);
      },
      isPaused: function () {
        return !v.running;
      },
      setMode: function (id) {
        return setMode(v, id);
      },
      mode: function () {
        return v.modeId;
      },
      modes: function () {
        return ET.modes.ids();
      },
      time: function () {
        return v.mode ? v.mode.clock : 0;
      },
      seek: function (t) {
        var x = Number(t);
        if (!Number.isFinite(x) || x < 0) x = 0;
        if (v.mode) {
          v.mode.clock = x;
          v.mode.seeked = true; // an exact frame is asked for: no spin while it prepares
        }
        v.spin = x * spinFactor(v.mode);
        v.needClear = true;
        invalidate(v);
        return v.mode ? v.mode.clock : 0;
      },
      seed: function () {
        return v.seed;
      },
      setSpeed: function (s) {
        var x = Number(s);
        if (Number.isFinite(x) && x > 0) {
          v.speed = x;
          v.speedInput.value = String(x);
        }
        return v.speed;
      },
      zoom: function (z) {
        if (z !== undefined && !v.destroyed) setZoom(v, Number(z) || 1);
        return v.userZoom;
      },
      resetZoom: function () {
        if (!v.destroyed) setZoom(v, 1);
      },
      refreshTheme: function () {
        refreshTheme(v);
      },
      info: function () {
        return info(v);
      },
      // Search (docs/search-interface.md, "Viewer (t8)").
      setSearches: function (list) {
        return setSearches(v, list);
      },
      clearSearches: function () {
        return clearSearches(v);
      },
      setSearchSettings: function (patch) {
        return setSearchSettings(v, patch);
      },
      searchSettings: function () {
        return { ...v.search.settings };
      },
      faceSearches: function () {
        return faceSearches(v);
      },
      setSearchCallbacks: function (cbs) {
        return setSearchCallbacks(v, cbs);
      },
    };
    Object.defineProperty(h, "_viewer", { value: v, enumerable: false });
    return h;
  }

  return {
    mount: mount,
    get: function (el) {
      var v = lookup(el);
      return v ? v.handle : null;
    },
    update: function (el, data) {
      var v = lookup(el);
      if (!v) {
        return {
          ok: false,
          code: "not-mounted",
          message: "No viewer is mounted on this element; call mount(el) first.",
        };
      }
      return update(v, data);
    },
    destroy: function (el) {
      var v = lookup(el);
      return v ? destroy(v) : false;
    },
    parseColour: parseColour,
    safeCssValue: safeCssValue,
    makeProjector: makeProjector,
    SHADOW: SHADOW,
  };
})();

ET.api.mount = ET.viewer.mount;
ET.api.update = ET.viewer.update;
ET.api.destroy = ET.viewer.destroy;
ET.api.get = ET.viewer.get;
ET.api.registerMode = function (definition) {
  return ET.modes.register(definition);
};

  // Export. Public API only; ET is reachable as api._internal for tests.
  var api = ET.api;
  api.version = ET.version;
  Object.defineProperty(api, "_internal", { value: ET, enumerable: false });

  if (typeof module === "object" && module !== null && module.exports) {
    module.exports = api; // node (tests)
  } else {
    root.EmbeddingsTumbler = api; // classic script tag: one global
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
